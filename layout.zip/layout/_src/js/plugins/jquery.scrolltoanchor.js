/*
 * handle scrolling on click on achro links
 */
;(function($) {

	'use strict';

	/**
	* handle clisck on anchor links
	* @param {jQuery event} jqE The message-event
	* @returns {undefined}
	*/
	var anchorScrollHandler = function(jqE) {
        event.preventDefault();

        $('html, body').animate({
            scrollTop: $($.attr(this, 'href')).offset().top
        }, 1000);
	};
	
	// set listener clicks on anchor links   
    $(document).on('click', 'a.js-anchor-scroll[href^="#"]', anchorScrollHandler)

})(jQuery);