var jq;
jq = jQuery.noConflict();

jq(document).on("click", "#contactfrm_btn", function () {
    assignEmailToForm();
    SubmitContactForm();
});

jq(document).on("click", "#clear_btn", function () {
    clearValidatedFields();
});

function SubmitContactForm() {
    var redirectUrl = jq('#ContactForm').attr("data-redirect-page");
    var inquiryData = {
        firstName: jq("#FirstName").val(),
        lastName: jq("#LastName").val(),
        email: jq("#Email").val(),
        phone: jq("#Phone").val(),
        urgency: jq("#Urgency").is(':checked'),
        message: jq("#Message").val(),
        recipient: jq("#Recipient").val(),
        id: jq("#Id").val(),
        subscribe: jq("#Subscribe").is(':checked')
    }

    jq.ajax({
        type: "POST",
        url: "/diamond/InstallerInquiries/ProcessContactDetails",
        data: inquiryData,
        dataType: 'json',
        success: function () {
	    clearFormFields();
            window.location.href = redirectUrl;
        },
        error: function (xhr, ajaxOptions, thrownError) {
            console.log(xhr.error);
        }
    });
}

function clearFormFields() {
	jq("#ContactForm input[type=text], textarea").val("");
	jq("input[type=checkbox]").prop('checked', false);
}

function clearValidatedFields(){
	jq("#ContactForm input[type=text], textarea").removeClass("valid");
	jq("#contactfrm_btn").attr("disabled");
}
