//fai.js v1.2
var jq;

jq = jQuery.noConflict();

jq(document).ready(function () {
    Setup_FormValidations();
    Setup_InstallerResults();
    //display progress bar contents when editing
    if (Remeha.Sc.SitecoreContext.IsPageEditor) {
        jq('.tab-panel').css('display', 'block');
    }

    if (Check_FaiFabLink()) {
        Autopopulate_Fai();
        Remove_StoredAdvies();
    }

    Initialize_InstallerSelection(true);

    jq(".progress-bar-fai li a").click(function(event){	
        if(event){
            event.preventDefault();
        }
    });
    if(jq(".installer-pagination ").length > 0){
        jq(document).on("click", "#find_installer", function () {
            jq(".pagination-number:first a").click();
        });
    }
});
function Check_FaiFabLink() {
    if (localStorage.getItem('referredByAdvies') !== null) {
        if (localStorage.getItem('referredByAdvies') === 'true') {
            return true;
        } else {
            return false;
        }
    }
    return false;
}

function Get_StoredAdvies() {
    var storedAdvies = [];
    var fabData = {};
    fabData.postCode = localStorage.getItem("adviesFabPostcode");
    fabData.houseNumber = localStorage.getItem("adviesFabHouseNumber");
    fabData.InstallerDistance = localStorage.getItem("adviesFabInstallerDistance");
    storedAdvies.push(fabData);
    if (storedAdvies.length > 0) {
        return storedAdvies;
    } else {
        return false;
    }
}

function Remove_StoredAdvies() {
    localStorage.setItem("referredByAdvies", false);
    localStorage.removeItem("adviesFabPostcode");
    localStorage.removeItem("adviesFabHouseNumber");
    localStorage.removeItem("adviesFabInstallerDistance");
}

function Autopopulate_Fai() {
    var adviesData = Get_StoredAdvies();
    if (adviesData !== false) {
        var postCode = Get_FAI_FieldByName('textInstallers');
        var houseNo = Get_FAI_FieldByName('textHouseNo');

        jq("input[name='installer'][ID='ID1']");
        jq(postCode).val(adviesData[0].postCode);
        jq(houseNo).val(adviesData[0].houseNumber);
        Get_FAI_FieldByName('mapRadius').val(adviesData[0].InstallerDistance);
        validate_Input(postCode);
        validate_Input(houseNo);
        Validate_Select(Get_FAI_FieldByName('mapRadius'));
        jq("ul.fai-search-purpose input").first().prop("checked", true);
        Validate_Address(adviesData[0].postCode, adviesData[0].houseNumber);
        jq('input[type=button].find_installers').not('.product-result #find_installer').click();
    } else {
        console.log("Error in retrieving Boiler Advies data!");
    }
}

function Advies_toFAI() {
    localStorage.setItem("adviesFabPostcode", Get_FAI_FieldByName('textInstallers').val().trim());
    localStorage.setItem("adviesFabHouseNumber", Get_FAI_FieldByName('textHouseNo').val().trim());
    localStorage.setItem("adviesFabInstallerDistance", Get_FAI_FieldByName('mapRadius').val().trim());
    localStorage.setItem('referredByAdvies', true);
    var paramaters = getUrlVars(location.hash.replace( /^#/, '' ));
    var action =  jq('.product-result #find_installer').closest(".find-installer-container").attr('action');
    window.location.href = buildSearchUrl(paramaters,  action + "#");  //"fai.html"; //test redirectin. this should be handled by sitecore
}

function Initialize_InstallerSelection(isForced) {
    if (isForced) {
        localStorage.setItem('selectedFaiInstallers', '');
        window.sessionStorage.clear();
    } else {
        if (localStorage.getItem('selectedFaiInstallers') === null) {
            localStorage.setItem('selectedFaiInstallers', '');
        }
    }

    jq('.installers-results-confirm').empty();
    //this sets the session storage to local storage for validation
    //Sync_InstallerSessionWithWebStorage();
}

function Sync_InstallerSessionWithWebStorage(){
    if(sessionStorage.RecipientsList){
        JSON.parse(sessionStorage.RecipientsList).forEach(function(item){
            Store_SelectedInstaller(item.guid, currentSelectedInstallers) 
        });
    }
}

function Get_InstallerSelection() {
    if (localStorage.getItem('selectedFaiInstallers') !== null && localStorage.getItem('selectedFaiInstallers').length > 0) {
        return localStorage.getItem('selectedFaiInstallers').split("&");
    } else {
        return false
    }
}

function Check_SelectedInstaller(installerGuid, currentSelectedInstallers) {
    var currentSelectedInstallers = currentSelectedInstallers.split("&");
    var returnVal = true;
    if (currentSelectedInstallers.length >= 3) {
        returnVal = false
    } else {
        currentSelectedInstallers.forEach(function (item) {
            if (installerGuid === item) {
                returnVal = false;
            }
        });
    }
    return returnVal;
}

function Store_SelectedInstaller(installerGuid, currentSelectedInstallers) {
    if (Check_SelectedInstaller(installerGuid, currentSelectedInstallers)) {
        if (currentSelectedInstallers !== "") {
            var newSelectedInstaller = currentSelectedInstallers + "&" + installerGuid;
        } else {
            var newSelectedInstaller = installerGuid;
        }
        localStorage.setItem('selectedFaiInstallers', newSelectedInstaller);
    } else {
        //console.log("Unexpected behavior! Cannot select more than 3 installers!");
    }
}

function Remove_SelectedInstaller(installerGuid, currentSelectedInstallers) {
    if (!Check_SelectedInstaller(installerGuid, currentSelectedInstallers)) {
        var toReplace = "";
        var indexLocation = 0;
        currentSelectedInstallers.split("&").forEach(function (item, index) {
            if (installerGuid === item) {
                indexLocation = index;
            }
        });
        if (indexLocation === 0 && currentSelectedInstallers.split("&").length === 1) {
            toReplace = installerGuid
        } else if (indexLocation === 0 && currentSelectedInstallers.split("&").length > 1) {
            toReplace = installerGuid + "&"
        } else {
            toReplace = "&" + installerGuid;
        }
        var newSelectedInstaller = currentSelectedInstallers.replace(toReplace, "");
        localStorage.setItem('selectedFaiInstallers', newSelectedInstaller);
    } else {
        //console.log("Unexpected behavior! Cannot deselect a non-selected installer!");
    }
}


function validate_Input(ctrl) {
    if (jq(ctrl).length > 0) {
        var input = jq(ctrl);
        input.removeClass("valid-field");
        jq(input).next('valid-input').remove();
        Validate_FAIForm();
        if (input.val().trim().length > 0) {
            jq(input).addClass('valid-field');
            jq(input).after('<valid-input></valid-input>');
        }
    }

}

function Validate_Select(ctrl) {
    var input = jq(ctrl);
    Validate_FAIForm();
    input.removeClass("valid-input");
    if (input.val().trim().length > 0) {
        input.addClass("valid-input");
    }
}


function Validate_FAIForm() {
    var submitButton = 'input[type=button].find_installers';
    EnableDisable_Element(submitButton, false);
    jq("#aanvraag-link").removeClass("enabled").addClass('disabled');
    jq("#selectie-link").removeClass("enabled").addClass('disabled');
    var areInputs_Valid = true;
    jq('.find-an-installer.fai input[type="text"], .find-an-installer.fai  select').each(function () {
        if (areInputs_Valid) {
            areInputs_Valid = jq(this).val().trim().length > 0;
        }
    });
    if (validate_postcode() && areInputs_Valid) {
        EnableDisable_Element(submitButton, true);
        if(jq(".fai.errorMessage").hasClass('show-error'))
        {
            jq("#aanvraag-link").removeClass("disabled").addClass('enabled');
            jq("#selectie-link").removeClass("disabled").addClass('enabled');
        }
    }
}

function Validate_postalcode(ctrl) {
    var input = jq(ctrl);
    input.removeClass("valid-field");
    jq(input).next('valid-input').remove();
    jq(".fai.errorMessage").removeClass('show-error');
    jq(".fai.errorMessagepostcode").removeClass('show-error');
    var isPostalCodeValid = validate_postcode();


    if (!isPostalCodeValid) {
        jq(".fai.errorMessagepostcode").addClass('show-error');
        input.addClass("error");
        input.removeClass("valid-field");
        jq('input.find_installers').attr('disabled', 'disabled');
        jq('input.find_installers').addClass('fai-btn-gray');

    } else {
        jq(".fai.errorMessagepostcode").removeClass('show-error');
        input.addClass("valid-field");
        jq(input).after('<valid-input></valid-input>');
        input.removeClass("error");
    }

    Validate_FAIForm();
}

// function validate_address() {
//     var input = jq("input[type=text]");

//     var pCode = jq("#location_postcode").val().trim();
//     var hNumber = jq("#location_housenumber").val().trim();
//     var distance = jq('#enquiry-distance_installer_regression').val().trim();
//     var isPostalCodeValid = validate_postcode();

//     if (pCode.length > 0 && hNumber.length > 0 && distance.length > 0 && isPostalCodeValid) {
//         get_Address(pCode,hNumber);

//     }
//     else
//     {
//         input.removeClass("valid-field");
//         jq('input.find_installers').attr('disabled', 'disabled');
//         jq('input.find_installers').addClass('fai-btn-gray');
//         jq(".fai.errorMessage").removeClass('show-error');
//     }
// }

function save_preference() {
    jq("#aanvrag-link").click().removeClass("disabled").addClass('enabled');
}

function go_fai() {
    jq("#start-link").click();
}

function FAI_Submit(referrer) {
    //clear selected installers
    if(referrer == "start")
    {
        jq(".fai-filter input[type=radio]").prop('checked',false);
        if(jq(".installers-results-sec").children(".installer-item").each(function(){
            if(jq(this).hasClass("selected")){
                jq(this).find(".contact-installers").click();
            }
        }));
        Initialize_InstallerSelection(true);       
    }
  
    var pCode = jq("input[name=textInstallers]").val().replace(/\s/g,  '');
    var hNumber = jq("input[name=textHouseNo]").val().replace(/\s/g,  '');
    Validate_Address(pCode, hNumber, referrer);
}

function checkboxIsChecked(item) {
    var ischecked = jq(item).is(':checked');
    if (ischecked) {
        return true;
    } else {
        return false;
    }
}

// function validate_fai() {
//     var pCode = jq("input[name=textInstallers]").val()
//     var hNumber = jq("input[name=textHouseNo]").val();

//     if (pCode.length > 0 && hNumber.length > 0) {
//         jq('#find_installer_regression').removeAttr('disabled');
//     } else {
//         jq('#find_installer_regression').attr('disabled', 'disabled');
//     }
// }

function ProtoPaginateResetCurrent(){
    jq(".installer-pagination").children("li").each(function(){
        if(jq(this).hasClass("current")){
            jq(this).removeClass("current");
            var currentText = jq(this).text();
            var elementToAdd = '<a href="" data-targetpage="' + currentText-- + '">' + jq(this).text() + '</a>';
            jq(this).text("");
            jq(this).append(elementToAdd);
        }
        if(!jq(this).hasClass("disabled")){
            jq(this).css("display","");
        }
    });    
}

function ProtoPaginateNewCurrent(element, visiblePageNoCount){
    var parentElem = jq(element).parent();
    var numericVal = jq(parentElem).find("a:first-child").text();
    jq(parentElem).find("a:first-child").remove();
    jq(parentElem).text(numericVal);
    if(numericVal >= 2 + visiblePageNoCount){
        jq(".installer-pagination").find("li.pagination-number:first").hide();
    }
} 

function ProtoPaginatePrevNext(direction){
    var currentElem = null; 
    var newTarget = null;   
    var maxCount = 0;
    jq(".installer-pagination").children("li").each(function(){
        if(jq(this).hasClass("current")){
            currentElem = jq(this);
        }
        if(!jq(this).hasClass("pagination-previous") && !jq(this).hasClass("ellipsis") && !jq(this).hasClass("pagination-next")){
            maxCount++
        }
    });
    if(direction === "next"){
        if(currentElem.text() != maxCount){
            var nextElem = currentElem.next();
            newTarget = nextElem.find("a:first");
            ProtoPaginateResetCurrent();
            jq(nextElem).addClass("current");
        }
    }
    else if(direction === "prev"){
        if(currentElem.text() != jq(".installer-pagination").find("li.pagination-number:first").text()){
            var nextElem = currentElem.prev();
            newTarget = nextElem.find("a:first");
            ProtoPaginateResetCurrent();
            jq(nextElem).addClass("current");
        }
    }
    return newTarget;
}

function ProtoInitPaginate(){    
    if(IsProtoEnvironment()){
        var visiblePageNoCount = 1;
        var pager = new PaginationHandler(visiblePageNoCount);
        pager.RefinePagination();
        jq(".installer-pagination").trigger("installer-pagination-rendered");
        if(jq(".installer-pagination ").length > 0){       

            jq(".installer-pagination  .pagination-next a").on('click', function(event)
            {		
                var newTarget = ProtoPaginatePrevNext("next");
                pager.RefinePagination(jq(event.target));
                ProtoPaginateNewCurrent(newTarget, visiblePageNoCount);
                event.preventDefault();
            });
            jq(".installer-pagination  .pagination-previous a").on('click', function(event)
            {			
                var newTarget = ProtoPaginatePrevNext("prev");
                pager.RefinePagination(jq(event.target));
                ProtoPaginateNewCurrent(newTarget, visiblePageNoCount);
                event.preventDefault();
            });
            jq(".installer-pagination ").on('click',' .pagination-number a', function(event)
            {
                ProtoPaginateResetCurrent(visiblePageNoCount);
                jq(this).parent().addClass("current");     
                pager.RefinePagination(jq(event.target));
                ProtoPaginateNewCurrent(this, visiblePageNoCount);
                event.preventDefault();       
            });
        }
    }
}

function Validate_Address(pcode, houseNo, referrer) {
    var submitButton = 'input[type=button].find_installers';
    //Reference Format of API: https://geodata.nationaalgeoregister.nl/locatieserver/free?fq=postcode:3582DD&fq=huisnummer:21
    jq.ajax({
        type: 'GET',
        url: 'https://geodata.nationaalgeoregister.nl/locatieserver/free',
        data: "fq=postcode:" + pcode + "&fq=huisnummer:" + houseNo,
        dataType: 'json',
        success: function (data) {
            if (data.response.docs[0] == null) {
                jq(".fai.errorMessage").addClass('show-error');
                jq(submitButton).attr('disabled');
                jq(submitButton).addClass('fai-btn-gray');
                jq("input[type=text]").addClass("error");
                jq("input[type=text]").removeClass("valid-field");
                jq('valid-input').remove();
            } else {
                var completeAddress = data.response.docs[0].weergavenaam;
                jq(".location").html(completeAddress);
                jq(".location-form").html(completeAddress);
                jq(".fai.errorMessage").removeClass('show-error');
                jq("input[type=text]").addClass("valid-field");
                jq("input[type=text]").removeClass("error");
                jq(submitButton).removeAttr('disabled');
                jq(submitButton).removeClass('fai-btn-gray');
                if (referrer === "advies") {
                    Advies_toFAI();
                }

                if (jq("#selectie-link") && referrer === "start") {
                    jq("#selectie-link").removeClass("disabled").addClass('enabled');
                    Progressbar_EnableNavigation("selectie-link", true);
                    Progressbar_EnableNavigation("start-link", false);
                    ProtoInitPaginate();
                }
                else if (jq("#aanvraag-link") && referrer === "selectie") {
                    jq("#aanvraag-link").removeClass("disabled").addClass('enabled');
                    Progressbar_EnableNavigation("aanvraag-link", true);
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            jq(".fai.errorMessage").addClass('show-error');
            jq(submitButton).attr('disabled');
            jq(submitButton).addClass('fai-btn-gray');
            jq("input[type=text]").addClass("error");
            jq("input[type=text]").removeClass("valid-field");
            jq('valid-input').remove();
        }
    });
}

function save_address() {
    var pCode = jq("input[name=textInstallers]").val().replace(/\s/g,  '');
    var hNumber = jq("input[name=textHouseNo]").val().replace(/\s/g,  '');

    Validate_Address(pCode, hNumber);

    if (!jq('.installer-results input[type="checkbox"]').not(':checked').length >  0) {
        jq(".promo-fai a").addClass("fai-btn-gray");
    }
}


function validate_postcode() {
    var pCode = jq(Get_FAI_FieldByName('textInstallers')).val().trim();
    var regex = /^[1-9][0-9]{3} ?(?!sa|sd|ss)[a-z]{2}$/i;
    var isValid = regex.test(pCode);

    return isValid;

}

function Validate_ContactForm(form) {
    var submit = jq(form).find('.contactfrm_btn');
    EnableDisable_Element(submit, false)
    if (jq(form).validate().checkForm()) {
        EnableDisable_Element(submit, true)
    }
}

function EnableDisable_Element(element, isEnabled) {
    if (isEnabled) {
        jq(element).prop('disabled', false);
        jq(element).removeClass('fai-btn-gray');
    } else {
        jq(element).prop('disabled', 'disabled');
        jq(element).addClass('fai-btn-gray');
    }
}

function Get_FAI_FieldByName(name) {
    return jq('.find-an-installer [name="' + name + '"]')
}

function Toggle_TelNum() {
    if(!isMobile)
    {
        jq(".show-tel-num").attr("href", "javascript:;");
        jq(".show-tel-num").unbind();
        jq(".show-tel-num").on("click", function (e) {
            jq(this).find('.tel-num').toggle();
        });
    }
}

function Setup_InstallerResults(actionEvent) {
    //if in html, remove parameter value
    if (!IsProtoEnvironment()) {
        jq('.installers-results-container').on('installer-search-rendered', function () {
            Register_InstallerResults();
            Toggle_TelNum();
        });
    } else {
        Register_InstallerResults();
        Toggle_TelNum();
    }

    jq('.installer-pagination').on('installer-pagination-rendered', function () {
        Load_SelectedInstallers();
        Toggle_TelNum();
    });

}

function Register_InstallerResults() {
    jq(".contact-installers").click(function (event) {
        var installerGuid = jq(this).attr("data-installerguid");
        var currentSelectedInstallers = localStorage.getItem('selectedFaiInstallers');
        if (currentSelectedInstallers.split("&").length >= 3 && !jq(this).parent().parent().hasClass('selected')) {
            event.preventDefault();
        }
        if (checkboxIsChecked(jq(this)) && Check_SelectedInstaller(installerGuid, currentSelectedInstallers)) {
            jq(this).parent().parent().addClass('selected');
            var installerSelected = jq(this).parent().parent().parent();
            EnableDisable_Element('promo fai-a', true);
            if (checkboxIsChecked(jq(this))) {
                jq(".installers-results-confirm").append(installerSelected.clone());
                // var telNum = jq('.installers-results-confirm .show-tel-num');
                // var num = parseInt(jq(telNum).prop("id").match(/\d+/g), 10) + 1;
                // telNum.prop('id', 'tel-id' + num);
            }
            Store_SelectedInstaller(installerGuid, currentSelectedInstallers);
        } else {
            var origAttr = jq(this).attr("id");
            jq(this).parent().parent().removeClass('selected');
            // jq("#installer-results .contact-installers").each(function (index) {
            //resultAttr = "";
            jq(".installers-results-confirm .contact-installers").each(function (index) {
                var resultAttr = jq(this).attr("id");

                if (origAttr == resultAttr) {
                    jq(this).parent().parent().parent().fadeOut("slow").remove();
                    jq(this).attr('checked', false);
                }
            });
            // });

            if (jq('#installer-results input[type="checkbox"]:checked').length == 0) {
                jq(".promo-fai a").addClass("fai-btn-gray");
            }
            Remove_SelectedInstaller(installerGuid, currentSelectedInstallers);
        }

        if (Get_InstallerSelection() !== false) {
            EnableDisable_Element('.promo-fai a', true);
            jq("#aanvraag-link").removeClass("disabled").addClass('enabled');
            jq("#selectie-link").removeClass("disabled").addClass('enabled');
        } else {
            EnableDisable_Element('.promo-fai a', false);
            jq("#aanvraag-link").removeClass("enabled").addClass('disabled');
            jq("#selectie-link").removeClass("enabled").addClass('disabled');
        }
    });
}

function Load_SelectedInstallers() {
    var installers = Get_InstallerSelection();
    if (installers !== false) {
        installers.forEach(function (item) {
            var element = jq('.installers-results-container').find("[data-installerguid='" + item + "']");
            if (element) {
                var installerItem = jq(element).parents('.installer-item');
                if (installerItem) {
                    installerItem.addClass('selected');
                    EnableDisable_Element('.promo-fai a', true);
                }
            }
        })
    } else {
        jq('.installer-item.selected').find('.contact-installers').click();
        EnableDisable_Element('.promo-fai a', false);
    }
    jq('.installer-item').not('.selected').find('.contact-installers').attr('checked', false)
}

function  hideUrgencyField() {
    jq( "li" ).has( "label.VnUrgency" ).css( "display",  "none" );
}

function Get_ProgressbarReferrer(item){
    return jq(item).parents(".tab-panel-display").attr("id");
}

function Setup_FormValidations() {
    //find an installer contact form validation
    var submit = jq('#ContactForm').find('.contactfrm_btn');
    EnableDisable_Element(submit, false);
    jq('#ContactForm').on('blur keyup change', 'input', function (event) {
        Validate_ContactForm('#ContactForm');
    });

    jq('.contactfrm_btn').on('click', function () {
        jq('#ContactForm input').removeClass('valid');
    });

    jq('.find-an-installer select').prepend("<option value=''>selecteer</option>").val('');
    //validation needs to be refactored
    jq('.find-an-installer input[name="textHouseNo"]').on("keyup", function () {
        validate_Input(this);
    }).change();

    jq('.find-an-installer input[name="textInstallers"]').on("blur", function () {
        Validate_postalcode(this);
    }).change();

    jq('.find-an-installer select').on("change", function () {
        Validate_Select(this);
    }).change();

    jq('input[type=button].find_installers, a.btn-find-installers').not('.product-result #find_installer').on('click', function (event) {
        if(event){
            event.preventDefault();
        }
        FAI_Submit(Get_ProgressbarReferrer(this));
    });

    jq('.product-result #find_installer').on('click', function () {
        FAI_Submit("advies");
    });

    hideUrgencyField();    
    OnFilterSelect();
}

function OnFilterSelect() {
    jq('.installer-skills-radio-filter input[type=radio]').on('click', function () {
        Initialize_InstallerSelection(true);
        Load_SelectedInstallers();
        Toggle_TelNum();
    });
}

function IsProtoEnvironment()
{
    if(window.location.hostname === "localhost" || window.location.hostname === "bdr-remeha-proto.azurewebsites.net"){
        return true;
    }    
    return false;
}