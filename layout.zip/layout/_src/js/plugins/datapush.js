
var jq = jQuery.noConflict();

var prgsbar = jq(".progress-bar");

jq(document).ready(function () {
    var answerWithSq = [];
    var subquestCount = ""
    
    prgsbar.on('click',' .progress-bar-number.enabled', function(event)
    {
        jq.each(jq("input[type=radio]:checked"), function(i){
            answerWithSq = [];
            answerWithSq['event'] = "Ketelwijzer";
        });	
    });

    jq( document).on('click', ".main-choice-item input[type='radio']", function(){	
        var dataPush = [];
        var dataAnswerName = jq(this).attr("name"); 
        var dataWaarde = jq(this).closest('.main-choice-item').attr('data-waarde');
        var stepNumber = jq(".progress-bar .current").attr('aria-label');
        var totalSteps = jq(".progress-bar-number").length;
        var questionid = jq(this).attr("id");
        var currentQuestionId = jq(this).closest('.subquestion').attr("data-choice-match-id");
        var sq = jq(".find-the-right-boiler-container  .boiler-questions.active .subquestion-container").find(".subquestion[data-choice-match-id*='"+questionid+"']");
        var totalSubquestion  = jq(".boiler-questions.active .subquestion").length;
        

        if(totalSubquestion > 0)
        {
            jq(".boiler-questions.active .subquestion").addClass(stepNumber);
        }
        //to initialize the main question
        //1 click = evaluation
        if(sq.length > 0){	
            answerWithSq = [];	
            subquestCount = sq.length;
            answerWithSq['event'] = "Ketelwijzer";
            answerWithSq[dataAnswerName] = dataWaarde;
            
        }else{
            var flag = true;
            if(jq(this).closest('.active').hasClass("subquestion") &&  subquestCount > 0){				
                jq.each(jq(this).closest("."+ stepNumber +".subquestion"), function(i){ 
                    if(jq(this).find("input[type=radio]:checked").val()){
                        answerWithSq[dataAnswerName] = dataWaarde;
                        flag = false;                        
                    }
                   
                });


                if(flag == true){
                    answerWithSq["step"] = parseInt(stepNumber) - 1;
                    answerWithSq[dataAnswerName] = dataWaarde; 
                    dataPush = answerWithSq;
                    dataLayer.push(Object.assign({}, dataPush));

                }

            }else{
                dataPush['event'] = "Ketelwijzer";
                dataPush["step"] = stepNumber == totalSteps ? stepNumber: parseInt(stepNumber) - 1;			
                dataPush[dataAnswerName] = dataWaarde;
                dataLayer.push(Object.assign({}, dataPush));
            }
        }
    });

    jq( document).on('click', ".product-details input.share-send", function(){
        dataLayer.push({
            'event': 'Ketelwijzer',
            'category': 'advies doorsturen'
        });
    });

      
    jq( document).on('click', "input.find_installers", function(){
        var path = window.location.pathname;
        var source = "Productwijzer";
        var purpose = "Nieuw product";
       if(path.indexOf("installateur") > -1) {
            purpose = jq("ul.fai-search-purpose li input:checked + label").text().trim();
            source = "Find Installer";
        }
        dataLayer.push({
            'event': 'InstallateurVinden',
            'category': 'Installateurzoeken',
            'redeninstallateur': purpose,
            'page': source
        });
    });

    jq( document).on('click', "#ContactForm ul li input.contactfrm_btn", function(){
        var installers = "";
        var elements = jq("#aanvraag .installer-item.selected label");
        for (var i = 0; i < elements.length; i++) {
            installers += " | " +  elements[i].textContent;
        }
        dataLayer.push({
            'event': 'InstallateurVinden',
            'category': 'InstallateurAanvraag',
            'naaminstallateur': installers
         
        });
    });

    jq( document).on('click', "#ContactForm ul li input.clear_btn", function(){
        var installers = "";
        var elements = jq("#aanvraag .installer-item.selected label");
        for (var i = 0; i < elements.length; i++) {
            installers += " | " +  elements[i].textContent;
        }
        dataLayer.push({
            'event': 'InstallateurVinden',
            'category': 'InstallateurWissen',
            'naaminstallateur': installers         
        });
    });

});


	
	
	