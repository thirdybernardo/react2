var jq;
jq = jQuery.noConflict();
var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|windows phone/i.test(navigator.userAgent) ? true : false;
jq(document).ready(function () {

    jq(".subquestion-container input[type=radio]").click(function () {
        //scroll to next active subquestion
        var activeParent = jq(this).parents('.subquestion.active');
        if (activeParent.length > 0) {
            var nextSubq = activeParent.parent().nextAll().children('.subquestion.active');
            if (nextSubq.length > 0) {
                jq('html,body').animate({
                    scrollTop: nextSubq.offset().top
                }, 'slow');
            }
        }
    });

    //tooltip behavior for mobile devices
    if (isMobile) {
        jq('.tool-tip .tooltipbox').hide();
        jq('.tool-tip').on('click tap', function () {
            if (jq('.tool-tip .tooltipbox').is(":visible")) {
                jq('.tool-tip .tooltipbox').hide();
            } else {
                jq('.tool-tip .tooltipbox').show();
            }
        });
    }
    jq('#start-link').parent().addClass('onload-active');
    jq('.progress-bar-fai').attr('id','progress-tabs');
    
});

function Progressbar_EnableNavigation(progressTab, isAutoClick){
    jq(".progress-bar-fai li a#" + progressTab).unbind('click');
    if(jq(".progress-bar-fai li a#" + progressTab)){
        jq(".progress-bar-fai li a#" + progressTab).click(function (e) {
            var showIt = jq(this).attr('href');
            jq(".tab-panel").hide();
            jq(showIt).show();

            var thisParent = jq(this).parent();
            thisParent.addClass("onload-active is-active");
            thisParent.prev('li').addClass("is-still-active");
            thisParent.prevAll().removeClass("is-active");
            thisParent.next('li').removeClass("is-active onload-active");

            if (thisParent.is('.is-still-active')) {
                thisParent.removeClass('is-still-active')
            }
            if (thisParent.is('.onload-active')) {
                thisParent.prevAll().addClass("onload-active is-still-active");
            }
            if (thisParent.first()) {
                thisParent.removeClass('is-active')
                thisParent.nextAll('li').removeClass("onload-active");
            }

            Toggle_TelNum();

            e.preventDefault();
        });
        if(isAutoClick){
            jq(".progress-bar-fai li a#" + progressTab).click();
        }
    }
}