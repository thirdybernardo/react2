var Remeha = Remeha || {};
Remeha.Ketelwijzer = Remeha.Ketelwijzer || {};
Remeha.Ketelwijzer.Settings = Remeha.Ketelwijzer.Settings || {};
Remeha.Ketelwijzer.Settings.SitecoreUrl = "https://nld-remeha.bdrwebtest.com/";
Remeha.Ketelwijzer.Settings.ApiKey = "{EBB8066D-BCB0-4493-93F4-B646B7456703}";
Remeha.Ketelwijzer.Settings.Debug = true;
Remeha.Ketelwijzer.Settings.Local = false;