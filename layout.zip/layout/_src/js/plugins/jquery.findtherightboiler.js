var jq;
jq = jQuery.noConflict();
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer_1) {
        var Ketelwijzer = /** @class */ (function () {
            function Ketelwijzer(fabContainer, notifications) {
                var main = this;
                this.toolid = jq(fabContainer).attr('data-toolid');
                this.summaryPageUrl = jq(fabContainer).attr('data-summarypagelink');
                this.fabContainerJq = fabContainer;
                jq(notifications).each(function () {
                    if (jq(this).attr("data-toolid") == main.toolid) {
                        main.notificationContainerJq = jq(this);
                    }
                });
                this.ketelwijzerContext = new Remeha.Ketelwijzer.Contexts.KetelwijzerContext("/sitecore/content/NL/RemehaNL", this.toolid);
            }
            Ketelwijzer.Initialize = function (fabContainer, notifications) {
                var wijzerJq = jq(fabContainer);
                if (wijzerJq.length > 0) {
                    var ketelwijzer = new Ketelwijzer(wijzerJq, notifications);
                    ketelwijzer.Setup();
                    return ketelwijzer;
                }
                return null;
            };
            Ketelwijzer.prototype.Setup = function () {
                //jq(".find-the-right-boiler-container ul:first li:first").addClass("active");
                if (!Remeha.Sc.SitecoreContext.IsPageEditor) {
                    this.progressBar = new Remeha.Ketelwijzer.Components.ProgressBar(this.toolid, this.ketelwijzerContext);
                    this.progressBar.Setup();
                    this.questionairre = new Remeha.Ketelwijzer.Components.Questionairre(this.ketelwijzerContext, this.fabContainerJq);
                    this.questionairre.Setup();
                    this.questionairre.AddProgressBar(this.progressBar);
                    if (this.notificationContainerJq != null && this.notificationContainerJq != undefined) {
                        this.notification = new Remeha.Ketelwijzer.Components.Notification(this.notificationContainerJq, this.ketelwijzerContext, this.questionairre);
                        this.notification.Setup();
                    }
                    this.questionairre.SwitchToQuestionNr(0);
                }
            };
            return Ketelwijzer;
        }());
        Ketelwijzer_1.Ketelwijzer = Ketelwijzer;
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
jq(document).ready(function () {
    jq(".find-the-right-boiler-container").each(function () {
        var notifications = jq(".notify-result");
        var ketelwijzer = Remeha.Ketelwijzer.Ketelwijzer.Initialize(this, notifications);
    });
    jq(".revisit-form").each(function () {
        var questionairreReset = new Remeha.Ketelwijzer.Components.ResetQuestionairre(this);
    });
});
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Settings = /** @class */ (function () {
            function Settings() {
            }
            return Settings;
        }());
        Ketelwijzer.Settings = Settings;
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Components;
        (function (Components) {
            var Answer = /** @class */ (function () {
                function Answer(answerJq, question) {
                    this.answerJq = jq(answerJq);
                    this.question = question;
                    this.Setup();
                }
                Object.defineProperty(Answer.prototype, "Name", {
                    get: function () {
                        return this.answerName;
                    },
                    enumerable: true,
                    configurable: true
                });
                Answer.prototype.Setup = function () {
                    var main = this;
                    main.AssociatedSubquestion = main.answerJq.find("input[type='radio']").attr("id");
                    main.answerName = main.answerJq.find("input[type='radio']").attr("name");
                    main.Waarde = main.answerJq.attr('data-waarde');
                    if (main.answerJq.attr('data-calculatievraag') == '1') {
                        main.CalculatieVraag = true;
                    }
                    else {
                        main.CalculatieVraag = false;
                    }
                    jq(this.answerJq).find("input[type=radio]").click(function () {
                        main.ChoiceClick(this);
                    });
                };
                Answer.prototype.SetAsSelected = function () {
                    this.answerJq.find("input[type='radio']").prop("checked", true);
                };
                Answer.prototype.GetSaveableAnswer = function () {
                    var qa = new Remeha.Ketelwijzer.Models.QuestionAnswer();
                    qa.Answer = this.answerName;
                    qa.Choice = this.AssociatedSubquestion;
                    return qa;
                };
                Answer.prototype.ChoiceClick = function (choice) {
                    this.question.UpdateQuestion(this);
                };
                return Answer;
            }());
            Components.Answer = Answer;
        })(Components = Ketelwijzer.Components || (Ketelwijzer.Components = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Components;
        (function (Components) {
            var Notification = /** @class */ (function () {
                function Notification(notificationContainerJq, context, questionairre) {
                    this.notificationContainerJq = notificationContainerJq;
                    this.context = context;
                    this.questionairre = questionairre;
                }
                Notification.prototype.Setup = function () {
                    var answers = this.context.GetAnswers(this.questionairre);
                    var main = this;
                    if (answers == null || answers == undefined || this.context.Reset) {
                        this.HideNotification();
                    }
                    if (this.context.Reset) {
                        main.context.LoadCalculationProperties(answers);
                        main.questionairre.LoadAnswers(answers.Answers);
                    }
                    jq(this.notificationContainerJq).find('input.load-answer').click(function () {
                        main.context.LoadCalculationProperties(answers);
                        main.questionairre.LoadAnswers(answers.Answers);
                        main.HideNotification();
                    });
                    jq(this.notificationContainerJq).find('input.close-modal').click(function () {
                        main.context.CleanAnswers(main.questionairre);
                        main.HideNotification();
                    });
                };
                Notification.prototype.HideNotification = function () {
                    this.notificationContainerJq.hide();
                };
                return Notification;
            }());
            Components.Notification = Notification;
        })(Components = Ketelwijzer.Components || (Ketelwijzer.Components = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Components;
        (function (Components) {
            var ProgressBar = /** @class */ (function () {
                function ProgressBar(toolId, context) {
                    this.initialised = false;
                    this.progressBarJq = jq(".progress-bar[data-toolid='" + toolId + "']");
                    this.fabContainerJq = jq(".find-the-right-boiler-container[data-toolid='" + toolId + "']");
                    this.context = context;
                }
                ProgressBar.prototype.Setup = function () {
                    if (this.progressBarJq.length > 0) {
                        this.skip = 0;
                        this.maxSlide = jq(this.fabContainerJq).find("ul.questionnaire li.boiler-questions").length - 1;
                        if (this.maxSlide == 0) {
                            this.progressBarJq.hide();
                        }
                        this.progressBarJq.find(".progress-bar-number").remove();
                        for (var i = 0; i <= this.maxSlide; i++) {
                            if (i == this.skip) {
                                this.progressBarJq.find(".progress-bar-next").before(this.GeneratePageNumber("progress-bar-number current", i));
                            }
                            else {
                                this.progressBarJq.find(".progress-bar-next").before(this.GeneratePageNumber("progress-bar-number", i));
                            }
                        }
                        jq(".progress-bar-previous").attr("data-targetpage", "0");
                    }
                };
                ProgressBar.prototype.AddUpdateEvent = function (questionnaire) {
                    jq(this.progressBarJq).on('click', '.progress-bar-number.enabled', function () {
                        questionnaire.SwitchToQuestionNr(jq(this).attr('data-targetpage'));
                    });
                };
                ProgressBar.prototype.UpdatePageNumber = function (questionNr) {
                    var main = this;
                    jq(this.progressBarJq).find(".progress-bar-number.current").removeClass("current");
                    jq(this.progressBarJq).find(".progress-bar-number.enabled").removeClass("enabled");
                    jq(this.progressBarJq).find(".progress-bar-number").each(function () {
                        if (jq(this).attr('data-targetpage') == questionNr) {
                            jq(this).addClass("current");
                        }
                        else if (jq(this).attr('data-targetpage') <= main.context.maxPage) {
                            jq(this).addClass("enabled");
                        }
                    });
                };
                ProgressBar.prototype.GeneratePageNumber = function (className, count) {
                    return "<li class=\"" + className + "\" aria-label=\"" + (count + 1) + "\" data-targetpage=\"" + count + "\">" + (count + 1) + "</li>";
                };
                return ProgressBar;
            }());
            Components.ProgressBar = ProgressBar;
        })(Components = Ketelwijzer.Components || (Ketelwijzer.Components = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Components;
        (function (Components) {
            var Question = /** @class */ (function () {
                function Question(questionJq, context, questionairre, parentQuestion) {
                    this.questionJq = jq(questionJq);
                    this.context = context;
                    this.questionairre = questionairre;
                    this.answers = [];
                    this.subQuestions = [];
                    this.parentQuestion = parentQuestion;
                    this.hasAnswer = false;
                    this.choiceIds = [];
                    if (this.parentQuestion != null) {
                        var choiceValues = this.questionJq.attr("data-choice-match-id").split("|");
                        var main_1 = this;
                        choiceValues.forEach(function (element) {
                            if (!(!element || element.length === 0 || /^\s*$/.test(element))) {
                                main_1.choiceIds.push(element);
                            }
                        });
                    }
                    this.Setup();
                }
                Object.defineProperty(Question.prototype, "HasAnswer", {
                    get: function () {
                        return this.hasAnswer;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Question.prototype, "IsSubQuestion", {
                    get: function () {
                        return this.parentQuestion != null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Question.prototype.Setup = function () {
                    var question = this;
                    if (!this.IsSubQuestion) {
                        jq(question.questionJq).find(".choice-wrapper .main-choice-item").each(function () {
                            question.answers.push(new Components.Answer(this, question));
                        });
                    }
                    else {
                        jq(question.questionJq).find(".main-choice-item").each(function () {
                            question.answers.push(new Components.Answer(this, question));
                        });
                    }
                    jq(question.questionJq).find(".subquestion").each(function () {
                        var subq = new Question(this, question.context, question.questionairre, question);
                        question.subQuestions.push(subq);
                        subq.QuestionChanged(null);
                    });
                };
                Question.prototype.QuestionChanged = function (activeQuestion) {
                    if (activeQuestion == this) {
                        this.ShowQuestion();
                    }
                    else {
                        this.HideQuestion();
                    }
                };
                Question.prototype.ShowQuestion = function () {
                    this.questionJq.addClass("active");
                    this.questionJq.show();
                };
                Question.prototype.HideQuestion = function () {
                    this.questionJq.removeClass("active");
                    this.questionJq.hide();
                };
                Question.prototype.IsLinkedToChoice = function (choiceId) {
                    return this.choiceIds.indexOf(choiceId) >= 0;
                };
                Question.prototype.SubquestionAnswered = function () {
                    var question = this;
                    if (this.parentQuestion != null) {
                        this.parentQuestion.SubquestionAnswered();
                        return;
                    }
                    var subquestionsAnswered = this.SubquestionsAnswered;
                    if (subquestionsAnswered) {
                        this.questionairre.UpdateQuestion(question);
                    }
                };
                Object.defineProperty(Question.prototype, "SubquestionsAnswered", {
                    get: function () {
                        var subquestionsAnswered = true;
                        var question = this;
                        this.subQuestions.forEach(function (element) {
                            if (element.IsLinkedToChoice(question.selectedAnswer.AssociatedSubquestion)) {
                                subquestionsAnswered = subquestionsAnswered && element.hasAnswer;
                            }
                        });
                        return subquestionsAnswered;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Question.prototype, "HasSubquestions", {
                    get: function () {
                        return this.subQuestions != undefined && this.subQuestions.length > 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                Question.prototype.LoadAnswers = function (answers) {
                    var _this = this;
                    var main = this;
                    this.answers.forEach(function (element) {
                        var answer = answers.filter(function (x) { return x.Answer == element.Name && x.Choice == element.AssociatedSubquestion; });
                        if (answer.length > 0) {
                            main.selectedAnswer = element;
                            main.hasAnswer = true;
                            element.SetAsSelected();
                            //setup subquestions
                            // let linkedSubquestion : boolean = false;
                            if (_this.subQuestions.length > 0) {
                                _this.subQuestions.forEach(function (subquestion) {
                                    subquestion.CleanAnswer();
                                    if (subquestion.IsLinkedToChoice(element.AssociatedSubquestion)) {
                                        subquestion.ShowQuestion();
                                    }
                                    subquestion.LoadAnswers(answers);
                                    // linkedSubquestion = linkedSubquestion || subquestion.IsLinkedToChoice(element.AssociatedSubquestion);
                                });
                            }
                        }
                    });
                };
                Question.prototype.GetAnswers = function () {
                    var answers = [];
                    if (this.HasAnswer) {
                        answers.push(this.selectedAnswer.GetSaveableAnswer());
                        this.subQuestions.forEach(function (element) {
                            var subAnswers = element.GetAnswers();
                            answers = answers.concat(subAnswers);
                        });
                    }
                    return answers;
                };
                Question.prototype.CleanAnswer = function () {
                    this.HideQuestion();
                    this.selectedAnswer = null;
                    this.hasAnswer = false;
                    jq(this.questionJq).find("input[type=radio]:checked").prop('checked', false);
                };
                Question.prototype.UpdateQuestion = function (answer) {
                    var question = this;
                    var linkedSubquestion = false;
                    if (this.subQuestions.length > 0) {
                        this.subQuestions.forEach(function (element) {
                            element.CleanAnswer();
                            if (element.IsLinkedToChoice(answer.AssociatedSubquestion)) {
                                element.ShowQuestion();
                            }
                            linkedSubquestion = linkedSubquestion || element.IsLinkedToChoice(answer.AssociatedSubquestion);
                        });
                        if (linkedSubquestion) {
                            jq('html,body').animate({
                                scrollTop: jq(question.questionJq).find('.subquestion-container').offset().top
                            }, 'slow');
                        }
                    }
                    this.selectedAnswer = answer;
                    this.hasAnswer = true;
                    this.context.ProcessQuestionAnswer(answer);
                    this.context.SaveAnswers(this.questionairre);
                    if (this.parentQuestion != null) {
                        this.parentQuestion.SubquestionAnswered();
                    }
                    else if (!linkedSubquestion) {
                        this.questionairre.UpdateQuestion(this);
                    }
                };
                return Question;
            }());
            Components.Question = Question;
        })(Components = Ketelwijzer.Components || (Ketelwijzer.Components = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Components;
        (function (Components) {
            var Questionairre = /** @class */ (function () {
                function Questionairre(ketelwijzerContext, fabContainer) {
                    this.ketelwijzerContext = ketelwijzerContext;
                    this.fabContainerJq = fabContainer;
                    this.questionairreJq = fabContainer.find(".questionnaire");
                    this.questions = [];
                }
                Questionairre.prototype.AddProgressBar = function (progressBar) {
                    var main = this;
                    this.progressBar = progressBar;
                    this.progressBar.AddUpdateEvent(this);
                    jq(main.questionairreJq).on("question-switch", function (evt, questionNr) {
                        main.progressBar.UpdatePageNumber(questionNr);
                    });
                };
                Questionairre.prototype.GetAnswers = function () {
                    var answers = [];
                    this.questions.forEach(function (element) {
                        var qAnswers = element.GetAnswers();
                        answers = answers.concat(qAnswers);
                    });
                    return answers;
                };
                Questionairre.prototype.LoadAnswers = function (answers) {
                    this.questions.forEach(function (element) {
                        element.LoadAnswers(answers);
                    });
                    var lastAnsweredQuestion = 0;
                    for (var index = 0; index < this.questions.length; index++) {
                        var element = this.questions[index];
                        if (element.HasAnswer) {
                            if (element.HasSubquestions) {
                                if (element.SubquestionsAnswered) {
                                    lastAnsweredQuestion = index;
                                }
                            }
                            else {
                                lastAnsweredQuestion = index;
                            }
                        }
                    }
                    if (this.ketelwijzerContext.Reset) {
                        this.UpdateQuestionWhenReset(this.questions[lastAnsweredQuestion]);
                    }
                    else {
                        this.UpdateQuestion(this.questions[lastAnsweredQuestion]);
                    }
                };
                Questionairre.prototype.Setup = function () {
                    var questionairre = this;
                    this.questionairreJq.find(".boiler-questions:nth-child(1n+2)").hide();
                    this.questionairreJq.find(".boiler-questions").each(function () {
                        var question = new Components.Question(this, questionairre.ketelwijzerContext, questionairre, null);
                        questionairre.questions.push(question);
                        jq(questionairre.questionairreJq).on("question-switch", function (evt, questionNr) {
                            question.QuestionChanged(questionairre.questions[questionNr]);
                        });
                    });
                };
                Questionairre.prototype.UpdateQuestionWhenReset = function (question) {
                    var questionNr = this.questions.indexOf(question);
                    this.ketelwijzerContext.UpdatePageNumber(questionNr + 1);
                    jq(this.questionairreJq).trigger("question-switch", [0]);
                };
                Questionairre.prototype.UpdateQuestion = function (question) {
                    var questionNr = this.questions.indexOf(question);
                    if (questionNr < (this.questions.length - 1)) {
                        this.ketelwijzerContext.UpdatePageNumber(questionNr + 1);
                        jq(this.questionairreJq).trigger("question-switch", [questionNr + 1]);
                        //when switching question, scroll to main question
                        jq('html,body').animate({
                            scrollTop: jq(this.questionairreJq).find('.main-question').offset().top
                        }, 'slow');
                    }
                    else {
                        var advice = this.ketelwijzerContext.GenerateProcessKetelwijzerResult();
                        if (advice == null) {
                            var currentUrl = document.location.href;
                            var to = currentUrl.lastIndexOf('/');
                            to = to == -1 ? currentUrl.length : to + 1;
                            currentUrl = currentUrl.substring(0, to);
                            window.location.href = currentUrl + "geen-advies";
                        }
                        else {
                            var adviceurl = this.ketelwijzerContext.GenerateAdviceUrl(advice.AdvicePage);
                            window.location.href = adviceurl;
                        }
                    }
                };
                Questionairre.prototype.SwitchToQuestionNr = function (index) {
                    this.ketelwijzerContext.UpdatePageNumber(index);
                    jq(this.questionairreJq).trigger("question-switch", [index]);
                };
                return Questionairre;
            }());
            Components.Questionairre = Questionairre;
        })(Components = Ketelwijzer.Components || (Ketelwijzer.Components = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Components;
        (function (Components) {
            var ResetQuestionairre = /** @class */ (function () {
                function ResetQuestionairre(resetLinkJq) {
                    this.targetUrl = jq(resetLinkJq).attr("data-revisit");
                    var main = this;
                    jq(resetLinkJq).find("input[type='button']").click(function () {
                        window.location.href = main.targetUrl + "?reset=1";
                    });
                }
                return ResetQuestionairre;
            }());
            Components.ResetQuestionairre = ResetQuestionairre;
        })(Components = Ketelwijzer.Components || (Ketelwijzer.Components = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var BoilerMatrix = /** @class */ (function () {
                function BoilerMatrix() {
                }
                return BoilerMatrix;
            }());
            Models.BoilerMatrix = BoilerMatrix;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var BoilerMatrixEntry = /** @class */ (function () {
                function BoilerMatrixEntry() {
                }
                return BoilerMatrixEntry;
            }());
            Models.BoilerMatrixEntry = BoilerMatrixEntry;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var CvIsolatieModel = /** @class */ (function () {
                function CvIsolatieModel() {
                }
                return CvIsolatieModel;
            }());
            Models.CvIsolatieModel = CvIsolatieModel;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var CvMatrixModel = /** @class */ (function () {
                function CvMatrixModel() {
                }
                return CvMatrixModel;
            }());
            Models.CvMatrixModel = CvMatrixModel;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var CwMatrixMappingModel = /** @class */ (function () {
                function CwMatrixMappingModel() {
                }
                return CwMatrixMappingModel;
            }());
            Models.CwMatrixMappingModel = CwMatrixMappingModel;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var CwMatrixModel = /** @class */ (function () {
                function CwMatrixModel() {
                }
                return CwMatrixModel;
            }());
            Models.CwMatrixModel = CwMatrixModel;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var KetelwijzerContextSettings = /** @class */ (function () {
                function KetelwijzerContextSettings() {
                }
                return KetelwijzerContextSettings;
            }());
            Models.KetelwijzerContextSettings = KetelwijzerContextSettings;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var QuestionAnswer = /** @class */ (function () {
                function QuestionAnswer() {
                }
                return QuestionAnswer;
            }());
            Models.QuestionAnswer = QuestionAnswer;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Models;
        (function (Models) {
            var SavedQueststionaire = /** @class */ (function () {
                function SavedQueststionaire() {
                }
                return SavedQueststionaire;
            }());
            Models.SavedQueststionaire = SavedQueststionaire;
        })(Models = Ketelwijzer.Models || (Ketelwijzer.Models = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Services;
        (function (Services) {
            var PatternService = /** @class */ (function () {
                function PatternService() {
                }
                return PatternService;
            }());
            Services.PatternService = PatternService;
        })(Services = Ketelwijzer.Services || (Ketelwijzer.Services = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Services;
        (function (Services) {
            var SitecoreService = /** @class */ (function () {
                function SitecoreService(basePath) {
                    this.boilerMatrixes = {};
                    this.basePath = basePath;
                }
                SitecoreService.prototype.GetItemList = function (path) {
                    return {};
                };
                SitecoreService.prototype.GetBoilerMatrix = function (klasse) {
                    if (!this.boilerMatrixes[klasse]) {
                        var main_2 = this;
                        jq.ajax({
                            url: Remeha.Ketelwijzer.Settings.SitecoreUrl
                                + "sitecore/api/ssc/aggregate/content/Items('" + this.basePath + "/Ketelwijzer/Boiler Matrix/" + klasse + "')/Children?sc_apikey=" + Remeha.Ketelwijzer.Settings.ApiKey + "&language=nl-NL&$expand=Fields($select=Name,Value)&$select=Id,Name",
                            async: false
                        }).done(function (data) {
                            var boilerMatrix = new Remeha.Ketelwijzer.Models.BoilerMatrix();
                            boilerMatrix.Boilers = [];
                            data.value.forEach(function (element) {
                                var matrixEntry = new Remeha.Ketelwijzer.Models.BoilerMatrixEntry();
                                matrixEntry.Name = element.Name;
                                element.Fields.forEach(function (field) {
                                    if (field.Name == "output") {
                                        matrixEntry.Output = +field.Value;
                                    }
                                    if (field.Name == "price rank") {
                                        matrixEntry.PriceRank = +field.Value;
                                    }
                                    if (field.Name == "Sustainable rank") {
                                        matrixEntry.SustainableRank = +field.Value;
                                    }
                                    if (field.Name == "Advice") {
                                        matrixEntry.AdvicePage = field.Value;
                                    }
                                    if (field.Name == "comfort rank") {
                                        matrixEntry.ComfortRank = +field.Value;
                                    }
                                });
                                boilerMatrix.Boilers.push(matrixEntry);
                            });
                            main_2.boilerMatrixes[klasse] = boilerMatrix;
                        });
                    }
                    return this.boilerMatrixes[klasse];
                };
                SitecoreService.prototype.GetBoilerAdviceName = function (itemId) {
                    var itemName;
                    jq.ajax({
                        url: Remeha.Ketelwijzer.Settings.SitecoreUrl
                            + "sitecore/api/ssc/aggregate/content/Items('" + itemId + "')?sc_apikey=" + Remeha.Ketelwijzer.Settings.ApiKey + "&language=nl-NL&$select=Id,Name",
                        async: false
                    }).done(function (data) {
                        itemName = data.Name;
                    });
                    return itemName;
                };
                SitecoreService.prototype.GetCvMatrix = function (bouwjaar, housetype) {
                    var matrix;
                    jq.ajax({
                        url: Remeha.Ketelwijzer.Settings.SitecoreUrl
                            + "sitecore/api/ssc/aggregate/content/Items('" + this.basePath + "/Ketelwijzer/CV%20Vermogen/" + bouwjaar + "/" + housetype + "')?sc_apikey=" + Remeha.Ketelwijzer.Settings.ApiKey + "&language=nl-NL&$expand=Fields($select=Name,Value)&$select=Id,Name",
                        async: false
                    }).done(function (data) {
                        matrix = data;
                    });
                    return matrix;
                };
                SitecoreService.prototype.GetCwMatrix = function () {
                    if (this.cwMatrix) {
                        return this.cwMatrix;
                    }
                    var matrix;
                    jq.ajax({
                        url: Remeha.Ketelwijzer.Settings.SitecoreUrl
                            + "sitecore/api/ssc/aggregate/content/Items('" + this.basePath + "/Ketelwijzer/CW')/Children?sc_apikey=" + Remeha.Ketelwijzer.Settings.ApiKey + "&language=nl-NL&$expand=Fields($select=Name,Value)&$select=Id,Name",
                        async: false
                    }).done(function (data) {
                        matrix = new Remeha.Ketelwijzer.Models.CwMatrixModel();
                        matrix.Mappings = [];
                        data.value.forEach(function (element) {
                            var mapping = new Remeha.Ketelwijzer.Models.CwMatrixMappingModel();
                            element.Fields.forEach(function (field) {
                                if (field.Name == "Points From") {
                                    mapping.From = +field.Value;
                                }
                                if (field.Name == "Klasse") {
                                    mapping.Klasse = field.Value;
                                }
                                if (field.Name == "Points To") {
                                    mapping.To = +field.Value;
                                }
                            });
                            matrix.Mappings.push(mapping);
                        });
                    });
                    this.cwMatrix = matrix;
                    return matrix;
                };
                return SitecoreService;
            }());
            Services.SitecoreService = SitecoreService;
        })(Services = Ketelwijzer.Services || (Ketelwijzer.Services = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Sc;
    (function (Sc) {
        var SitecoreContext = /** @class */ (function () {
            function SitecoreContext() {
            }
            Object.defineProperty(SitecoreContext, "IsPageEditor", {
                get: function () {
                    if (typeof Sitecore == "undefined" || Sitecore == null) {
                        return false;
                    }
                    if (typeof Sitecore.PageModes == "undefined" || Sitecore.PageModes == null) {
                        return false;
                    }
                    return Sitecore.PageModes.PageEditor != null;
                },
                enumerable: true,
                configurable: true
            });
            return SitecoreContext;
        }());
        Sc.SitecoreContext = SitecoreContext;
    })(Sc = Remeha.Sc || (Remeha.Sc = {}));
})(Remeha || (Remeha = {}));
var Remeha;
(function (Remeha) {
    var Ketelwijzer;
    (function (Ketelwijzer) {
        var Contexts;
        (function (Contexts) {
            var KetelwijzerContext = /** @class */ (function () {
                function KetelwijzerContext(basePath, toolId) {
                    this.sitecoreService = new Remeha.Ketelwijzer.Services.SitecoreService(basePath);
                    this.basePath = basePath;
                    this.contextSettings = new Remeha.Ketelwijzer.Models.KetelwijzerContextSettings();
                    this.contextSettings.HasResults = true;
                    this.maxPage = 0;
                    this.toolId = toolId;
                }
                KetelwijzerContext.prototype.GetProductMatrix = function () {
                    return this.sitecoreService.GetItemList(this.basePath + "/Ketelwijzer/Matrix");
                };
                KetelwijzerContext.prototype.GetBoilerChoices = function () {
                    return {};
                };
                KetelwijzerContext.prototype.UpdatePageNumber = function (pageNr) {
                    if (pageNr > this.maxPage) {
                        this.maxPage = pageNr;
                    }
                };
                KetelwijzerContext.prototype.GenerateAdviceUrl = function (adviceId) {
                    var name = this.sitecoreService.GetBoilerAdviceName(adviceId);
                    var currentUrl = document.location.href;
                    var to = currentUrl.lastIndexOf('/');
                    to = to == -1 ? currentUrl.length : to + 1;
                    currentUrl = currentUrl.substring(0, to);
                    var newUrl = currentUrl + this.cwKlasse + "/" + name.replace(" ", "-");
                    if (Remeha.Ketelwijzer.Settings.Local) {
                        newUrl = currentUrl + "ketelwijzeradvies.html";
                    }
                    if (Remeha.Ketelwijzer.Settings.Debug) {
                        console.log("url : " + newUrl);
                    }
                    return newUrl;
                };
                KetelwijzerContext.prototype.GenerateProcessKetelwijzerResult = function () {
                    var boilerMatrix = this.sitecoreService.GetBoilerMatrix(this.cwKlasse);
                    if (this.vermogen > 40) {
                        return null;
                    }
                    switch (this.adviceImportance) {
                        case "Comfort":
                            return this.GetHighestRankingAdvice("ComfortRank", boilerMatrix, this.comfortScore);
                        case "Prijs":
                            return this.GetHighestRankingAdvice("PriceRank", boilerMatrix, this.comfortScore);
                        case "Duurzaamheid":
                            return this.GetHighestRankingAdvice("SustainableRank", boilerMatrix, this.comfortScore);
                    }
                };
                KetelwijzerContext.prototype.GetHighestRankingAdvice = function (rank, boilerMatrix, comfortScore) {
                    var _this = this;
                    var highestRankingAdvice = new Remeha.Ketelwijzer.Models.BoilerMatrixEntry();
                    highestRankingAdvice[rank] = 99;
                    var matchingBoilers = boilerMatrix.Boilers.filter(function (x) { return x.Output >= _this.vermogen; });
                    if (matchingBoilers.length == 0) {
                        return this.GetHighestRankingAdvice(rank, this.GetHigherComfortValueBoilerMatrix(comfortScore), comfortScore + 1);
                    }
                    matchingBoilers.forEach(function (element) {
                        if (highestRankingAdvice[rank] > element[rank]) {
                            highestRankingAdvice = element;
                        }
                    });
                    if (Remeha.Ketelwijzer.Settings.Debug) {
                        console.log("best advice:" + highestRankingAdvice.Name);
                    }
                    return highestRankingAdvice;
                };
                KetelwijzerContext.prototype.GetHigherComfortValueBoilerMatrix = function (comfortScore) {
                    var matrix = this.sitecoreService.GetCwMatrix();
                    var mapping = matrix.Mappings.filter(function (x) { return x.From <= (comfortScore + 1) && x.To >= (comfortScore + 1); });
                    if (mapping.length > 0) {
                        this.cwKlasse = mapping[0].Klasse;
                    }
                    var boilerMatrix = this.sitecoreService.GetBoilerMatrix(this.cwKlasse);
                    return boilerMatrix;
                };
                KetelwijzerContext.prototype.ProcessQuestionAnswer = function (answer) {
                    if (answer.CalculatieVraag) {
                        switch (answer.Name) {
                            case "woninginhoud":
                                this.inhoudwaarde = +answer.Waarde;
                                this.CalculateVermogen();
                                break;
                            case "bouwjaar":
                                this.bouwjaar = +answer.Waarde;
                                this.CalculateVermogen();
                                break;
                            case "soortwoning":
                                this.woningtype = answer.Waarde;
                                this.CalculateVermogen();
                                break;
                            case "woningisolatie":
                                this.isolatie = answer.Waarde;
                                this.CalculateVermogen();
                                break;
                            case "warmwaterbadkamer":
                                this.situationChoice = answer.Waarde;
                                this.CalculateComfort();
                                break;
                            case "soortdouche":
                                this.showerPoints = +answer.Waarde;
                                this.CalculateComfort();
                                break;
                            case "soortbad":
                                this.bathPoints = +answer.Waarde;
                                this.CalculateComfort();
                                break;
                            case "gelijktijdigdouchebad":
                                this.bathShowerSameTime = answer.Waarde == "true";
                                this.CalculateComfort();
                                break;
                            case "gelijktijdigbadkamerkeuken":
                                this.waterAtSameTimePoints = +answer.Waarde;
                                this.CalculateComfort();
                                break;
                            case "aankoopcriteria":
                                this.adviceImportance = answer.Waarde;
                                break;
                        }
                    }
                };
                KetelwijzerContext.prototype.CalculateComfort = function () {
                    var _this = this;
                    switch (this.situationChoice) {
                        case "a":
                            if (this.showerPoints != undefined && this.waterAtSameTimePoints != undefined) {
                                this.comfortScore = this.showerPoints + this.waterAtSameTimePoints;
                            }
                            break;
                        case "b":
                            if (this.showerPoints != undefined && this.bathPoints != undefined && this.waterAtSameTimePoints != undefined) {
                                var bathshowerPoints = void 0;
                                if (this.showerPoints >= this.bathPoints) {
                                    bathshowerPoints = this.showerPoints;
                                }
                                else {
                                    bathshowerPoints = this.bathPoints;
                                }
                                this.comfortScore = bathshowerPoints + this.waterAtSameTimePoints;
                            }
                            break;
                        case "c":
                        case "d":
                            if (this.bathShowerSameTime != undefined && this.showerPoints != undefined && this.bathPoints != undefined && this.waterAtSameTimePoints != undefined) {
                                var cBasePoints = void 0;
                                if (this.bathShowerSameTime) {
                                    cBasePoints = this.showerPoints + this.bathPoints;
                                }
                                else {
                                    if (this.showerPoints >= this.bathPoints) {
                                        cBasePoints = this.showerPoints;
                                    }
                                    else {
                                        cBasePoints = this.bathPoints;
                                    }
                                }
                                this.comfortScore = cBasePoints + this.waterAtSameTimePoints;
                            }
                            break;
                    }
                    if (this.comfortScore) {
                        var matrix = this.sitecoreService.GetCwMatrix();
                        var mapping = matrix.Mappings.filter(function (x) { return x.From <= _this.comfortScore && x.To >= _this.comfortScore; });
                        if (mapping.length > 0) {
                            this.cwKlasse = mapping[0].Klasse;
                        }
                    }
                    if (Remeha.Ketelwijzer.Settings.Debug) {
                        console.log("comfort score : " + this.comfortScore);
                        console.log("cw klasse : " + this.cwKlasse);
                    }
                };
                KetelwijzerContext.prototype.CalculateVermogen = function () {
                    this.rekenfactor = this.CalculateRekenfactor();
                    if (this.rekenfactor > 0) {
                        this.vermogen = (this.inhoudwaarde * this.rekenfactor) / 1000;
                        if (Remeha.Ketelwijzer.Settings.Debug) {
                            console.log("inhoud : " + this.inhoudwaarde);
                            console.log("factor : " + this.rekenfactor);
                            console.log("vermogen : " + this.vermogen);
                        }
                    }
                };
                KetelwijzerContext.prototype.CalculateRekenfactor = function () {
                    var _this = this;
                    switch (this.bouwjaar) {
                        case 1992: return 20;
                        case 1991: return 30;
                        default:
                            if (this.bouwjaar != undefined && this.woningtype != undefined) {
                                var matrix = this.sitecoreService.GetCvMatrix(this.bouwjaar, this.woningtype);
                                var matches = matrix.Fields.filter(function (x) { return x.Name == _this.isolatie; });
                                if (matches.length > 0) {
                                    return +matches[0].Value;
                                }
                            }
                            return 0;
                    }
                };
                KetelwijzerContext.prototype.LoadCalculationProperties = function (answers) {
                    this.bouwjaar = answers.BouwJaar;
                    this.inhoudwaarde = answers.InhoudWaarde;
                    this.isolatie = answers.Isolatie;
                    this.rekenfactor = answers.RekenFactor;
                    this.vermogen = answers.Vermogen;
                    this.woningtype = answers.WoningType;
                    this.situationChoice = answers.SituationChoice;
                    this.showerPoints = answers.ShowerPoints;
                    this.bathPoints = answers.BathPoints;
                    this.waterAtSameTimePoints = answers.WaterAtSameTimePoints;
                    this.bathShowerSameTime = answers.BathShowerSameTime;
                    this.comfortScore = answers.ComfortScore;
                    this.cwKlasse = answers.CwKlasse;
                    this.adviceImportance = answers.AdviceImportance;
                };
                KetelwijzerContext.prototype.SaveAnswers = function (questionairre) {
                    var answers = questionairre.GetAnswers();
                    var savedQuestionare;
                    savedQuestionare = new Remeha.Ketelwijzer.Models.SavedQueststionaire();
                    savedQuestionare.Answers = answers;
                    savedQuestionare.BouwJaar = this.bouwjaar;
                    savedQuestionare.InhoudWaarde = this.inhoudwaarde;
                    savedQuestionare.Isolatie = this.isolatie;
                    savedQuestionare.RekenFactor = this.rekenfactor;
                    savedQuestionare.Vermogen = this.vermogen;
                    savedQuestionare.WoningType = this.woningtype;
                    savedQuestionare.SituationChoice = this.situationChoice;
                    savedQuestionare.ShowerPoints = this.showerPoints;
                    savedQuestionare.BathPoints = this.bathPoints;
                    savedQuestionare.WaterAtSameTimePoints = this.waterAtSameTimePoints;
                    savedQuestionare.BathShowerSameTime = this.bathShowerSameTime;
                    savedQuestionare.ComfortScore = this.comfortScore;
                    savedQuestionare.CwKlasse = this.cwKlasse;
                    savedQuestionare.AdviceImportance = this.adviceImportance;
                    if (Remeha.Ketelwijzer.Settings.Debug) {
                        console.log("saving choices");
                        console.log(savedQuestionare);
                    }
                    var choices = JSON.stringify(savedQuestionare);
                    choices = window.btoa(choices);
                    this.setCookie("BoilerChoices_" + this.toolId, choices, 30);
                };
                KetelwijzerContext.prototype.CleanAnswers = function (questionairre) {
                    this.setCookie("BoilerChoices_" + this.toolId, "", -30);
                };
                KetelwijzerContext.prototype.GetAnswers = function (questionairre) {
                    var choices = window.atob(this.getCookie("BoilerChoices_" + this.toolId));
                    if (!choices) {
                        return null;
                    }
                    var answers = JSON.parse(choices);
                    if (Remeha.Ketelwijzer.Settings.Debug) {
                        console.log("gettings choices");
                        console.log(answers);
                    }
                    return answers;
                };
                Object.defineProperty(KetelwijzerContext.prototype, "Reset", {
                    get: function () {
                        return this.GetQueryParameterByName("reset") == "1";
                    },
                    enumerable: true,
                    configurable: true
                });
                KetelwijzerContext.prototype.GetQueryParameterByName = function (name) {
                    var url = window.location.href;
                    name = name.replace(/[\[\]]/g, "\\$&");
                    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"), results = regex.exec(url);
                    if (!results)
                        return null;
                    if (!results[2])
                        return '';
                    return decodeURIComponent(results[2].replace(/\+/g, " "));
                };
                KetelwijzerContext.prototype.setCookie = function (cookieName, cookie, exdays) {
                    var d = new Date();
                    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                    var expires = "expires=" + d.toUTCString();
                    document.cookie = cookieName + "=" + cookie + ";" + expires + ";path=/";
                };
                KetelwijzerContext.prototype.getCookie = function (cookieName) {
                    var name = cookieName + "=";
                    var decodedCookie = decodeURIComponent(document.cookie);
                    var ca = decodedCookie.split(';');
                    for (var i = 0; i < ca.length; i++) {
                        var c = ca[i];
                        while (c.charAt(0) == ' ') {
                            c = c.substring(1);
                        }
                        if (c.indexOf(name) == 0) {
                            return c.substring(name.length, c.length);
                        }
                    }
                    return "";
                };
                Object.defineProperty(KetelwijzerContext.prototype, "HasResults", {
                    get: function () {
                        return this.contextSettings.HasResults;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KetelwijzerContext, "Instance", {
                    get: function () {
                        if (this.context == undefined || this.context == null) {
                            this.context = new KetelwijzerContext("/sitecore/content/NL/RemehaNL", "");
                        }
                        return this.context;
                    },
                    enumerable: true,
                    configurable: true
                });
                return KetelwijzerContext;
            }());
            Contexts.KetelwijzerContext = KetelwijzerContext;
        })(Contexts = Ketelwijzer.Contexts || (Ketelwijzer.Contexts = {}));
    })(Ketelwijzer = Remeha.Ketelwijzer || (Remeha.Ketelwijzer = {}));
})(Remeha || (Remeha = {}));
//# sourceMappingURL=jquery.findtherightboiler.js.map