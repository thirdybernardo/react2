 jQuery.noConflict()(function($){
    $(document).ready(function(){

		function createCookie() {
		        var expires = "; expires=Fri, 31 Dec 9999 23:59:59 GMT";
		        document.cookie = "bdrCookie=AcceptedCookie" + expires + "; path=/";
		} 

		function getCookie(name) {
		    var cookie = document.cookie;
		    var prefix = name + "=";
		    var begin = cookie.indexOf("; " + prefix);
		    if (begin == -1) {
		        begin = cookie.indexOf(prefix);
		        if (begin != 0) return null;
		    } else {
		        begin += 2;
		        var end = document.cookie.indexOf(";", begin);
		        if (end == -1) {
		        end = cookie.length;
		        }
		    }
		    return unescape(cookie.substring(begin + prefix.length, end));
		} 
		function isPageEditor() {
			if (typeof Sitecore == "undefined" || Sitecore == null) {
				return false;
			}
			if (typeof Sitecore.PageModes == "undefined" || Sitecore.PageModes == null) {
				return false;
			}
			return Sitecore.PageModes.PageEditor != null;
		}

		
		var checkCookie = getCookie("bdrCookie");

		if (checkCookie == null) {
			$(".cookie-content").show();
			if(!isPageEditor()) {
				$(".accept-cookie").click(function(){
					createCookie();
					$(".cookie-content").hide();
				});
			}

		} else {
		    $(".cookie-content").hide();
		}
    });

});