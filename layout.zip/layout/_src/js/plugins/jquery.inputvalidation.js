﻿function submitSearch() {
    var textSearch = document.getElementById("textSearch");
    
    if ($(textSearch).val().match(/</g) || $(textSearch).val().match(/>/g)) {
        var htmlReplace = textSearch.value.replace(/</g, "").replace(/>/g, "");
        textSearch.value = htmlReplace;
        event.preventDefault();
        return false;
    }
    else {
        return true;
        $('#submitForm').submit();
    }
}