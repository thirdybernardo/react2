	
	var jq;

	jq = jQuery.noConflict();

	jQuery.validator.addMethod('multiEmail', function(value, element) {
		if (this.optional(element)) {
			return true;
		} else {
			var valid = true;
			var pattern = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i;
			jQuery.each(jQuery.trim(value).replace(/,$/, '').split(','), jQuery.proxy(function (index, email) {
				 if (!pattern.test(jQuery.trim(email))){
					valid = false;
				}
			}, this));

			return valid; 
		}
	}, 'Email is ongeldig.');
    
    jq(document).on( "click", ".share-send", function() {					
			var productIdToShare;
			productIdToShare = jq('.product-details').attr("data-product-id");
			var emailAddressInput;
			emailAddressInput = jq('.share-email').val();
			
			var shareSettings;
			shareSettings = jq(this).parent().attr('data-share-settings');

			var shareParams = emailAddressInput.split(";");

			jq("form.share-product-form").validate();
			jq.extend( jq('form.share-product-form [name="emailProduct"]').rules('add', {
				messages: {
					required: "Email is verplicht",
					multiEmail: "Email is ongeldig"
				}
			}));  
			if(jq("form.share-product-form").valid() && shareSettings != ""){
					jq.ajax({
						method: "POST",
						url:  "/diamond/shareproduct/sendemail?emailAddress="+shareParams
								+"&productId="+productIdToShare
								+"&shareSettings="+shareSettings,
						success: function(){
							jq('form.share-product-form').hide();
							jq('.share-success').show();
						}
							
					}); 
			}
	});