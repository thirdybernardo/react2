var jq: any;

class PaginationHandler {
    private pagination: any;
    private pages: any;
    private maxPage: number;
    private selectedPage: number;
    private visiblePageNoCount: number;
    constructor(visiblePageNoCount: number) {
        this.pagination = jq('.fai-pagination li').filter('.pagination-number');
        if (this.pagination != null) {
            this.pages = this.pagination.map(function () {
                return jq(this).find('a').data('targetpage');
            }).get();
            this.maxPage = Math.max.apply(Math, this.pages);
            this.selectedPage = this.pagination.filter('.current').find('a').data('targetpage');
            this.visiblePageNoCount = visiblePageNoCount;
        } else {
            console.log("Cannot find pagination component");
        }
    }
    public RefinePagination(sender ? : number) {
        this.SetActivePage(sender);
        let self = this;
        let eAddEllipsis = false;
        let sAddEllipsis = false;
        //hide pages and setting ellipsis
        jq.each(this.pagination, function (index, element) {
            let pageNo = self.GetDataPageValue(jq(element));
            if (pageNo < self.selectedPage - self.visiblePageNoCount || pageNo > self.selectedPage + self.visiblePageNoCount ) {
                if (pageNo != 0 && pageNo != self.maxPage) {
                    self.HidePageNo(jq(element));
                    if (pageNo > self.selectedPage) {
                        if ((self.selectedPage + self.visiblePageNoCount) + 1 <= self.maxPage) {
                            eAddEllipsis = true;
                        }
                    }
                    if (pageNo < self.selectedPage) {
                        if (self.selectedPage - self.visiblePageNoCount >= pageNo) {
                            sAddEllipsis = true;
                        }
                    }
                }
            }
        });

        if (eAddEllipsis) {
            this.AddEllipsis(this.pagination.find('[data-targetpage=' + this.maxPage + ']'), "before");
        }

        if (sAddEllipsis) {
            this.AddEllipsis(this.pagination.find('[data-targetpage=0]'));
        }
    }

    public SetActivePage(sender) {
        if (sender != null) {
            let nav = jq(sender).parent();
            let pageSelected = this.pagination.filter('.current');
            this.ResetDisplay();
            if (nav.hasClass('pagination-previous') && jq(pageSelected).prev().hasClass('pagination-number')) { //nav button
                jq(pageSelected).prev().addClass('current');
            } else if (nav.hasClass('pagination-next') && jq(pageSelected).next().hasClass('pagination-number')) { //nav button
                jq(pageSelected).next().addClass('current');
            } else {
                //if event sender is not from prev next buttons, set current class
                if ((jq(pageSelected).prev().hasClass('pagination-number') &&
                        jq(pageSelected).next().hasClass('pagination-number')) ||
                    jq(sender).parent().hasClass('pagination-number')) {
                    nav.addClass('current');
                } else {
                    jq(pageSelected).addClass('current'); //else 
                }
            }
            this.selectedPage = this.pagination.filter('.current').find('a').data('targetpage');
        }
    }

    private ResetDisplay() {
        this.pagination.css('display', '');
        this.pagination.removeClass('current');
        jq('.fai-pagination li').remove('.ellipsis');
    }

    private HidePageNo(pageNo) {
        pageNo.css('display', 'none');
    }

    private AddEllipsis(pageNo, position ? : string) {
        if (position == "before") {
            pageNo.parent().before('<li class="ellipsis"><span>...</li></li>');
        } else {
            pageNo.parent().after('<li class="ellipsis"><span>...</li></li>');
        }
    }

    private GetDataPageValue(current): any {
        return jq(current).find('a').data('targetpage');
    }

}


window.onload = () => {
    console.log("ONLOAD");
    var pager = new PaginationHandler(1);
    pager.RefinePagination();
    jq('.fai-pagination a').click(function (e) {
        e.preventDefault();
        pager.RefinePagination(jq(event.target));
    });
};