﻿var jq = jQuery.noConflict();
var Bdr = Bdr || {};
Bdr.CookieConsent = Bdr.CookieConsent || {};

Bdr.CookieConsent.VisitorLevel = function () {
  var level = this.GetCookie();
  if (level == "") {
    return this.StartLevel;
  }
  return level;
}
Bdr.CookieConsent.SetVisitorLevel = function(value) {
  this.SetCookie(value);
  jq.post("/bdr/api/CookieConsent/SaveConsent?level="+value,
    function (data, status) {
     
    });
}

Bdr.CookieConsent.StartLevel = 2;

Bdr.CookieConsent.SetCookie = function (value) {
  var d = new Date();
  d.setTime(d.getTime() + (10* 365 * 24 * 60 * 60 * 1000));
  var expires = "expires=" + d.toUTCString();
  document.cookie = "bdr_CookieConsent" + "=" + value + ";" + expires + ";path=/";
}

Bdr.CookieConsent.GetCookie = function () {
	var name = "bdr_CookieConsent=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

Bdr.CookieConsent.ShowBanner = function() {
  jq('.cookie-consent-content').addClass("visible");
}

Bdr.CookieConsent.HideBanner = function() {
  jq('.cookie-consent-content').removeClass("visible");
}

Bdr.CookieConsent.Initialise = function () {
  if (jq('.cookie-consent-content.visible.editing').length == 0) {

    var cookie = this.GetCookie();
    var bdr = Bdr.CookieConsent;

    jq('.cookie-consent-content button.accept-cookie').click(function() {
      var selectedValue = jq('.cookie-consent-content input[name="consent"]:checked').val();
      bdr.SetVisitorLevel(selectedValue);
      bdr.HideBanner();
      window.location.reload(true); 
    });

    jq('#cookie-instellingen').click(function()
    {
        bdr.ShowBanner();
        jq('.cookie-consent-content div[data-cookie-consent-step="1"]').hide();
        jq('.cookie-consent-content div[data-cookie-consent-step="2"]').show();
        return false;
    });

    jq('.cookie-consent-content a.more-cookie').click(function () {
      jq('.cookie-consent-content div[data-cookie-consent-step="1"]').hide();
      jq('.cookie-consent-content div[data-cookie-consent-step="2"]').show();
      return false;
    });

    jq('.cookie-consent-content div[data-cookie-consent-step="2"]').hide();

    if (!cookie) {
      this.ShowBanner();
      jq('.cookie-consent-content input[name="consent"][value="' + this.StartLevel + '"]').prop('checked', true);
    } else {
      jq('.cookie-consent-content input[name="consent"][value="' + this.VisitorLevel() + '"]').prop('checked', true);
    }
  }
}


jq(document).ready(function() {
  Bdr.CookieConsent.Initialise();
});