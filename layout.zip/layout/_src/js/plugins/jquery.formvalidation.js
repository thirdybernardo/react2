jQuery.noConflict()(function($){
		
		var param = getUrlVars(location.hash.replace( /^#/, '' ));
		
		$.validator.setDefaults({
			submitHandler: function() {				
				this.submit();
			}
		});
		
		//custom validations
		$.validator.addMethod(
			"ValidateRegexp", 
			function(value, element, regexp) {
				var re = new RegExp(regexp);			
				return this.optional(element) || re.test(value);
			},
			"Your input does not match the pattern.");		

		$.validator.addMethod(
			"ValidateInstallersEmail", 
			function(value, element, mode) {
				var flag = false;
				var emailcontent = "";
				$( ".contact-installers" ).each(function( index ) {
				  
				  if($(this).prop('checked')==true){
						flag = true;	
						emailcontent = emailcontent + $(this).val() + "|";
						$("#Recipient").val(emailcontent);						
						//console.log(emailcontent);
				  }
				  
				});
				return flag;
			},
			"Please check atleast one installerrr");			
			
		$.validator.addMethod(
			"CharacterMode", 
			function(value, element, mode) {
				if(mode=="Alphanumeric"){					
					return this.optional(element) || /^[a-z0-9\s-#,.]+$/i.test(value) || /^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]+$/i.test(value);
				}else if(mode=="Alpha"){					
					return this.optional(element) || /^[a-z\s-.]+$/i.test(value); 
				}else if(mode=="Numeric"){					
					return this.optional(element) || /^[0-9\s-+]+$/i.test(value); 
				}else if(mode=="Password"){
					return this.optional( element ) || /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$/.test( value );
				}else{
					return true;
				}				
			},
			"Invalid charaters detected");	
			
		$.validator.addMethod("customvalidation", function(value, element) {
		  // allow any non-whitespace characters as the host part
		  return this.optional( element ) || /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$/.test( value );
		},'Password must be at least eight characters long and combination of uppercase letter, special character and alphanumeric characters.');			
		
		// populate field labels, indicate if required or not
		$("#LabelsandValidations label").each(function( index ) {
			
			var vnclass = $( this ).attr("id");
			var vnreq = $( this ).attr("req");
			var vnname = $( this ).attr("name");				
			
			if(vnname){				
				if(vnreq == "true"){
					$("."+vnclass).html(' ' + vnname+' <span class="required" >*</span>');	
				}else{
					$("."+vnclass).html(' ' + vnname);
				}			
			}
		});	

		// validate signup form on keyup and submit		
		var formname = $("#LabelsandValidations").attr("formid");
		$("#signupForm").validate({
			rules: {
				FirstName: {
					required: ($("#VnFirstName").attr("req") === 'true'),
					CharacterMode: $("#VnFirstName").attr("charmode"),	
					minlength: $("#VnFirstName").attr("minlength"),
					ValidateRegexp: $("#VnFirstName").attr("regex")				
				},
				LastName: {
					required: ($("#VnLastName").attr("req") === 'true'),						
					CharacterMode: $("#VnLastName").attr("charmode"),
					minlength: $("#VnLastName").attr("minlength"),
					ValidateRegexp: $("#VnLastName").attr("regex")	
				},
				Username: {
					required: ($("#VnUsername").attr("req") === 'true'),						
					CharacterMode: $("#VnUsername").attr("charmode"),
					minlength: $("#VnUsername").attr("minlength"),
					ValidateRegexp: $("#VnUsername").attr("regex")	
				},
				Password: {
					required: ($("#VnPassword").attr("req") === 'true'),
					CharacterMode: $("#VnPassword").attr("charmode"),	
					minlength: $("#VnPassword").attr("minlength"),
					ValidateRegexp: $("#VnPassword").attr("regex")	
				},
				Password2: {
					required: ($("#VnPassword2").attr("req") === 'true'),
					CharacterMode: $("#VnPassword2").attr("charmode"),	
					minlength: $("#VnPassword2").attr("minlength"),
					ValidateRegexp: $("#VnPassword2").attr("regex"),
					equalTo: "#Password"
				},
				Email: {
					required: ($("#VnEmail").attr("req") === 'true'),
					CharacterMode: $("#VnEmail").attr("charmode"),	
					minlength: $("#VnEmail").attr("minlength"),
					ValidateRegexp: $("#VnEmail").attr("regex")	
				},
				Mobile:{
					required: ($("#VnMobile").attr("req") === 'true'),
					CharacterMode: $("#VnMobile").attr("charmode"),	
					minlength: $("#VnMobile").attr("minlength"),
					ValidateRegexp: $("#VnMobile").attr("regex")	
				},
				Address:{
					required: ($("#VnAddress").attr("req") === 'true'),
					CharacterMode: $("#VnAddress").attr("charmode"),	
					minlength: $("#VnAddress").attr("minlength"),
					ValidateRegexp: $("#VnAddress").attr("regex")	
				},
				City:{
					required: ($("#VnCity").attr("req") === 'true'),
					CharacterMode: $("#VnCity").attr("charmode"),	
					minlength: $("#VnCity").attr("minlength"),
					ValidateRegexp: $("#VnCity").attr("regex")	
				},
				ZipCode:{
					required: ($("#VnZipCode").attr("req") === 'true'),
					CharacterMode: $("#VnZipCode").attr("charmode"),	
					minlength: $("#VnZipCode").attr("minlength"),
					ValidateRegexp: $("#VnZipCode").attr("regex")	
				}
			},
			messages: {
				FirstName: {
					required: $("#VnFirstName").attr("reqerror"),					
					CharacterMode: $("#VnFirstName").attr("charmodeerror"),
					minlength: $("#VnFirstName").attr("minlenghterror"),
					ValidateRegexp: $("#VnFirstName").attr("regexerror")	
				},
				LastName: {
					required: $("#VnLastName").attr("reqerror"),
					CharacterMode: $("#VnLastName").attr("charmodeerror"),
					minlength: $("#VnLastName").attr("minlenghterror"),
					ValidateRegexp: $("#VnLastName").attr("regexerror")
				},
				Username: {
					required: $("#VnUsername").attr("reqerror"),
					CharacterMode: $("#VnUsername").attr("charmodeerror"),
					minlength: $("#VnUsername").attr("minlenghterror"),
					ValidateRegexp: $("#VnUsername").attr("regexerror")
				},				
				Password: {
					required: $("#VnPassword").attr("reqerror"),
					CharacterMode: $("#VnPassword").attr("charmodeerror"),
					minlength: $("#VnPassword").attr("minlenghterror"),
					ValidateRegexp: $("#VnPassword").attr("regexerror")
				},
				Password2: {
					required: $("#VnPassword2").attr("reqerror"),
					CharacterMode: $("#VnPassword2").attr("charmodeerror"),
					minlength: $("#VnPassword2").attr("minlenghterror"),
					ValidateRegexp: $("#VnPassword2").attr("regexerror"),
					equalTo: $("#VnPasswordsNotMatch").attr("reqerror")
				},
				Email: {
					required: $("#VnEmail").attr("reqerror"),
					CharacterMode: $("#VnEmail").attr("charmodeerror"),
					minlength: $("#VnEmail").attr("minlenghterror"),
					ValidateRegexp: $("#VnEmail").attr("regexerror")
				},
				Mobile:{
					required: $("#VnMobile").attr("reqerror"),
					CharacterMode: $("#VnMobile").attr("charmodeerror"),
					minlength: $("#VnMobile").attr("minlenghterror"),
					ValidateRegexp: $("#VnMobile").attr("regexerror")
				},		
				Address:{
					required: $("#VnAddress").attr("reqerror"),
					CharacterMode: $("#VnAddress").attr("charmodeerror"),
					minlength: $("#VnAddress").attr("minlenghterror"),
					ValidateRegexp: $("#VnAddress").attr("regexerror")
				},		
				City:{
					required: $("#VnCity").attr("reqerror"),
					CharacterMode: $("#VnCity").attr("charmodeerror"),
					minlength: $("#VnCity").attr("minlenghterror"),
					ValidateRegexp: $("#VnCity").attr("regexerror")
				},		
				ZipCode:{
					required: $("#VnZipCode").attr("error"),
					CharacterMode: $("#VnZipCode").attr("charmodeerror"),
					minlength: $("#VnZipCode").attr("minlenghterror"),
					ValidateRegexp: $("#VnZipCode").attr("regexerror")
				}
			}
		});
		
		$("#ContactForm").validate({
			ignore: [],
			rules: {
				FirstName: {
					required: ($("#VnFirstName").attr("req") === 'true'),
					CharacterMode: $("#VnFirstName").attr("charmode"),	
					minlength: $("#VnFirstName").attr("minlength"),
					ValidateRegexp: $("#VnFirstName").attr("regex")				
				},
				LastName: {
					required: ($("#VnLastName").attr("req") === 'true'),						
					CharacterMode: $("#VnLastName").attr("charmode"),
					minlength: $("#VnLastName").attr("minlength"),
					ValidateRegexp: $("#VnLastName").attr("regex")	
				},
				Email: {
					required: ($("#VnEmail").attr("req") === 'true'),
					CharacterMode: $("#VnEmail").attr("charmode"),	
					minlength: $("#VnEmail").attr("minlength"),
					ValidateRegexp: $("#VnEmail").attr("regex")	
				},
				Phone:{
					required: ($("#VnPhone").attr("req") === 'true'),
					CharacterMode: $("#VnPhone").attr("charmode"),	
					minlength: $("#VnPhone").attr("minlength"),
					ValidateRegexp: $("#VnPhone").attr("regex")	
				},
				Urgency:{
					required: ($("#VnUrgency").attr("req") === 'true'),
					CharacterMode: $("#VnUrgency").attr("charmode"),	
					minlength: $("#VnUrgency").attr("minlength"),
					ValidateRegexp: $("#VnUrgency").attr("regex")	
				},
				Message:{
					required: ($("#VnMessage").attr("req") === 'true'),
					CharacterMode: $("#VnMessage").attr("charmode"),	
					minlength: $("#VnMessage").attr("minlength"),
					ValidateRegexp: $("#VnMessage").attr("regex")	
				},
				Recipient:{
					required: ($("#VnRecipient").attr("req") === 'true'),
					ValidateInstallersEmail: ""
				}

			},
			messages: {
				FirstName: {
					required: $("#VnFirstName").attr("reqerror"),					
					CharacterMode: $("#VnFirstName").attr("charmodeerror"),
					minlength: $("#VnFirstName").attr("minlenghterror"),
					ValidateRegexp: $("#VnFirstName").attr("regexerror")	
				},
				LastName: {
					required: $("#VnLastName").attr("reqerror"),
					CharacterMode: $("#VnLastName").attr("charmodeerror"),
					minlength: $("#VnLastName").attr("minlenghterror"),
					ValidateRegexp: $("#VnLastName").attr("regexerror")
				},
				Email: {
					required: $("#VnEmail").attr("reqerror"),
					CharacterMode: $("#VnEmail").attr("charmodeerror"),
					minlength: $("#VnEmail").attr("minlenghterror"),
					ValidateRegexp: $("#VnEmail").attr("regexerror")
				},
				Phone:{
					required: $("#VnPhone").attr("reqerror"),
					CharacterMode: $("#VnPhone").attr("charmodeerror"),
					minlength: $("#VnPhone").attr("minlenghterror"),
					ValidateRegexp: $("#VnPhone").attr("regexerror")
				},		
				Urgency:{
					required: $("#VnUrgency").attr("reqerror"),
					CharacterMode: $("#VnUrgency").attr("charmodeerror"),
					minlength: $("#VnUrgency").attr("minlenghterror"),
					ValidateRegexp: $("#VnUrgency").attr("regexerror")
				},		
				Message:{
					required: $("#VnMessage").attr("reqerror"),
					CharacterMode: $("#VnMessage").attr("charmodeerror"),
					minlength: $("#VnMessage").attr("minlenghterror"),
					ValidateRegexp: $("#VnMessage").attr("regexerror")
				},
				Recipient:{
					required: $("#VnRecipient").attr("reqerror"),
					ValidateInstallersEmail: $("#VnRecipient").attr("reqerror")
				}
			}
		});		
		
		$("#loginform").validate({
			rules: {
				LoginUsername: {
					required: true
				},
				LoginPassword: {
					required: true

				},
			},
			messages: {
				LoginUsername: {
					required: $("#VnLoginUsername").attr("reqerror")
				},
				LoginPassword: {
					required: $("#VnLoginPassword").attr("reqerror")
				}
			}
			
		});
		
		$("#forgotpasswordform").validate({
			rules: {
				Email: {
					required: true,
					email: true
				}
			},
			messages: {
				Username: {
					required: $("#VnEmail").attr("reqerror"),
					email: $("#VnEmail").attr("reqerror")
				}
			}
			
		});		
		
		$("#signoutuser").click(function(){
			
			
		});
		
		$( document ).on( "click", "#signoutuser", function() {	
			LogoutUser();
		});			
		
});(jQuery)

function getUrlVars(hashvalue)
{
    var vars = [], hash;
    if(hashvalue != undefined && hashvalue != "")
    {
        var hashes = hashvalue.split('&');
        for(var i = 0; i < hashes.length; i++)
        {
            hash = hashes[i].split('=');
            vars[hash[0]] = hash[1];
        }
    }
    return vars;
}

function LogoutUser(){
	
	jq.ajax({
		url: "/diamond/Login/LogoutUser",
		type: "Get",
		data: "",
		async: true,
		success: function (data) {
			alert(data);
		}
	});
	
}