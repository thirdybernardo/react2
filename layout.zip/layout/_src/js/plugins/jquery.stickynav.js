;(function($) {

	'use strict';

	//define "semi globals": variables global to this anonymous function's scope
	//prefix them all with sg for recognizability

	var sgPluginName = 'stickyNav',
		$sgWin = $(window);

	

	$.fn[sgPluginName] = function(options) {

		var defaults = {
			stickyNavClass: 'is-sticky',
			scrollSpeed: 3000,// px/second
			maxDuration: 2000,
		},
		config;

		options = options || {};
		config = $.extend({}, defaults, options);


		/**
		* get the position vars for this instance
		* @returns {undefined}
		*/
		var getPositionVars = function($nav) {
			var blocks = [],
				$links = $nav.find('a');

			$links.each(function() {
				var $link = $(this),
					blockId = $link.attr('href'),
					$block = $(blockId).closest('.c-block'),
					blockTop = $block.offset().top;

				blocks.push({
					$block: $block,
					blockTop: blockTop,
				});

				$block.addClass('js-has-sticky-nav');
			});

			var navTop = $nav.offset().top,
				navHeight = $nav.outerHeight(),
				lastBlock = blocks[blocks.length-1],
				lastBlockBottom = lastBlock.blockTop + lastBlock.$block.outerHeight() - $nav.outerHeight();

			var positions = {
				navTop: navTop,
				navHeight: navHeight,
				lastBlockBottom: lastBlockBottom,
				blocks: blocks,
			};

			return positions;
		};


		/**
		* add scrollHandler for object
		* @returns {undefined}
		*/
		var addScrollHandler = function($nav) {
			var positions = getPositionVars($nav),
				$navParent = $nav.parent(),
				$links = $nav.find('a'),
				$clone,
				activeBlockIdx = -1;

			$sgWin.on('resize', function(e) {
				if ($clone) {
					// then $nav is sticky, so we can't use its position - use the clone instead
					positions = getPositionVars($clone);
				} else {
					positions = getPositionVars($nav);
				}
			});

			$sgWin.scroll(function() {
				var scrollTop = $sgWin.scrollTop();

				var isSticky = (scrollTop >= positions.navTop && scrollTop < positions.lastBlockBottom);

				if(isSticky) {

					// add clone in $nav's position 
					if (!$clone) {
						$clone = $nav.clone().appendTo($navParent).addClass('js-sticky-nav-clone');
					}

					// make $nav sticky
					$nav.addClass(config.stickyNavClass);

					// check which block is active
					activeBlockIdx = -1;
					var extraEarly = 10;// make menu active little bit before sections hits
					for (var i=0, len=positions.blocks.length; i<len; i++) {
						var block = positions.blocks[i];
						if ( (scrollTop + positions.navHeight + extraEarly) > block.blockTop) {
							activeBlockIdx = i;
						}
					}

					$links.removeClass('is-active');
					if (activeBlockIdx > -1) {
						$links.eq(activeBlockIdx).addClass('is-active');
					}
				} else if ($clone) {
					$clone.remove();
					$clone = null;// explicitly set to null; otherwise $clone keeps reference to removed element
					$nav.removeClass(config.stickyNavClass);
				}
			});

		};


		/**
		* scroll to inpage link
		* @returns {undefined}
		*/
		var scrollToLink = function(e, $navList) {
			e.preventDefault();
			var href = $(e.currentTarget).attr('href'),
				$block = $(href),
				scrollTop = $block.offset().top - $navList.outerHeight(),// scroll until block ends up directly below nav
				distance = Math.abs(scrollTop - $sgWin.scrollTop()),
				duration = Math.min(1000*distance/config.scrollSpeed, config.maxDuration);

			$('html, body').stop().animate({scrollTop: scrollTop}, duration, 'swing');
		};


		/**
		* initialize scrolling to page
		* @param {jQuery object} $navList Typically a <ul> with nav-links
		* @returns {undefined}
		*/
		var initPageScrolling = function($navList) {
			var $links = $navList.find('a');

			$links.on('click', function(e) {
				scrollToLink(e, $navList);
			});
		};
	

		/**
		* initialize this instance
		* @param {html element} obj The html element to bind sticky behaviour to
		* @returns {undefined}
		*/
		var init = function(obj) {
			var $navList = $(obj);

			addScrollHandler($navList);
			initPageScrolling($navList);
		};

		
		//do stuff with every element of the wrapped set, and return the set for chaining
		return this.each(function() {
			init(this);
		});

	};

})(jQuery);