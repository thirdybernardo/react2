/* ========================================================================
 * Alphaquad: megamenu.js v 1.0.0
 * ========================================================================
 *
 * ======================================================================== */

jQuery.noConflict();

;(function($, window, document){
    'use strict';

    var pluginName = 'megamenu',
        viewport = {
            width : window.innerWidth,
            desktop : undefined,
            mobile : undefined
        };

    // Create the plugin constructor
    function Megamenu (element, options) {
        this.element = element;
        this._name = pluginName;
        this._viewport = null;
        this._defaults = Megamenu.DEFAULTS;

        this.options = $.extend({}, this._defaults, options);

        this.init();
    }

    Megamenu.VERSION  = '1.0.0';

    Megamenu.DEFAULTS = {
        speed : '500ms',
        easing : 'ease-in',
        callback : undefined,
        closeOption:false,
        closeOptionText:'Close menu'
    }

    var Events = {
        mainMenuLink : function(e) {
            var clickedLink = e.target,
                $navLink = $(clickedLink),
                $body = $('body'),
                subNav = $navLink.data('subnav'),
                directlink = $navLink.data('directlink');
            if(directlink) {
                window.location.href = $navLink.attr('href');
            } else {
                this.$mainNavLinks.each(function(){
                    var $link = $(this);
                    if($link.hasClass('active')) {
                        $body.removeClass('submenu-is-active');
                        $link.removeClass('active');
                    }
                });
                $navLink.addClass('active');
                $body.addClass('submenu-is-active');
                if(viewport.desktop) {
                    //console.log("viewport is desktop");
                    //console.log(viewport);
                    this.setupDesktopMenu(subNav, $navLink);

                } else {
                    //console.log("viewport is mobile");
                    //console.log(viewport);
                    this.setupMobileMenu(subNav, $navLink)
                }
            }
            e.preventDefault();
        },
        closeMenuLink : function(e) {
            var $clickedLink = $(e.target);
            if(viewport.desktop) {
                var $panel = $clickedLink.closest('.nav__subnav_panel');
                $panel.slideFadeToggle(500);
            } else {
                var $mobileSubNav = $clickedLink.prevAll('.nav__subnav_items--mobile');
                $mobileSubNav.slideUp(500);
                this.$element.slideFadeToggle(500);
            }

            e.preventDefault();
        },
        navBurgerLink : function(e) {
            var $mobileSubLinks = $('.nav__subnav_items--mobile');

            $mobileSubLinks.each(function(){
                var $linkSection = $(this);
                if($linkSection.is(':visible')) {
                    $linkSection.slideUp(500);
                }
            });

            this.$element.slideFadeToggle(500);
        },
        viewPortResize: function(e) {
            viewport.width = window.innerWidth;


            //console.log(window.innerWidth);
            // console.log(window.Width);          
            //console.log(viewport.width);
            //console.log(viewport);
            
            if(viewport.width > 1023 && !viewport.desktop) {
                viewport.desktop = true;
                viewport.mobile = false;
                //console.log(viewport);
            }

            if(viewport.width < 1024 && !viewport.mobile) {
                viewport.desktop = false;
                viewport.mobile = true;
                //console.log(viewport);
            }
            this.resetMenu();
        },
        offMenuClickOrEsc : function(e) {

            if (e.keyCode == 27) { //esc
                this.offMenuReset();
            }

            if(!$(e.target).closest('.nav').length) {
                this.offMenuReset();
            }
        }
    }

    // Avoid Megamenu.prototype conflicts
    $.extend(Megamenu.prototype, {
        // Initialization logic
        init : function(options) {
            this.buildCache();
            this.setViewPort();
            this.setupMainNavLinks();
            this.buildMobileMenu();
            if(this.options.closeOption) {
                this.addCloseButton();
            }
            this.bindEvents();

        },

        setViewPort : function () {
            if(viewport.width > 1023) {
                
                this._viewport = 'desktop';
                viewport.desktop = true;
                viewport.mobile = false;
                //console.log("set viewport desktop");
                //console.log(viewport);

            } else {
                this._viewport = 'mobile';
                viewport.desktop = false;
                viewport.mobile = true;
                //console.log("set viewport mobile");
                //console.log(viewport);
            }
        },

        // Remove plugin instance completely
        destroy : function () {
            this.unbindEvents();
            this.$element.removeData();
        },


        // Cache DOM nodes for performance
        buildCache : function() {
            this.$element = $(this.element);
            this.$navBurger = $('.nav__navBurger');
            this.$mainNavLinks = this.$element.find('a');
            this.$desktopSubNavContainer = $('.nav__subnav');
        },

        setupMainNavLinks : function() {
            var plugin = this;
            if(viewport.mobile) {
                plugin.$element.addClass('mobile-menu-on');
            }
            plugin.$mainNavLinks.each(function() {
                var link = $(this);
                if(link.data('directlink')) {
                    link.attr('data-subnav', "false");
                }
            });
        },
        addCloseButton : function() {
            var plugin = this;

            plugin.$desktopSubNavContainer.find('.nav__subnav_panel').each(function(){
                var $panel = $(this);
                //$panel.append('<div class="nav__menu-close"><a class="nav__menu-close-link" href="#">'+plugin.options.closeOptionText+'</a></div>');
            });

            if(viewport.mobile) {
                plugin.$element.append('<a class="nav__menu-close-link mobile" href="#">'+plugin.options.closeOptionText+'</a>');
            }
        },

        buildMobileMenu : function () {
            var plugin = this;

            //iterate through main nav links for sub links
            plugin.$mainNavLinks.each(function(){
                var $link = $(this),
                    sub = $link.data('subnav');

                if(sub) {
                    var  $mobileNavContainer = $("<div id="+ sub +" class='nav__subnav_items--mobile'></div>"),
                        $subnavHeaderLevel1Link = $('.nav__subnav_panel[data-subnav="'+ sub +'"] .nav__subnav_header'),
                        $levelTwoChildLinks = $('.nav__subnav_panel[data-subnav="'+ sub +'"] .nav__subnav_items .nav__subnav_item.nav__subnav_title');

                    $link.after($mobileNavContainer);

                    $mobileNavContainer.append($subnavHeaderLevel1Link.html());

                    $levelTwoChildLinks.each(function() {
                        var $link = $(this).clone();

                        $mobileNavContainer.append($link);
                    });
                }
                //append to just after main nav link

            });
        },

        setupDesktopMenu : function(subNav, $navLink) {
            var plugin = this,
                $clickedLink = $navLink,
                $body = $('body'),
                $panels = $('.nav__subnav_panel'),
                $subPanel = $('.nav__subnav_panel[data-subnav='+subNav+']' );


            if($subPanel.length > 0) {
                if($subPanel.is(':visible')) {
                    $subPanel.slideToggle(300);
                    $clickedLink.removeClass('active');
                    $body.removeClass('submenu-is-active');
                } else {
                    if ( $panels.is(':visible') ){
                        $panels.each(function(){
                            var $panel = $(this);
                            if($panel.is(':visible')){
                                $panel.fadeOut("fast");
                            }
                        });
                        //$(':visible'').fadeOut("fast");
                        plugin.$mainNavLinks.removeClass('active');
                        $subPanel.fadeIn('fast');
                        $clickedLink.addClass('active');
                    }
                    else {
                        $subPanel.slideToggle(300);
                    }
                }
            } else {
                $panels.slideToggle(300);
                plugin.$mainNavLinks.removeClass("active");
            }

        },
        setupMobileMenu : function(subNav, $navLink) {
            var plugin = this,
                $clickedLink = $navLink,
                $mobileSubLinks = $('.nav__subnav_items--mobile'),
                $selectedSubNav = $('#'+subNav);

            $mobileSubLinks.each(function(){
                var $mobileSubLink = $(this);
                if($mobileSubLink.is(':visible')){
                    $mobileSubLink.slideUp(500).animate({ opacity: 0 },{ queue: false, duration: 'slow' });
                    plugin.$mainNavLinks.removeClass('active');
                }
            });

            if($selectedSubNav.is(':visible')) {
                $selectedSubNav.slideUp(500).animate({ opacity: 0 },{ queue: false, duration: 'slow' });
                plugin.$mainNavLinks.removeClass("active");

            } else {
                $selectedSubNav.css('opacity',0).slideDown(500).animate({ opacity: 1 },{ queue: false, duration: 'slow' });
                $clickedLink.addClass("active");
            }
        },
        offMenuReset : function () {
            var plugin = this,
                $mobileSubLinks = $('.nav__subnav_items--mobile'),
                $panels = $('.nav__subnav_panel'),
                $mobileCloseButton = $('.nav__menu-close-link.mobile'),
                $body = $('body');
                plugin.$mainNavLinks.removeClass('active');
                $body.removeClass('submenu-is-active');
            if(viewport.desktop) {
                $panels.each(function(){
                    var $panel = $(this);
                    if($panel.is(':visible')){
                        $panel.fadeOut("fast");
                    }
                });

                if(!plugin.$element.is(':visible')) {
                    plugin.$element.show();
                    plugin.$element.addClass('test');
                }
                $mobileCloseButton.hide();
                if(plugin.$element.hasClass('mobile-menu-on')) {
                    plugin.$element.removeClass('mobile-menu-on');
                }
            } else {
                $mobileSubLinks.each(function(){
                    var $mobileSubLink = $(this);
                    $mobileSubLink.slideUp(500).animate({ opacity: 0 },{ queue: false, duration: 'slow' });
                });

                if(plugin.options.closeOption) {
                    if($mobileCloseButton.length == 0) {
                        plugin.$element.append('<a class="nav__menu-close-link mobile" href="#">'+plugin.options.closeOptionText+'</a>');
                    } else {
                        if(!$mobileCloseButton.is(':visible')) {
                            $mobileCloseButton.show();
                        }
                    }
                }

                if(plugin.$element.hasClass('mobile-menu-on') && plugin.$element.is(':visible')) {
                    plugin.$element
                        .slideUp(500);
                }

            }
        },

        resetMenu : function() {
            //remove active links
            var plugin = this,
                $mobileSubLinks = $('.nav__subnav_items--mobile'),
                $panels = $('.nav__subnav_panel'),
                $mobileCloseButton = $('.nav__menu-close-link.mobile');

            plugin.$mainNavLinks.removeClass('active');

            if(viewport.desktop) {
                $mobileSubLinks.each(function(){
                    var $linkSection = $(this);
                    if($linkSection.is(':visible')) {
                        $linkSection.hide();
                    }
                });
                if(!plugin.$element.is(':visible')) {
                    plugin.$element.show();
                }
                $mobileCloseButton.hide();
                if(plugin.$element.hasClass('mobile-menu-on')) {
                    plugin.$element.removeClass('mobile-menu-on');
                }
            } else {
                //hide desktop panels if shown
                $panels.each(function(){
                    var $panel = $(this);
                    if($panel.is(':visible')) {
                        $panel.hide();
                    }
                });

                if(plugin.options.closeOption) {
                    if($mobileCloseButton.length == 0) {
                        plugin.$element.append('<a class="nav__menu-close-link mobile" href="#">'+plugin.options.closeOptionText+'</a>');
                    } else {
                        if(!$mobileCloseButton.is(':visible')) {
                            $mobileCloseButton.show();
                        }
                    }
                }

                if(!plugin.$element.hasClass('mobile-menu-on')) {
                    plugin.$element
                        .hide()
                        .addClass('mobile-menu-on');
                }

            }
        },

        bindEvents: function() {
            var plugin = this;

            plugin.$mainNavLinks.on('click'+'.'+plugin._name+' touchend'+'.'+plugin._name, function (e) {
                Events.mainMenuLink.call(plugin, e);
            });

            if(plugin.options.closeOption) {
                $(document).on('click'+'.'+plugin._name, '.nav__menu-close-link', function(e) {
                    Events.closeMenuLink.call(plugin, e);
                });
            }


            plugin.$navBurger.on('click'+'.'+plugin._name, function(e) {
                Events.navBurgerLink.call(plugin, e);
            });

            $(window).on('resize'+'.'+plugin._name, function(e){
                Events.viewPortResize.call(plugin, e);
            });

            $(document).on('click'+'.'+plugin._name,function(e) {
                Events.offMenuClickOrEsc.call(plugin, e);
            });
            $(document).on('keyup'+'.'+plugin._name,function(e) {
                Events.offMenuClickOrEsc.call(plugin, e);
            });
        },

        // Unbind events that trigger methods
        unbindEvents: function() {
            /*
             Unbind all events in our plugin's namespace that are attached
             to "this.$element".
             */
            this.$element.off('.'+this._name);
        },

    });

    // Megamenu PLUGIN DEFINITION
    // ==========================

    function Plugin(options) {
        this.each(function(){
            if ( !$.data( this, "plugin_" + pluginName ) ) {

                $.data( this, "plugin_" + pluginName, new Megamenu( this, options ) );
            }
        });

        return this;
    }

    var old = $.fn.megamenu

    $.fn.megamenu = Plugin


    // MEGAMENU NO CONFLICT
    // ====================

    $.fn.megamenu.noConflict = function () {
        $.fn.megamenu = old
        return this
    }

    $.fn.slideFadeToggle = function(speed, easing, callback) {
        return this.animate({
            opacity: 'toggle',
            height: 'toggle'
        }, speed, easing, callback);
    };

})(jQuery, window, document);

(function($) {
    $(function(){
        $('.nav__mainNav').each(function() {
            var $nav = $(this),
                options = (typeof $nav.attr('data-options') !== "undefined") ? $.parseJSON($nav.attr('data-options')) : {};
            $nav.megamenu(options);
        });
    });

})(jQuery);