
jQuery.noConflict()(function ($) {
  
  const ie11 = !!navigator.userAgent.match(/Trident\/7\./);
  
  /**
   * ObjectFit Polyfill
   * ------------
   * Version : 1.0.0
   * Author  : Wieteke Pots
   */
  function objectFit() {
    const $imageContainers = $('.js-polyfill-object-fit');

    $imageContainers.each(function() {
      const $figure = $(this);
      const $img = $figure.children('img');
      const imgSrc = $img.attr('src');

      if(imgSrc) {
        $figure.css({
              'background-image': `url(${imgSrc})`,
              'background-size': 'cover',
              'background-repeat': 'no-repeat',
        });

        $img.css({ 'display': 'none' });
      }
    });

  }
  
  function init() {
    if (ie11) {
      objectFit();
    }
  }
  
  $(document).ready(init);
});