jQuery.noConflict()(function($){
    
    
    // $("label[for='storingscode']").click(function() {
    //     var $label = $("label[for='storingscode']:not('.text-label')");
    //     if($("#storingscode").prop("checked") == true) {
    //         $label.html("Nee");
    //         $label.parents(".row").find(".input-wrapper").addClass("hide");
    //         $label.parents(".row").find(".disabled-input-message").show();
    //     } else {
    //         $label.html("Ja");
    //         $label.parents(".row").find(".input-wrapper").removeClass("hide");
    //         $label.parents(".row").find(".disabled-input-message").hide();
    //     }
    // });
    $(document).ready(function(){
        $(".arrange.rblock.yellow").find(".btn-wrapper").addClass("menu-show"); 
        $(".arrange.rblock.yellow").addClass("hideOption");
    });
    
    if ($(".dashboard .container .promo.snel-regelen").length > 0 && window.outerWidth <= 639) {
        $(".arrange.rblock.yellow").find(".btn-wrapper").addClass("menu-show"); 
        $(".arrange.rblock.yellow").addClass("hideOption");
        var snelRegelen = $(".arrange.rblock.yellow");
        $(snelRegelen).find(".block--text").click(function(){
            if($(snelRegelen).find(".menu-show.hide-for-small").length){
                $(snelRegelen).find(".menu-show.hide-for-small").removeClass("hide-for-small");
                $(snelRegelen).addClass("showOption");
                $(snelRegelen).removeClass("hideOption");
            }else{
                $(snelRegelen).find(".menu-show").addClass("hide-for-small");
                console.log("Kris Triggered");
                $(snelRegelen).removeClass("showOption");
                $(snelRegelen).addClass("hideOption");
            }
       });
    }
});