import React from "react";
import Data from "../Data/Data";
import QuickProductRegistrationTileFields from '../Components/Dashboard/QuickProductRegistrationTile';
import RecentRegistrationsTile from '../Components/Dashboard/RecentRegistrationsTile';
import RecentPointsEarnedTile from '../Components/Dashboard/RecentPointsEarnedTile';
import DashboardSearch from '../Components/Dashboard/DashboardSearch';
import EmailCampaignBanner from '../Components/Dashboard/EmailCampaignBanner';
import WishlistTile from '../Components/Dashboard/WishlistTile';
import ErrorReport from '../Components/ProductOverview/ErrorReport';

export default class Dashboard extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            quickProductRegistrationTileFields: {
                item: {}
            },
            recentRegistrationsTileFields: {
                item: {}
            },
            recentPointsEarnedTileFields: {
                item: {}
            },
            dashboardSearchFields: {
                item: {}
            },
            emailCampaignBannerFields: {
                item: {}
            },
            wishlistTileFields: {
                item: {}
            },
            errorReportFields: {
                item: {}
            }
        };
    }

    componentDidMount() {
        Data.getData("QuickProductRegistrationTileFields", (data) => {
            this.setState({ quickProductRegistrationTileFields: data });
        });
        Data.getData("RecentRegistrationsTileFields", (data) => {
            this.setState({ recentRegistrationsTileFields: data });
        });
        Data.getData("RecentPointsEarnedTileFields", (data) => {
            this.setState({ recentPointsEarnedTileFields: data });
        });
        Data.getData("DashboardSearchFields", (data) => {
            this.setState({ dashboardSearchFields: data });
        });
        Data.getData("EmailCampaignBannerFields", (data) => {
            this.setState({ emailCampaignBannerFields: data });
        });
        Data.getData("WishlistTileFields", (data) => {
            this.setState({ wishlistTileFields: data });
        });
        Data.getData("ErrorReportFIelds", (data) => {
            this.setState({ errorReportFields: data });
        });
    }

    render() {
        return (
            <div className="c-reg--main">
                <div className="dashboard">
                    <div className="container">
                        <div className="row title-field">
                            <div className="columns medium-6 small-12">
                                <div className="form--title">
                                    <h2>Goedemiddag Danny,</h2>
                                </div>
                            </div>
                            <div className="columns medium-6 hide-for-small">
                                <DashboardSearch data={this.state.dashboardSearchFields} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="columns medium-12 hide-for-small">
                                <EmailCampaignBanner data={this.state.emailCampaignBannerFields} />
                            </div>
                        </div>    </div>
                    <div className="white-bg container">
                        <div className="dashboard--tabber-container dashboard-tabber row">
                            <div className="easy-responsive-tabber Brand Class " id="dashboard--tabber" style={{ display: "block", width: "100%", margin: "0px" }}>
                                <ul className="resp-tabs-list dashboard--tabber">
                                    <li className="resp-tab-item dashboard--tabber resp-tab-active" arial-controls="producten-klanten" role="tab" aria-controls="dashboard--tabber_tab_item-0">
                                        <span className="icon-product"></span>
                                        <span className="tab--title">Producten &amp; klanten</span>
                                    </li>
                                    <li className="resp-tab-item dashboard--tabber" arial-controls="mijn-berichten" role="tab" aria-controls="dashboard--tabber_tab_item-1">
                                        <span className="icon icon-envelope">
                                            <span className="circle-icon">9</span>
                                        </span>
                                        <span className="tab--title">Mijn berichten</span>
                                    </li>
                                    <li className="resp-tab-item dashboard--tabber" arial-controls="mijn-profiel" role="tab" aria-controls="dashboard--tabber_tab_item-2">
                                        <span className="icon icon-user"></span>
                                        <span className="tab--title">Mijn profiel</span>
                                    </li>
                                </ul>
                                <div className="resp-tabs-container dashboard--tabber">
                                    <h2 className="resp-accordion dashboard--tabber resp-tab-active" role="tab" aria-controls="dashboard--tabber_tab_item-0"><span className="resp-arrow"></span>
                                        <span className="icon-product"></span>
                                        <span className="tab--title">Producten &amp; klanten</span>
                                    </h2><div className="resp-tab-content dashboard--tabber resp-tab-content-active" arial-labelledby="producten-klanten" aria-labelledby="dashboard--tabber_tab_item-0" style={{ display: "block" }}>
                                        <div className="row">
                                            <div className="columns small-12 producten-klanten--title show-for-small-only">
                                                <h4>Snel een registratie zoeken</h4>
                                            </div>
                                            <div className="columns small-12 show-for-small-only">
                                                <div className="search-wrapper">
                                                    <input type="text" placeholder="Zoek op klantnaam, serienummer, etc.." />
                                                </div>
                                            </div>
                                            <div className="columns small-12 producten-klanten--rblocks align-middle">
                                                <div className="row">
                                                    <div className="columns small-6 medium-6 large-4">
                                                        <QuickProductRegistrationTileFields data={this.state.quickProductRegistrationTileFields} />
                                                    </div>
                                                    <div className="columns small-6 medium-6 large-5">
                                                        <RecentRegistrationsTile data={this.state.recentRegistrationsTileFields} />
                                                    </div>
                                                    <div className="columns small-12 medium-12 large-3">
                                                        <div className="rblock-container">
                                                            <div className="new-request rblock">
                                                                <div className="block--text hide-for-small">Klanten</div>
                                                                <div className="block--text show-for-small-only">Nieuwe aanvragen</div>
                                                                <div className="block--icon circle-icon">3</div>
                                                                <div className="customer-requests hide-for-small">
                                                                    <div className="found-customers">20x gevonden op Remeha.nl</div>
                                                                    <div className="new-applications">U heeft <a href="">3 nieuwe aanvragen</a> in uw klantoverzicht.</div>
                                                                </div>
                                                            </div>
                                                            <div className="arrange rblock yellow">
                                                                <div className="block--text">Snel regelen</div>
                                                                <div className="btn-wrapper hide-for-small">
                                                                    <ErrorReport data={this.state.errorReportFields} />
                                                                    <a href="" className="button hollow arrow-right">Product retournen</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <h2 className="resp-accordion dashboard--tabber" role="tab" aria-controls="dashboard--tabber_tab_item-1"><span className="resp-arrow"></span>
                                        <span className="icon icon-envelope">
                                            <span className="circle-icon">9</span>
                                        </span>
                                        <span className="tab--title">Mijn berichten</span>
                                    </h2><div className="resp-tab-content dashboard--tabber" arial-labelledby="mijn-berichten" aria-labelledby="dashboard--tabber_tab_item-1">
                                        mijn-berichten
                        </div>
                                    <h2 className="resp-accordion dashboard--tabber" role="tab" aria-controls="dashboard--tabber_tab_item-2"><span className="resp-arrow"></span>
                                        <span className="icon icon-user"></span>
                                        <span className="tab--title">Mijn profiel</span>
                                    </h2><div className="resp-tab-content dashboard--tabber" arial-labelledby="mijn-profiel" aria-labelledby="dashboard--tabber_tab_item-2">
                                        mijn-profiel
                        </div>
                                </div>
                            </div>
                        </div>    </div>
                    <div className="container promo-section">
                        <div className="row">
                            <div className="columns large-4 medium-6 small-6">
                                <div className="promo-ds dashboard--promo-blue-btn">
                                    <div className="dashboard--promo-blue-btn__img">
                                        <img src="/images/productlandingspagina/waterpas_2.jpg" />
                                    </div>
                                    <div className="dashboard--promo-blue-btn__title">
                                        <h3>Klik-Klaar-Kado Maanden</h3>
                                    </div>
                                    <div className="dashboard--promo-blue-btn__btn">
                                        <a href="" className="">
                                            Lees meer
                            </a>
                                    </div>
                                </div>
                            </div>
                            <div className="columns large-4 medium-6 small-6">
                                <RecentPointsEarnedTile data={this.state.recentPointsEarnedTileFields} />
                            </div>
                            <div className="columns large-4 show-for-large">
                                <WishlistTile data={this.state.wishlistTileFields} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="columns large-4 medium-6 small-12">
                                <div className="promo-ds dashboard--promo-block">
                                    <div className="dashboard--promo-block__img">
                                        <img src="/images/temp/cat.jpg" />
                                        <span className="promo-date">18 januari 2019</span>
                                    </div>
                                    <div className="dashboard--promo-block__text">
                                        <h4>Remeha en Techneco bundelen de krachten</h4>
                                        <p>
                                            Met ingang van 1 januari 2019 neemt Remeha alle aandelen over van Techneco, een Nederlandse
                                specialist in warmtepompen. <a href="">lees meer</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className="columns large-8 medium-6 small-12">
                                <div className="promo-ds dashboard--promo-banner">
                                    <div className="cta cta--banner  Brand Class " style={{ background: "#ffda39" }}>

                                        <div className="cta cta__block">
                                            <div className="cta cta--singleLink cta--icon   cta--noText Brand Class ">
                                                <div className="cta__headerBlock">
                                                    <div className="alpha">Waterstof<br />één van de wegen<br />naar duurzaam.</div>
                                                </div>
                                                <div className="cta__promoBlock">
                                                    <div className="cta__imageBlock">
                                                        <img src="/images/temp/cat.jpg" alt="" />
                                                    </div>
                                                    <div className="cta__contentBlock">
                                                        <p>Waterstof als onderdeel van de energietransitie</p>
                                                    </div>
                                                    <div className="cta__linkBlock">
                                                        <a href="" className="">Lees verder</a>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }

}