import React from "react";
import Data from "../Data/Data";
import RegistrationOptions from "../Components/ProductRegistration/RegistrationOptions";
import SingleUpload from "../Components/ProductRegistration/SingleUpload";
import BulkUpload from "../Components/ProductRegistration/BulkUpload";
import CookieHelper from '../Helpers/CookieHelper';

export default class InstallerRegistration extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            activeTab: 0,
            singleUpload: {
                item: {}
            },
            bulkUpload: {
                item: {}
            },
            registrationOptions: {
                item: {}
            },
            cookieState: false
        };
    }

    componentDidMount() {
        //set the component sitecore fields here
        Data.getData("RegistrationOptionsFields", (data) => {
            this.setState({ registrationOptions: data });
        });
        Data.getData("SingleRegistrationProductFields", (data) => {
            this.setState({ singleUpload: data });
        });
        Data.getData("BulkRegistrationProductFields", (data) => {
            this.setState({ bulkUpload: data });
        });
        this.mockCookieChecker();
    }

    mockWhitelabelTabber = (e, tab) => {
        this.setState({ activeTab: tab });
    }

    mockCookieChecker = (_override) => {
        let _activeTab = 0;
        if (_override)
            this.setState({ cookieState: _override }, () => {  this.setState({ activeTab: (_override == "single-upload" ? 0 : 1 ) }); });
        else
            this.setState({ cookieState: CookieHelper.getCookie("InstallerPortalPreferredRegistration") }, () => {  this.setState({ activeTab: (this.state.cookieState == "single-upload" ? 0 : 1 ) }); });
    }

    render() {
        let _isSelection = this.state.cookieState;
        let _selectionComponent = _isSelection == "" ? (<RegistrationOptions data={this.state.registrationOptions} callback={this.mockCookieChecker} />) : null;
        return (
            <div className="main">
                <div className="product-registration">
                    {/* START Installer Progress Bar Component */}
                    {/* <div className="form--progress-bar progress-complete">

                        <div className="row collapse progress-bar-label">
                            <span className="columns large-6">87%</span>
                            <span className="columns large-6">~ 20 sec</span>
                        </div>
                        <div className="progress-bar-meter">
                            <span style={{ width: "87" + "%" }}></span>
                        </div>

                    </div> */}
                    {/* END Installer Progress Bar Component */}
                    {_selectionComponent}
                    <div className={"form--content " + (_isSelection == "" ? "hide" : "" )}>
                        <div className="form--title">
                            <h2>Registreer uw product(en)</h2>
                        </div>
                        <div className="container installer-tabber">                        
                            <ul className="resp-tabs-list">
                                <li className={"resp-tab-item " + (this.state.activeTab == 0 ? "resp-tab-active" : "")} role="tab" onClick={event => this.mockWhitelabelTabber(event, 0)}>
                                    Enkel adres </li>
                                <li className={"resp-tab-item " + (this.state.activeTab == 1 ? "resp-tab-active" : "")} role="tab" onClick={event => this.mockWhitelabelTabber(event, 1)}>
                                    Bulk Upload </li>
                            </ul>
                            <div className="resp-tabs-container" style={{ display: "block" }}>
                                <div className={"resp-tab-content " + (this.state.activeTab == 0 ? "resp-tab-content-active" : "")}>
                                    <div className="pure-g row expanded collapse">
                                        <div className="small-12 columns">
                                            <div className="container">
                                                <SingleUpload data={this.state.singleUpload} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className={"resp-tab-content " + (this.state.activeTab == 1 ? "resp-tab-content-active" : "")}>
                                    <div className="pure-g row expanded collapse">
                                        <div className="small-12 columns">
                                            <div className="container">
                                                <BulkUpload data={this.state.bulkUpload} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}