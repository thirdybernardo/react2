import React from 'react';
import Data from '../Data/Data';
import InstalledProductsOverview from '../Components/ProductOverview/InstalledProductsOverview';
import Alert from '../Components/Generic/Alert';
import TableSearch from '../Components/Generic/TableSearch';

export default class InstalledParkOverview extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            installedParkOverviewFields: {
                item: {}
            },
            installedParkOverviewAlert: {
                item: {}
            },
            installedParkOverviewTableFields: {
                item: {}
            },
            installedParkOverviewModalFields: {
                item: {}
            }
        };
    }

    componentDidMount() {
        Data.getData("InstalledParkOverviewFields", (data) => {
            this.setState({ installedParkOverviewFields: data });
        });   
        Data.getData("InstalledParkOverviewAlertFields", (data) => {
            this.setState({ installedParkOverviewAlert: data });
        });     
        Data.getData("InstalledParkOverviewTableFields", (data) => {
            this.setState({ installedParkOverviewTableFields: data });
        }); 
    }

    render() {
        return (
            <div className="main--product-overview">
                <InstalledProductsOverview data={this.state.installedParkOverviewFields} />
                <div className="product-overview product-overview--main-body">
                    <div className="row">
                        <div className="large-8 medium-12 small-12">
                            <Alert data={this.state.installedParkOverviewAlert} />
                        </div>
                    </div>
                    <TableSearch data={this.state.installedParkOverviewTableFields} />
                </div>
                {/* Table */}
                {/* Pagination */}
            </div>
        );
    }

}