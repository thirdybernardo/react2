import React from "react";
import Data from "../Data/Data";
import Greeting from "../Components/Generic/Greeting";
import ProfileForm from '../Components/Profile/ProfileForm';


export default class ManageProfile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            profileFormFields: {
                item: {},
                dictionary: {}
            },
            greetingFields: {
                item: {}
            }
        };
    }

    componentDidMount() {
        Data.getData("ProfileFormFields", (data) => {
            this.setState({ profileFormFields: data });
        });
        Data.getData("GreetingsFields", (data) => {
            this.setState({ greetingFields: data });
        });
    }

    renderSideMenu = () => {
        if (!this.props.isSitecore) {
            return (
                <div className="profile-sidebar">
                    <section className="nav company-profile">
                        <div className="sidebar-title">
                            Profiel
                    </div>
                        <ul className="sidebar-nav">
                            <li className="title">Mijn bedrijfsprofiel</li>
                            <li><a href="#algemenegegevens">Algemene gegevens</a></li>
                            <li><a href="#werkgebied">Werkgebied</a></li>
                            <li><a href="#diensten">Diensten</a></li>
                            <li><a href="">Account instellingen</a></li>
                        </ul>
                    </section>
                    <section className="nav user-management">
                        <ul className="sidebar-nav">
                            <li className="title">Gebruikersbeheer</li>
                            <li><a href="">Overzicht van gebruikers (12)</a></li>
                            <li><a href="">Nieuwe gebruiker aanmaken</a></li>
                        </ul>
                    </section>
                    <section className="nav gifts">
                        <ul className="sidebar-nav">
                            <li className="title">Cadeaus</li>
                            <li><a href="">Mijn punten</a></li>
                            <li><a href="">Mijn gekochte cadeaus</a></li>
                        </ul>
                    </section>
                </div>
            );
        }
    }

    render() {
        return (
            <div className="profile" >
                {/* START GREETING COMPONENT */}
                <Greeting data={this.state.greetingFields} userName="Danny" />
                {/* END GREETING COMPONENT */}
                {/* START Regular Menu Component - Will no be rendered when in Sitecore */}
                {this.renderSideMenu()}
                {/* END Regular Menu Component */}
                {/* START PROFILE FORM COMPONENT */}
                <div className="profile-body">
                    <ProfileForm data={this.state.profileFormFields} />
                </div>
                {/* END PROFILE FORM COMPONENT */}
            </div >
        );
    }

}