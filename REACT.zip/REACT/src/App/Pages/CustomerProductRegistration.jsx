import React from "react";
import Data from "../Data/Data";
//import RegistrationOptions from "../Components/ProductRegistration/RegistrationOptions";
import CustomerSingleForm from "../Components/Customer-Registration/CustomerSingleForm";
//import CookieHelper from '../Helpers/CookieHelper';

export default class ProductRegistration extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            singleUpload: {
                item: {}
            },
            
            bulkUpload: {
                item: {}
            },
            registrationOptions: {
                item: {}
            },
            cookieState: false,
            showServiceWindow: true,
        };
    }
    componentDidMount() {
        //set the component sitecore fields here
        Data.getData("RegistrationOptionsFields", (data) => {
            this.setState({ registrationOptions: data });
        });
        Data.getData("SingleRegistrationProductFields", (data) => {
            this.setState({ singleUpload: data });
        });    
    }

    render() {
        //let _isSelection = this.state.cookieState;
        //let _selectionComponent = _isSelection == "" ? (<RegistrationOptions data={this.state.registrationOptions} callback={this.mockCookieChecker} />) : null;
        return (
            <div className="main">
              <div className="divContainer">
                <div className="yellow-bg campaign--message">
                    <div className="radiomenu">
                      <div className="form--content">
                          <div className="form--title">
                             <h2>Garantieregistratie</h2>
                             <div className="txtheadercon">
                               <span>Om optimaal te kunnen profiteren van onze volledige 2 jaar garantie en service is het van belang om de garantiekaart binnen 4 weken na installatie in te vullen. Vul onderstaand formulier in en ontvang handige onderhoudstips.</span>
                             </div>
                             
                          </div>
                       </div>  
                    </div>
                   <div className="cus-radio-select">
                    <div className="form-group wh-cus-bg customer-data">
                        <div className="row section-title">
                            <div className="columns medium-12">
                                <div className="contextual-title-bold">Welke gebruiker bent u?</div>
                            </div>
                        </div>
                        <div className="row section-field customer-input">
                           <div className="small-12 input-row--salutation"> 
                            <label className="input-wrapper input--radio-button">
                                <input type="radio" checked="checked" name="salutation"/>
                                  Ik ben consument
                                <span class="checkmark"></span>
                            </label>
                            <label className="input-wrapper input--radio-button">
                                <input type="radio" name="salutation"/> 
                                  Ik ben installateur
                                <span className="checkmark"></span>
                            </label>
                           </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> 
                <div className="customer-registration-start">   
                    <div className="form--content"> 
                        <div className="container"> 
                            <div className="resp-tabs-container" style={{ display: "block" }}>
                                <div className={"resp-tab-content " + (this.state.activeTab == 0 ? "resp-tab-content-active" : "")}>
                                    <div className="pure-g row expanded collapse">
                                        <div className="small-12 columns">
                                            <div className="container">
                                                <CustomerSingleForm Title={"test"} data={this.state.singleUpload} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}