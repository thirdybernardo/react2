import React from "react";
import Data from "../Data/Data";
import HelloWorld from "../Components/Demo/HelloWorld";


class Demo extends React.Component{
    constructor(props){
        super(props);

        this.state ={
            pageContent:{
                item: {}
            }            
        };
    }

    componentDidMount(){
        Data.getData("DemoPage", (data)=>{
            this.setState({
                pageContent: data
            });
        });      

      }

    render(){
        return(
            <div>
                <HelloWorld data={this.state.pageContent}/>
            </div>
        );
    }

}

module.exports = Demo;