import React from "react";
import Data from "../Data/Data";
import ThankYou from "../Components/ThankYou/ThankYou";

export default class ThankYouPage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            thankYoudata: {
                item: {}
            },
        };
    }

    componentDidMount() {
        Data.getData("ThankYouFields", (data) => {
            this.setState({ thankYoudata: data });
        });
    }

    render() {
        return (
            <div className="c-reg--main">
                <ThankYou data={this.state.thankYoudata} />
            </div>
        );
    }

}