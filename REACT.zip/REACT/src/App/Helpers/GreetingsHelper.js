export default class GreetingsHelper {

    /**
     * If no parameters supplied, the default greetings in english will be used
     * */
    static getVerbalGreeting(morningGreeting = "Good morning", afternoonGreeting = "Good afternoon", eveningGreeting = "Good evening") {
        var today = new Date();
        var curHr = today.getHours();

        if (curHr < 12) {
            return morningGreeting;
        } else if (curHr < 18) {
            return afternoonGreeting;
        } else {
            return eveningGreeting;
        }
    }
}

