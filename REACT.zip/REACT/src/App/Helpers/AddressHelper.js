import axios from "axios";

var _delayTimer = null;
var _timeout = 150;

export default class AddressHelper {

    static getAddressInfo(post_code, house_number, callback) {
        if (post_code && house_number) {

            clearTimeout(_delayTimer);

            //Will not perform an API call under [_timeout (300ms)] to prevent heavy requests when typing
            _delayTimer = setTimeout(() => {

                //Replaces all whitespaces
                post_code = post_code.replace(/ /g, '');
                house_number = String(house_number).replace(/ /g, '');

                var apiUrl = "https://geodata.nationaalgeoregister.nl/locatieserver/free";
                var params = ["fq=postcode:" + post_code, "fq=huis_nlt:" + house_number];

                var jsonUrl = apiUrl + "?" + params.join("&");

                axios.get(jsonUrl)
                    .then((data) => {
                        callback(data.data);
                    }).catch((error) => {
                        console.log("getAddressInfo: " + error);
                        callback(null);
                    });
            }, _timeout);
        }
    }
}
