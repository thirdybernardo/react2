import QueryString from '../Data/QueryString';
import InstallerAPI from '../API/Installer';

export default class InstallerHelper {
    static GetInstallerId(isSitecore, callback) {
        let installerId = null;
        if (!isSitecore) {
            installerId = QueryString.getValue("installerid");
            if (installerId != null && installerId != "")
                callback(installerId);
            else
                callback("Failed to retrieve installer id");
        }
        else {
            // Retrieve installer id using Azure B2C context, temporarily using query string too
            installerId = QueryString.getValue("installerid");
            if (installerId != null && installerId != "")
                callback(installerId);
            else
                callback("Failed to retrieve installer id");
        }
    }

    static getUnfinishedRegistrationsCount(installerID) {
        // Scaffolding for getting number of Unfinished Registrations of a specific Installer
        let _return = undefined;
        // Fake into 1, return undefined if installerID is null or in any type of exception 
        // so it can be easily handled by receiving component using isNaN
        _return = 1;
        return _return;
    }

}