import axios from "axios";

var _delayTimer = null;
var _timeout = 150;

export default class ProductCategoryHelper {

    static getDefinition(obj) {
        let _category = null;
        if (obj) {
            _category = obj.Category.toUpperCase();
        }
        switch (_category) {
            case "WHB":
                return "ketel";
            case "HWB":
                return "ketel";
            case "HS":
                return "warmtepomp";
            case "HP":
                return "warmtepomp";
            case "SS":
                return "zonlicht systemen";

        }
    }
}
