import validator from  '../Helpers/Validator';

export default class ValidationHelper {
    static checkIfFieldIsValid(type, event) {
        let isValid = true;
        validator[type].valid = true;
        if(event)
            validator[type].rules.forEach((rule) => {
                if (rule.validate instanceof RegExp) {
                    if (!rule.validate.test(event)) {
                        validator[type].valid = false;
                        isValid = false;
                    }
                }
            });

        return isValid;
    }
}