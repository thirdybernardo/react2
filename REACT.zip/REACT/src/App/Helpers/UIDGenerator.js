//See docs if wanted to exented more: https://www.npmjs.com/package/uuid
export default class UIDGenerator {
    static Generate() {
        const uuid = require('uuid/v1'); //Version 1 : Timestamp GUID => Ex: '45745c60-7b1a-11e8-9c9c-2d42b21b1a3e'
        return uuid(); 
    }
}
