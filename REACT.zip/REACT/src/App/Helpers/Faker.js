export default class Faker {
    static fakePromise(_duration, _text){
        return new Promise((resolve, reject) => {
            setTimeout(function() {
                resolve('Mock promise finished executing - ' + _text);
              }, parseInt(_duration));
        });
    }
}