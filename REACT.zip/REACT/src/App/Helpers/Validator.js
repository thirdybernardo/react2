const validator = {
    email: {
        rules: [
            {
                validate: /^[^!-=+_#$%^&*!?/<>()\[\]\\.,;:\s@"](([^/<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/i,
                message: 'This is an invalid email address' //default validation messages can be replaced
            },
            {
                validate: (value) => {
                    return value.length > 0;
                },
                message: 'Email is invalid',
            }
        ],
        errors: [],
        valid: true,
        state: ''
    },
    telephone: {
        rules: [
            {
                validate: /^((\+|00(\s|\s?\-\s?)?)31(\s|\s?\-\s?)?(\(0\)[\-\s]?)?|0)[1-9]((\s|\s?\-\s?)?[0-9])((\s|\s?-\s?)?[0-9])((\s|\s?-\s?)?[0-9])\s?[0-9]\s?[0-9]\s?[0-9]\s?[0-9]\s?[0-9]$/,
                message: 'This is an invalid telephone format' //default validation messages can be replaced
            },
            {
                validate: (value) => {
                    return value.length > 0;
                },
                message: 'Telephone is invalid',
            }
        ],
        errors: [],
        valid: true,
        state: ''
    },

    website: {
        rules: [
            {
                validate: /^[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
                message: 'This is an invalid website format' //default validation messages can be replaced
            },
            {
                validate: (value) => {
                    return value.length > 0;
                },
                message: 'Website is invalid',
            }
        ],
        errors: [],
        valid: true,
        state: ''
    },

    required: {
        rules: [
            {
                validate: (value) => {
                    return value.length > 0;
                },
                message: 'This field is required'  //default validation messages can be replaced
            }
        ]
    }
};

export default validator;