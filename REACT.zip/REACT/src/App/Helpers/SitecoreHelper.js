export default class SitecoreHelper {
    static getPlaceholderText(context, placeholderValue) {
        if(!context) {
            return placeholderValue;
        }
        return "";
    }

    static getLink(markupString){
        var frame = document.createElement('div');
        frame.innerHTML = markupString;
        return frame.firstChild.href;
    }

    static getFileLink(markupString){
        var frame = document.createElement('div');
        frame.innerHTML = markupString;
        return frame.firstElementChild.attributes.src.value;
    }

    static getImage(markupString){
        if(markupString == "" || markupString == null)
            return "";

        var frame = document.createElement('div');
        frame.innerHTML = markupString;
        return frame.firstChild.src;
    }

    static getNameValuePair(field,isEditing){
        var _keyValue = [];
        if(!isEditing){
            field.map((option,i)=>{
                var array = option.split('=');
                _keyValue.push({
                    Name: array[0].replace('_',' '),
                    Value: (array.length < 2)? "":array[1]
                });

                });
        }
        return _keyValue;
    }
}