import axios from 'axios';
import Mime from 'mime-types';
import XLSX from 'xlsx';

const enums = {
    fileError: {
        genericError: 0,
        hasDuplicateField: 1,
        hasMissingField: 2
    },
    templateFields: {
        PostalCode: "PostalCode",
        HouseNumber: "HouseNumber",
        SerialNumber: "SerialNumber",
        InstallationDate: "InstallationDate",
        FirstName: "Firstname",
        LastName: "Lastname",
        Project: "Project"
    }
};

export default class FileHelper {
    static downloadFile(url, filename, isEditing) {
        var _url = url;
        if (String(_url)[0] != "/") {
            _url = "/" + _url;
        }
        if (!isEditing) {
            axios.get(_url, { responseType: 'blob' })
                .then((data) => {
                    var _ext = Mime.extension(data.data.type);
                    var _filename = filename + "." + _ext;
                    // FileSave uses window object and must only be imported when page is loaded on the browser
                    new Promise(async () => {
                        const FileSaver = await require('file-saver');
                        FileSaver.saveAs(data.data, _filename);
                    });
                })
                .catch(function (error) {
                    if (error.response) {
                        console.log('Download failed!', error.message);
                    }
                });
        }
    }

    // *** Bulk Registration File Upload - Template File Validation **//
    static refineWorkbookCsvJSON(_data, _reqFields, _truncateEmptyRows) {
        let _coll = [];
        let _hasError = false;
        let _emptyRows = true;
        let _dat = !(_data instanceof Array) ? Object.values(_data) : _data;
        let _return = {
            status: "ok",
            data: null,
            code: 0
        };
        _dat.forEach((sheet) => {
            let _entry = {
                fields: [],
                values: [[]]
            };
            if (sheet.length > 1) {
                let _reqFieldIndex = [];
                let _serialNumbers = [];
                let _serialNumberIndex = null;
                sheet.forEach((val, i) => {
                    if (val.length > 0 && !_hasError) {
                        if (i > 0) {
                            let _row = [];
                            // Check if there are duplicate serial number
                            let _currSN = val[_serialNumberIndex];
                            if (_serialNumbers.find((_sn) => { return _sn == _currSN; }))
                                _hasError = true;
                            else
                                _serialNumbers.push(_currSN);
                            // Check if at least one row has values
                            _emptyRows = val.length > 0 ? false : _emptyRows;
                            // Check if there's a missing required field for the rows with values
                            _reqFieldIndex.forEach((_vv) => {
                                if (!val[_vv]) {
                                    _hasError = true;
                                    _return.code = enums.fileError.hasMissingField;
                                }
                            });
                            val.forEach((_v) => {
                                _row.push(_v);
                            });
                            _entry.values[i - 1] = (_row);
                            // Check if there's a null field but row has values that exists for it
                            if (_entry.values[i - 1].length !== _entry.fields.length) {
                                _hasError = true;
                                _return.code = enums.fileError.genericError;
                            }
                        }
                        else {
                            // Check if there's a missing required field for the header
                            _reqFields.forEach((_val) => {
                                if (val.filter((_v) => {
                                    return _val == String(_v).replace(/\s/g, '');
                                }).length == 0) {
                                    _hasError = true;
                                    _return.code = enums.fileError.hasMissingField;
                                }
                            });
                            // Check if a field is duplicate   
                            let _sortedFields = val.map((_val) => {
                                return String(_val).replace(/\s/g, '');
                            }).sort();
                            for (var ix = 0; ix < _sortedFields.length - 1; ix++) {
                                if (!_sortedFields[ix]) {
                                    _hasError = true;
                                    _return.code = enums.fileError.genericError;
                                    break;
                                }
                                if (_sortedFields[ix + 1] == _sortedFields[ix]) {
                                    _hasError = true;
                                    _return.code = enums.fileError.hasDuplicateField;
                                    break;
                                }
                            }
                            // No errors and fields will be ok   
                            _reqFields.forEach((_val) => {
                                val.forEach((_v, _i) => {
                                    if (_val == String(_v).replace(/\s/g, ''))
                                        _reqFieldIndex.push(_i);
                                    if (enums.templateFields.SerialNumber == String(_v).replace(/\s/g, '') )
                                        _serialNumberIndex = _i;
                                });
                            });
                            val.forEach((_v) => {
                                _entry.fields.push(_v);
                            });
                        }
                    }
                });
            }
            _coll.push(_entry);
        });
        // If a duplicate field is found or all rows don't have values, return status of undefined so promise will fail
        if (_hasError || _emptyRows) {
            _return.status = undefined;
        }
        else {
            _return.data = _coll;
        }
        // Truncate empty rows
        if (_truncateEmptyRows && _return.data) {
            _return.data.forEach((v, i) => {
                _return.data[i].values = v.values.filter((_v) => {
                    return _v != undefined && _v.length > 0;
                });
            });
        }
        return _return;
    }

    static promiseReadWorkbookOrCSV(_data, _reqFields, _truncateEmptyRows) {
        return new Promise((resolve, reject) => {
            let result = {};
            let _jsonResult = {};
            let _workbook = XLSX.read(_data, { type: 'array' });
            _workbook.SheetNames.forEach(function (sheetName) {
                var roa = XLSX.utils.sheet_to_json(_workbook.Sheets[sheetName], { header: 1, defval:"", raw: false });
                if (roa.length) result[sheetName] = roa;
            });
            _jsonResult = FileHelper.refineWorkbookCsvJSON(result, _reqFields, _truncateEmptyRows);
            if (_jsonResult.status){
                let _formattedJson = FileHelper.formatJsonResponse(_jsonResult);
                resolve(_formattedJson);
            }
            else
                reject(_jsonResult);
        });
    }

    static formatJsonResponse(_data) {
        let _response = [];
        _data.data.forEach((_sheet, count) => {
            _sheet.values.forEach((val) => {
                let _row = {};             
                let _matcher = {};
                let _matchedIndex = null;
                let _currentSerialNumber = "";
                val.forEach((_val, x) => {     
                    // Check if postal code and house number matches anything we already have in any row of _reponse   
                    let _currentField = _data.data[count].fields[x].replace(/\s/g, '');
                    if(_currentField == enums.templateFields.SerialNumber)
                        _currentSerialNumber = _val;
                    if (_currentField == enums.templateFields.PostalCode || _currentField == enums.templateFields.HouseNumber ||  _currentField == enums.templateFields.InstallationDate
                            || _currentField == enums.templateFields.FirstName || _currentField == enums.templateFields.LastName || _currentField == enums.templateFields.Project){
                        _response.forEach((_crow, index) => {
                            if(_crow[_currentField] == _val){
                                _matcher[_currentField] = true;
                                _matchedIndex = index;
                            }
                        });
                    }
                    // Add values to a row
                    if (_currentField == enums.templateFields.SerialNumber) {
                        let _arr = [];
                        _arr.push(_val);
                        _row[_currentField] = _arr;
                    }
                    else
                        _row[_currentField] = _val;
                });
                // If installation date, project, postal code and house number matches with a unique customer name, add serial number to matching array otherwise add the row to _response
                // When it matches, the serial number will be added to the first detected entry thus ignoring non-checked items
                // Ex: 1st row has empty email address and a 2nd row with matching serial number will be added to it but it has an email address.. the email address will still be empty because it uses the 1st row's details
                //          Serial Number	Postal Code	House Number	Installation Date	Project	    First Name	Last Name	Email Address	    Telephone Number
                //          1111111111112	4125 RN	    97	            2019-03-03		                Jan	        Sloot	                    	555555555
                //          333333333334	4125 RN	    97	            2019-03-03		                Jan	        Sloot	    j.sloot@gmail.com	555555555
                if (_matcher[enums.templateFields.PostalCode] 
                        && _matcher[enums.templateFields.HouseNumber]
                        && _matcher[enums.templateFields.InstallationDate]
                        && _matcher[enums.templateFields.FirstName]
                        && _matcher[enums.templateFields.LastName]
                        && _matcher[enums.templateFields.Project]) {
                    let _serialColl = _response[_matchedIndex][enums.templateFields.SerialNumber];
                    if (!_serialColl.includes(_currentSerialNumber)) {
                        _serialColl.push(_currentSerialNumber);
                    }
                }
                else {
                    _response.push(_row);
                }
            });
        });
        _data.data = _response;
        return _data;
    }

    static readWorkbookOrCSV(file, _reqFields, _truncateEmptyRows, callback) {
        let _reader = new FileReader();
        _reader.onload = function (e) {
            let _data = e.target.result;
            _data = new Uint8Array(_data);
            FileHelper.promiseReadWorkbookOrCSV(_data, _reqFields, _truncateEmptyRows)
                .then((result) => {
                    callback(result);
                })
                .catch((result) => {
                    callback(result);
                });
        };
        if (file instanceof Blob) {
            _reader.readAsArrayBuffer(file);
        }
    }
    // *** Bulk Registration File Upload - Template File Validation **//

    static exportJsonToWorkbook(sheetName = "Sheet1", fileName, jsonData, format = "xlsx") {

        if (fileName && jsonData && (format === "xlsx" || format === "csv")) {
            /* this line is only needed if you are not adding a script tag reference */
            if (typeof XLSX == 'undefined') XLSX = require('xlsx');

            /* remove file extension in case they are added */
            fileName = fileName.replace(/\.[^/.]+$/, "");

            /* make the worksheet */
            var ws = XLSX.utils.json_to_sheet(jsonData);

            if (format === "xlsx") {
                /* add to workbook */
                var wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, sheetName);

                /* generate an XLSX file */
                XLSX.writeFile(wb, fileName + ".xlsx");
            }
            else {
                /* write workbook (use type 'binary') */
               // var csv = XLSX.utils.sheet_to_csv(ws);    // Commented-out for no-unused-vars in e lint

                //saveAs(new Blob([this.s2ab(csv)], { type: "application/octet-stream" }), fileName + ".csv")
            }
        }
    }

    static s2ab = (s) => {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i !== s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    }
}
