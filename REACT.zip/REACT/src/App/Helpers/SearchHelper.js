import ProductAPI from "../API/ProductRegistration";

var _delayTimer = null;
const _timeout = 150;

export default class SearchHelper {

    static getRegistrations(installerId, q, beginDate, endDate, callback, _overrideTimeout) {
        clearTimeout(_delayTimer);
        if (_overrideTimeout)
            ProductAPI.GetRegistrations(installerId, q, beginDate, endDate, callback);
        else {
            //Will not perform an API call under [_timeout] to prevent heavy requests when typing
            _delayTimer = setTimeout(() => {
                ProductAPI.GetRegistrations(installerId, q, beginDate, endDate, callback);
            }, _timeout);
        }
    }
}
