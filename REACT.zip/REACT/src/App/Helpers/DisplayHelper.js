export default class DisplayHelper {
    static toTitleCase(string) {
        return string.replace(/\w\S*/g, function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    }

    static ChangeInputElemValueProgramatically(inputElement, value, inputProp) {
        var _inputProp = inputProp? inputProp : "value";
        var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, _inputProp).set;
        nativeInputValueSetter.call(inputElement.current, value);
        var ev2 = new Event('input', { bubbles: true });
        inputElement.current.dispatchEvent(ev2);
    }
}