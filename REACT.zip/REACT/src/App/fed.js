import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import 'core-js/shim';
import 'core-js/modules/es6.promise';
import 'core-js/modules/es6.array.iterator';
import 'regenerator-runtime/runtime';
import 'isomorphic-fetch';
import 'axios';

// Layout
import MainLayout from './Views/Layout/MainLayout';

// Pages
import Demo from './Pages/Demo';
import CustomerProductRegistration from './Pages/CustomerProductRegistration';
import InstallerRegistration from './Pages/InstallerRegistration';
import InstalledParkOverview from './Pages/InstalledParkOverview';
import ThankYou from './Pages/ThankYouPage';
import ManageProfile from './Pages/ManageProfile';
import Dashboard from './Pages/Dashboard';

const App = () => (
    <MainLayout>
        <Switch>            
            <Route exact path='/' component={Demo}/> 
            <Route path='/CustomerProductRegistration' component={CustomerProductRegistration}/>            
            <Route path='/InstallerRegistration' component={InstallerRegistration}/>  
            <Route path='/InstalledParkOverview' component={InstalledParkOverview}/>
            <Route path='/ThankYou' component={ThankYou}/>        
            <Route path='/ManageProfile' component={ManageProfile}/>  
            <Route path='/Dashboard' component={Dashboard}/>
        </Switch>
    </MainLayout>
);


ReactDOM.render(
    <BrowserRouter>
        <App />
    </BrowserRouter>,
document.getElementById('app'));