import ProxyData from '../Data/ProxyData';

export default class ProductRegistration {
    static SubmitSingleRegistration(data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");
            ProxyData.postData('api/products/registration/single', data, (response) => {
                let _reponse = Object.assign(response);
                if (callback)
                    callback(_reponse);
                resolve(_reponse);
            }, true);
        });
    }

    static SubmitBulkRegistration(snlimit, data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");
            ProxyData.postData('api/products/registration/bulk?snLimit='  + snlimit, data, (response) => {
                let _reponse = Object.assign(response);
                if (callback)
                    callback(_reponse);
                resolve(_reponse);
            }, true);
        });
    }

    static GetRegistrations(installerId, q, beginDate, endDate, callback) {
        return new Promise((resolve, reject) => {
            if (!installerId)
                reject("Missing installer ID");
            else {
                var apiUrl = "api/products/registered/" + installerId;
                var params = ["q=" + q];
                if (beginDate)
                    params.push("begindate=" + beginDate);
                if (endDate)
                    params.push("enddate=" + endDate);

                var jsonUrl = apiUrl + "?" + params.join("&");

                ProxyData.getData(jsonUrl, (response) => {
                    let _reponse = Object.assign({}, response);
                    if (callback)
                        callback(_reponse);
                    resolve(_reponse);
                }, true);
            }
        });
    }

    static GetInstallerRegisteredProductsCount(installerId, callback) {
        return new Promise((resolve, reject) => {
            if (!installerId)
                reject("Request body is empty");
            ProxyData.getData('api/products/registered/count/' + installerId, (response) => {
                let _reponse = Object.assign(response);
                if (callback)
                    callback(_reponse);
                resolve(_reponse);
            }, true);
        });
    }

    static GetOGP(callback) {
        return new Promise((resolve, reject) => {
            /* CHANGE TO "ProxyData.getData" when in Sitecore */
            ProxyData.getData('api/warranty/extended', (response) => {
                let _reponse = Object.assign(response);
                if (callback)
                    callback(_reponse);
                resolve(_reponse);
            }, true);
        });
    }

    static UpdateProductRegistrationOGP(data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");
            ProxyData.postData('api/warranty/extended/update', data, (response) => {
                let _reponse = Object.assign(response);
                if (callback)
                    callback(_reponse);
                resolve(_reponse);
            }, true);
        });
    }

    static RefineBulkData(snlimit, data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");

            /*
             PLEASE CHANGE THE postDataToSanbox to postData WHEN IN SITECORE MODE
             */

            ProxyData.postData('api/products/registration/bulk/validate?snLimit='  + snlimit, data, (response) => {
                let _reponse = response ? Object.assign(response) : null;
                if (callback)
                    callback(_reponse);
                resolve(_reponse);
            }, true);
        });
    }

}