import ProxyData from '../Data/ProxyData';

export default class ErrorReports {
    static GetFaultDescriptions(data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");
            ProxyData.postData('api/errors/product/faults', data, (response) => {
                let _reponse = Object.assign(response);
                if (callback)
                    callback(_reponse.data);
                resolve(_reponse);
            }, true);
        });
    }

    static CreateProductErrorReport(data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");
            ProxyData.postData('api/errors/product/report/create', data, (response) => {
                let _reponse = Object.assign({}, response);
                if (callback)
                    callback(_reponse.status);
                resolve(_reponse);
            }, true);
        });
    }

}