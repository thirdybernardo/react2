import ProxyData from '../Data/ProxyData';

export default class Installer {
    static GetInstallerInfo(installerId, callback) {
        return new Promise((resolve, reject) => {
            if (!installerId || parseInt(installerId) === 0) {
                reject("Invalid or Missing Installer Id");
            }
            ProxyData.getData('api/installers?installerid=' + installerId, (response) => {
                let _response = response ? Object.assign(response) : null;
                if (callback)
                    callback(_response);
                resolve(_response);
            }, true);
        });
    }

    static UpdateProfileData(installerId, data, callback) {
        return new Promise((resolve, reject) => {
            if (!installerId || parseInt(installerId) === 0) {
                reject("Invalid or Missing Installer Id");
                return null;
            }
            if (!data)
                reject("Request body is empty");
            ProxyData.postData('api/installers?installerid=' + installerId, data, (response) => {
                let _response = response ? Object.assign(response) : null;
                if (callback)
                    callback(_response);
                resolve(_response);
            }, true);
        });
    }

    static GetInstallerProjects(installerId, callback) {
        return new Promise((resolve, reject) => {
            if (!installerId || parseInt(installerId) === 0) {
                reject("Invalid or Missing Installer Id");
            }
            ProxyData.getData('api/projects/installer/' + installerId, (response) => {
                if (callback)
                    callback(response ? response : null);
                resolve(response ? response : null);
            }, true);
        });
    }

    static searchInstaller(installerName, installerLocation, callback) {
        return new Promise((resolve, reject) => {
            if (!installerName && !installerLocation) {
                reject("Missing insaller name and installer location");
            }
            ProxyData.getDataFromLocal(`api/installers/search?installerName=${installerName}&installerLocation=${installerLocation}`, (response) => {
                let _response = response ? Object.assign(response) : null;
                if (callback)
                    callback(_response);
                resolve(_response);
            }, true);
        });
    }

    static searchInstallerByAddress(postalCode, houseNumber, callback) {
        return new Promise((resolve, reject) => {
            if (!postalCode && !houseNumber) {
                reject("Missing insaller name and installer location");
            }
            ProxyData.getDataFromLocal(`api/installers/address/search?postalCode=${postalCode}&houseNumber=${houseNumber}`, (response) => {
                let _response = response ? Object.assign(response) : null;
                if (callback)
                    callback(_response);
                resolve(_response);
            }, true);
        });
    }
}