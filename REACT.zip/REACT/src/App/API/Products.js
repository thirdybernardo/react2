import ProxyData from '../Data/ProxyData';

export default class Products {
    static GetProduct(data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");
            let route = 'api/products?serialNumber=' + data.ProductId + "&snLimit=" + (parseInt(data.snLimit) ? parseInt(data.snLimit) : 11);
            ProxyData.getData(route, (response) => {
                if (callback)
                    callback(response.Result);
                resolve(response.Result);
            }, true);
        });
    }

    static GetProducts(data, callback) {
        return new Promise((resolve, reject) => {
            if (!data)
                reject("Request body is empty");
            let route = 'api/productsonly/all';
            ProxyData.getData(route, (response) => {
                if (callback)
                    callback(response);
                resolve(response);
            }, true);
        });
    }
}