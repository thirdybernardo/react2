import axios from "axios";

export default class ProxyData {
    static getData(route, callback, isAnon) {
        var anonymous = isAnon ? "anonymous" : "";
        var jsonUrl = "/proxy/" + anonymous + "get/" + route;
        axios.get(jsonUrl)
            .then((data) => {
                callback(data.data);
            }).catch(function (err) {
                console.log(err);
                callback(err.response);
            });
    }

    static postData(route, data, callback, isAnon) {
        var anonymous = isAnon ? "anonymous" : "";
        var jsonUrl = "/proxy/" + anonymous + "post/" + route;
        if (String(route).includes("http")) {
            jsonUrl;
        }
        axios(
            {
                method: 'POST',
                url: jsonUrl,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(data)
            }).then(response => {
                callback(response);
            })
            .catch(function (err) {
                console.log(err);
                callback(err.response);
            });
    }

    static postDataToSandbox(route, data, callback, isAnon) {
        var jsonUrl = "http://thesandbox.azurewebsites.net/" + route;
        axios(
            {
                method: 'POST',
                url: jsonUrl,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(data)
            }).then(response => {
                callback(response);
            })
            .catch(function (err) {
                console.log(err);
                callback(err.response);
            });
    }

    static getDataFromLocal(route, callback, isAnon) {
        var jsonUrl = "http://localhost:7071/" + route;
        axios(
            {
                method: 'GET',
                url: jsonUrl,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then((data) => {
                callback(data.data);
            }).catch(function (err) {
                console.log(err);
                callback(err.response);
            });
    }

    static postDataToLocal(route, data, callback, isAnon) {
        var jsonUrl = "http://localhost:7071/" + route;
        if (String(route).includes("http")) {
            jsonUrl;
        }
        axios(
            {
                method: 'POST',
                url: jsonUrl,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify(data)
            }).then(response => {
                callback(response);
            })
            .catch(function (err) {
                console.log(err);
                callback(err.response);
            });
    }

    static getDataFromSandbox(route, callback, isAnon) {
        var jsonUrl = "http://thesandbox.azurewebsites.net/" + route;
        axios(
            {
                method: 'GET',
                url: jsonUrl,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(response => {
                callback(response.data);
            })
            .catch(function (err) {
                console.log(err);
                callback(err.response);
            });

    }
}