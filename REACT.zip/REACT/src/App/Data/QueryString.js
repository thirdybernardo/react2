export default class QueryString {
    static getValue(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }

    static setValue(key, val, isReset) {
        var _qs = "";
        if (!(!key && !val)) {
            if (isReset) {
                _qs = "?" + key + "=" + val;
            }
            else {
                var _tqs = location.search == "" ? "?" : location.search;
                var _tqs2 = "?";
                var _eq = String(_tqs).replace(/\?/g, '').split("&");
                var _exists = false;
                _eq.forEach(function (v, i) {
                    var _pre = (i === 0 ? "" : "&");
                    if (String(v).replace(/\&/g, '').toLowerCase().split("=")[0] == String(key).toLowerCase()) {
                        _exists = true;
                        _tqs2 += _pre + String(v).replace(/\?/g, '').split("=")[0] + "=" + val;
                    }
                    else {
                        _tqs2 += _pre + String(v).replace(/\?/g, '');
                    }
                });
                if (!_exists) {
                    if (_eq.length > 0 && _eq[0] != "") {
                        _tqs += "&";
                    }
                    _tqs += key + "=" + val;
                }
                else {
                    _tqs = _tqs2;
                }
                _qs = _tqs;
            }
        }
        return _qs;
    }
}