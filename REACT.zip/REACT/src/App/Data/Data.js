import axios from "axios";

export default class Data{
    static getData(templateName, callback){
        var jsonUrl = "/Data/json/" + templateName + ".json";
        axios.get(jsonUrl)
            .then((data)=>{
                callback(data.data);
            });
    }
}