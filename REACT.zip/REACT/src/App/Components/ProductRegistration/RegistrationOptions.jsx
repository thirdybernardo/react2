import React, { Component } from "react";
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import CookieHelper from '../../Helpers/CookieHelper';

class RegistrationOptions extends Component {
    constructor(props) {
        super(props);

        this.enums = {
            singleOption: "single-upload",
            bulkOption: "bulk-upload"
        };

        this.state = {
            selectedOption: null,
            rememberOption: false,
            singleImage: null,
            bulkImage: null,
            isInitialized: false
        };

    }

    componentDidMount() {
        if (this.props.isSitecore) {
            this.setState({ 
                singleImage: SitecoreHelper.getImage(this.props.data.item.SingleRegistrationImage), 
                bulkImage: SitecoreHelper.getImage(this.props.data.item.BulkRegistrationImage) 
            });            
        }
    }

    componentDidUpdate(prevProps, prevState){
        if( !this.props.isSitecore && Object.values(this.props.data.item).length > 0 && !this.state.isInitialized){
            this.setState({ 
                isInitialized: true,
                singleImage: this.props.data.item.SingleRegistrationImage, 
                bulkImage: this.props.data.item.BulkRegistrationImage 
            });
        }
    }

    triggerRemember = (e) => {
        this.setState({ rememberOption: e.target.checked });
    }

    triggerSelection = (e) => {
        this.setState({ selectedOption: e.target.value });
    }

    triggerStart = () => {
        let _cookieName = this.props.data.item.CookieName != "" ? this.props.data.item.CookieName : "installerPortalPreferredRegistration";
        let _cookieVal = "";
        if (this.state.rememberOption) {
            _cookieVal = this.state.selectedOption;
        }
        CookieHelper.setCookie(_cookieVal, _cookieName);
        if (!this.props.isSitecore && this.props.callback)
            this.props.callback(this.state.selectedOption);
        else if (this.props.isSitecore) {
            let _id = String(this.props.data.item.TargetID).replace(/\s/g, '');
            let _value = this.state.selectedOption == this.enums.singleOption ? 1 : 2; 
            CookieHelper.setCookie(`${_id}${(_value)}`, _id);
            CookieHelper.setCookie(true, "fromSelection");
            let _target = `${_id}${_value}`;
            location.hash = `${_target}`;
            location.reload();
        }
    }

    render() {
        return (
            <div className="form--content">
                <div className="form--title">
                    <h2 dangerouslySetInnerHTML={{ __html: this.props.data.item.Title }}></h2>
                </div>
                <div className="selection-screen">
                    <div className="contextual-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.Introduction }} />
                    <div className="select-action">
                        {/* Fade should be removed when an option is selected */}
                        <div className={"select-container " + (this.state.selectedOption === this.enums.singleOption ? "" : "fade")}>
                            <input type="radio" name="register-product" id="single-upload" value={this.enums.singleOption} onChange={event => this.triggerSelection(event)} />
                            <label className="reg-select" htmlFor="single-upload">
                                <span className="radio-button"></span>
                                <img src={this.state.singleImage} alt="" />
                                <div className="reg-select--text">
                                    <span className="select-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.SingleRegistrationTitle }} />
                                    <span className="select-description" dangerouslySetInnerHTML={{ __html: this.props.data.item.SingleRegistrationDescription }} />
                                </div>
                            </label>
                        </div>
                        <div className={"select-container " + (this.state.selectedOption === this.enums.bulkOption ? "" : "fade")}>
                            <input type="radio" name="register-product" id="bulk-upload" value={this.enums.bulkOption} onChange={event => this.triggerSelection(event)} />
                            <label className="reg-select" htmlFor="bulk-upload">
                                <span className="radio-button"></span>
                                <img src={this.state.bulkImage} alt="" />
                                <div className="reg-select--text">
                                    <span className="select-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.BulkRegistrationTitle }} />
                                    <span className="select-description" dangerouslySetInnerHTML={{ __html: this.props.data.item.BulkRegistrationDescription }} />
                                </div>
                            </label>
                        </div>
                    </div>
                    <div className={"proceed-selection " + (this.state.selectedOption ? "" : "hide")}>
                        <label className="checkbox-wrapper" htmlFor="user-select">
                            <input type="checkbox" name="user-select" id="user-select" onChange={event => this.triggerRemember(event)} />
                            <span dangerouslySetInnerHTML={{ __html: this.props.data.item.RememberOptionButton }} />
                        </label>
                        <a href="#" className="button arrow-right" onClick={event => this.triggerStart(event)} ><span dangerouslySetInnerHTML={{ __html: this.props.data.item.StartButton }} /></a>
                    </div>
                </div>
            </div>
        );
    }
}

module.exports = RegistrationOptions;
