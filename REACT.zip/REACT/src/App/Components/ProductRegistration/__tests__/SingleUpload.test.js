import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import SingleUpload from '../SingleUpload';
import singleUpload from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import renderer from 'react-test-renderer';
import { equal } from 'assert';

const singleRegistration = shallow(<SingleUpload data={singleUpload}/>);

test('SingleUpload renders the subcomponent', () => {
    // Dynamically import the subcomponent just for the constructor and check if it does not exist yet
    const RegistrationAddress = require ('../../../Components/Forms/RegistrationAddress').default;
    expect(singleRegistration.find(RegistrationAddress).length).toBe(1);

    const ToggleSwitch = require ('../../../Components/Forms/ToggleSwitch').default;
    expect(singleRegistration.find(ToggleSwitch).length).toBe(1);

    const DatePicker = require ('../../../Components/Forms/DatePicker').default;
    expect(singleRegistration.find(DatePicker).length).toBe(1);
});