import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import BulkUpload from '../BulkUpload';
import bulkUploadData from '../../../../../build/Data/json/BulkRegistrationProductFields.json';
import renderer from 'react-test-renderer';

const bulkUpload = shallow(<BulkUpload data={bulkUploadData} />);

test('BulkUpload matches snapshot', () => {
    const tree = renderer.create(
        <BulkUpload data={bulkUploadData} />).toJSON();
    expect(tree).toMatchSnapshot();
});