import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import RegistrationOptions from '../RegistrationOptions';
import registrationOptions from '../../../../../build/Data/json/RegistrationOptionsFields.json';
import renderer from 'react-test-renderer';
import { equal } from 'assert';

const options = shallow(<RegistrationOptions data={registrationOptions}/>);

test("Check data used in component", () => {
    expect(options.instance().props.data.item.Title).toEqual("Registreer uw product(en)");
    expect(options.instance().props.data.item.Introduction).toEqual("{{GivenName}}, hoe wilt u uw product registreren?");
    expect(options.instance().props.data.item.SingleRegistrationImage).toEqual("/images/icons/single-address.svg");
    expect(options.instance().props.data.item.SingleRegistrationTitle).toEqual("Enkel adres");
    expect(options.instance().props.data.item.SingleRegistrationDescription).toEqual("Registreer één of meerdere producten op hetzelfde adres");
    expect(options.instance().props.data.item.BulkRegistrationImage).toEqual("/images/icons/bulk-address.svg");
    expect(options.instance().props.data.item.BulkRegistrationTitle).toEqual("Toevoegen in bulk");
    expect(options.instance().props.data.item.BulkRegistrationDescription).toEqual("Upload een excel bestand met meerdere adressen en producten");
    expect(options.instance().props.data.item.RememberOptionButton).toEqual("Onthoud mijn keuze");
    expect(options.instance().props.data.item.StartButton).toEqual("Starten");
    expect(options.instance().props.data.item.CookieName).toEqual("InstallerPortalPreferredRegistration");
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(<RegistrationOptions data={registrationOptions}/>);
    expect(tree).toMatchSnapshot();
});


test("Renders 2 anchor tag", () => {
    expect(options.find("a")).toHaveLength((1));
});