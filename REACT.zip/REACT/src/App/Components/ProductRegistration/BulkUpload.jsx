import React, { Component } from "react";
import Data from "../../Data/Data";
import BulkFileUpload from "../Forms/BulkFileUpload";
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import BulkAlert from "../Forms/BulkAlert";
import BulkOverview from '../../Components/Forms/BulkOverview';

class BulkUpload extends Component {
    constructor(props) {
        super(props);
        this._ProductSNMonthLimit = "11";
        if (this.props.data.item.ProductSNMonthLimit) {
            this._ProductSNMonthLimit = this.props.data.item.ProductSNMonthLimit;
        }
        this.state = {
            bulkStep: 0,
            tooltipIcon: null,
            isInitialized: false,
            uploaded: [],
            bulkErrorValidation: {
                hasError: false,
                numberOfError: "0"
            },
            entryAnalysationDone: false,
            uploadBasicInfo: {},
            fileName: "",
            productSNMonthLimit: this._ProductSNMonthLimit
        };
    }

    setEntryAnalysation = (isDone, callback) => {
        let _obj = this.state.entryAnalysationDone;

        _obj = isDone;

        this.setState({ entryAnalysationDone: _obj }, () => {
            if (callback)
                callback();
        });
    }

    componentDidMount() {
        //Load proper src of icon in Sitecore on render() while this.props.links is still being fixed
        if (this.props.isSitecore)
            this.setState({ tooltipIcon: SitecoreHelper.getImage(this.props.data.item.TooltipIcon) });
    }

    componentDidUpdate(prevProps, prevState) {
        //Load proper src of icon in React-standalone on render() while this.props.links is still being fixed
        if (this.props.data.item.TooltipIcon != undefined && !this.state.isInitialized && !this.props.isSitecore) {
            this.setState({
                isInitialized: true,
                tooltipIcon: this.props.data.item.TooltipIcon
            });
        }
    }

    setBulkErrorValidation = (hasError, numberOfError) => {
        let _obj = Object.assign(this.state.bulkErrorValidation);

        _obj.hasError = hasError;
        _obj.numberOfError = String(numberOfError);

        this.setState({ bulkErrorValidation: _obj });
    }

    renderContent = () => {
        let _return = null;
        if (this.state.bulkStep == 0) {
            _return = (
                <div className="form--bulk-upload">
                    <div className="tool-tip-info">
                        <a href="javascript:void(0)">
                            <img src={this.state.tooltipIcon} alt="" />
                        </a>
                    </div>
                    <div className="contextual-title-bold">
                        <span dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadTitle }} />
                    </div>
                    <BulkFileUpload
                        data={this.props.data}
                        isSitecore={this.props.isSitecore}
                        isEditing={this.props.isEditing}
                        renderBulkOverView={this.renderBulkOverView}
                        fileName={this.state.fileName}
                        productSNMonthLimit={this.state.productSNMonthLimit}
                    />
                </div>
            );
        }
        else if (this.state.bulkStep == 1) {
            _return = (
                <div className="form--bulk-upload result">
                    <BulkAlert data={this.props.data}
					    tooltipIcon={this.state.tooltipIcon}
                        bulkErrorValidation={this.state.bulkErrorValidation}
                        entryAnalysationDone={this.state.entryAnalysationDone}
                        setEntryAnalysation={this.setEntryAnalysation}
                        isEditing={this.props.isEditing} />
                    <BulkOverview data={this.props.data}
                        uploaded={this.state.uploaded}
                        setBulkErrorValidation={this.setBulkErrorValidation}
                        setEntryAnalysation={this.setEntryAnalysation}
                        isSitecore={this.props.isSitecore}
                        isEditing={this.props.isEditing}
                        fileName={this.state.fileName}
                        uploadBasicInfo={this.state.uploadBasicInfo}
                         returnToBulkUpload={this.returnToBulkUpload}
                         productSNMonthLimit={this.state.productSNMonthLimit}
                    />
                </div>
            );
        }
        return _return;
    }

    returnToBulkUpload = () => {
        this.setState({
            bulkStep: 0
        });
    }

    renderBulkOverView = (uploaded, basicInfo, fileName) => {
        let _bulkStepIncrement = this.state.bulkStep += 1;
        this.setState({
            bulkStep: _bulkStepIncrement,
            uploaded: uploaded,
            uploadBasicInfo: basicInfo,
            fileName: fileName
        });
    }

    render() {
        return (
            <div>{this.renderContent()}</div>
        );
    }
}

module.exports = BulkUpload;