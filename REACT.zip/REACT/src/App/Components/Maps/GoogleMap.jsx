import React from "react";
import GoogleMapReact from 'google-map-react';
import MapMarker from './MapMarker';
import { isNumber, isNullOrUndefined } from "util";


class GoogleMap extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            zoom: 13,
            isInitialized: false
        };
        this._maps = null;
        this._map = null;
        this._circle = null;
    }

    componentDidMount() {
        if (this.props.isSitecore && !this.state.isInitialized) {
            this.initializeValues();
        }
    }

    componentDidUpdate(prevProps) {
        if (!this.props.isSitecore && prevProps.data.item !== this.props.data.item) {
            if (!this.state.isInitialized) {
                this.initializeValues();
            }
        }
        if (prevProps.radius !== this.props.radius) {
            this.adjustRadius(this.props.radius);
          
        }

        if (prevProps.addressResult !== this.props.addressResult) {
            this.adjustCirclePosition();
        }
    }


    apiIsLoaded = (map, maps) => {
        //Assign map and maps context globally
        this._map = map;
        this._maps = maps;
        this.createMapCircle(map, maps);
    };

    createMapCircle = (map, maps) => {
        this._circle = new maps.Circle({
            strokeColor: this.props.data.item.CircleStrokeColor,
            strokeOpacity: this.props.data.item.CircleStrokeOpacity,
            strokeWeight: this.props.data.item.CircleStrokeWeight,
            fillColor: this.props.data.item.CircleFillColor,
            fillOpacity: this.props.data.item.CircleFillOpacity,
            map,
            center: {
                lat: this.props.config.DefaultLatitude,
                lng: this.props.config.DefaultLongitude
            },
            radius: parseFloat(this.props.data.item.InitialRadius)
        });

        {/*When True, default zoom will be disregarded*/ }
        if (this.props.data.item.FitBoundsOnInitialize) {
            this.fitBounds(map, this._circle);
        }
    }

    //Automatically zoom in/out upon changing the radius
    fitBounds = (map, circle) => {
        map.fitBounds(circle.getBounds());
    }

    initializeValues = () => {
        this.setState({
            //longitude: this.props.config.DefaultLongitude,
            //latitude: this.props.config.DefaultLatitude,
            zoom: parseFloat(this.props.data.item.DefaultZoom),
            isInitialized: true
        });
    }

    adjustRadius = (rad) => {
        if (rad) {
            try {
                this._circle.setRadius(parseFloat(rad));
                this.fitBounds(this._map, this._circle);
            }
            catch{ }
        }
    }


    adjustCirclePosition = () => {
        try {
            this._circle.setCenter({ lat: this.props.config.DefaultLatitude, lng: this.props.config.DefaultLongitude });
            //this.fitBounds(this._map, this._circle)
        }
        catch{ }
    }

    renderMap = () => {
       
        if (this.state.isInitialized && this.props.config.ApiKey != "") {
            return (
                <GoogleMapReact
                    bootstrapURLKeys={{ key: this.props.config.ApiKey, language: this.props.config.language }}
                    center={{ lat: this.props.config.DefaultLatitude, lng: this.props.config.DefaultLongitude }}
                    defaultZoom={this.state.zoom}
                    yesIWantToUseGoogleMapApiInternals
                    onGoogleApiLoaded={({ map, maps }) =>
                        this.apiIsLoaded(map, maps)
                    }
                >
                    {/*Can be multiple markers*/}
                    <MapMarker
                        lat={this.props.config.DefaultLatitude}
                        lng={this.props.config.DefaultLongitude}
                    />
                </GoogleMapReact>
            );
        }
    }

    render() {
        return (
            // Important! Always set the container height explicitly
            <div style={{ height: '100%', width: '100%' }} >
                {this.renderMap()}
            </div >
        );
    }
}

module.exports = GoogleMap;