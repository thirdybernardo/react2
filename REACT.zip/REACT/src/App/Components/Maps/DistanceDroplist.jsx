﻿import React from 'react';
import CustomDroplist from '../Generic/CustomDroplist';

class DistanceDroplist extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            labelValue: "",
            droplistInitialized: false,
            selectedDroplist: {
                Text: "",
                Value: ""
            }
        };
    }

    componentDidMount() {
        this.initializeDroplist();
    }

    componentDidUpdate(prevProps) {
        if (prevProps.sliderDistanceText !== this.props.sliderDistanceText) {
            var _sliderSelected = {
                Text: this.props.sliderDistanceText,
            };
            this.setState({ selectedDroplist: _sliderSelected });
        }
    }

    initializeDroplist = () => {
        if (!this.state.droplistInitialized && this.props.distanceList[0].Value && this.props.distanceList[0].Text) {
            this.setState({ droplistInitialized: true }, () => {
                let _selected = Object.assign(this.state.selectedDroplist);
                _selected.Value = this.props.distanceList[0].Value;
                _selected.Text = this.props.distanceList[0].Text;
                this.setState({ selectedDroplist: _selected }, () => {
                    this.props.callback(_selected, this.props.dataRef, this.props.callbackKey);
                });
            });
        }
    }

    handleChange = (e, identifier, val) => {
        this.setState({ selectedDroplist: val });
    }

    render() {
        return (
            <div className={this.props.wrapperClass}>
                <label><span dangerouslySetInnerHTML={{ __html: this.props.title }} /></label>
                <CustomDroplist
                    dataRef={this.props.dataRef}
                    containerClass=""
                    list={this.props.distanceList}
                    selected={this.state.selectedDroplist}
                    action={this.handleChange}
                    callback={this.props.callback}
                    callbackKey={this.props.callbackKey}
                    identifier="_paginationSlicer"
                />
            </div>
        );
    }

}

module.exports = DistanceDroplist;