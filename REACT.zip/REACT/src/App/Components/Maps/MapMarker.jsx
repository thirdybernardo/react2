/*
 * TODO: MAKE COMPONENT CONTENT MAINTAINABLE
 * ADD LOGIC THAT CAN MAKE USE OF PNG OR ICON FILES
 * */

import React from "react";

class MapMarker extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <React.Fragment>
                <i
                    style={{ fontSize: "20px", position: "absolute", right: "-13px", top: "-10px" }}
                    className="fa fa-map-marker"
                />
            </React.Fragment>
        );
    }
}

module.exports = MapMarker;