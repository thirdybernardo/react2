import React from "react";

class Card extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
        };
    }

    getLink = () => {
        let _linkEvent = !this.props.linkEvent ? "#" : this.props.linkEvent;
        let _link = (!this.props.linkVisible || !this.props.linkText) ? ""
            : (<a href={_linkEvent} className={this.props.linkClass}>
                <span dangerouslySetInnerHTML={{ __html: this.props.linkText }} />
            </a>);
        return _link;
    }

    render() {
        return (
            <div className={"columns " + (!this.props.columnSize ? "large-3" : this.props.columnSize)}>
                <div className={this.props.containerClass}>
                    <div className="reg-box--section">
                        <p className="reg-box--title" dangerouslySetInnerHTML={{ __html: this.props.title}} />
                        <p className="reg-box--content" dangerouslySetInnerHTML={{ __html: this.props.content}} />
                    </div>
                    {this.getLink()}
                </div>
            </div>
        );
    }

}

module.exports = Card;