import React from 'react';
import Data from '../../Data/Data';
import SH from '../../Helpers/SitecoreHelper';

class SearchBox extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
        };
    }

    componentDidMount() {
    }

    searchChange = (e) => {
        if(this.props.onChangeFunc)
            this.props.onChangeFunc(e);
    }


    render() {
        return (
            <div className={this.props.wrapperClass}>
                <label><span dangerouslySetInnerHTML={{__html: this.props.title}} /></label>
                <div className={this.props.searchClass}>
                    <input type="text" placeholder={SH.getPlaceholderText(this.props.isEditing, this.props.searchPlaceholder)} onChange={event => this.searchChange(event)} ref={this.props.dataRef}/>
                </div>
            </div>
        );
    }

}

module.exports = SearchBox;