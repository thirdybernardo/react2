import React from "react";

class Pagination extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            paginationEllipsisLimits: [0, 0, 0, 0],
            isInitialized: false
        };

        this.windowWidth = null;
        this.widthDivisor = 40;
    }

    componentDidMount(){
        this.windowWidth = window.innerWidth;
        switch(this.windowWidth){
            case (this.windowWidth >= 1367): 
                this.widthDivisor = 53;
                break;
            case (this.windowWidth >= 360 && this.windowWidth <= 767):
                this.widthDivisor = 33;
                break;                
            // widths that falls under 1366-768 and 359 below will be 40
        }
    }

    componentDidUpdate(prevProps){
        if(prevProps.paginationOptions.resultKeysCount != this.props.paginationOptions.resultKeysCount){
            this.computePaginationEllipsis(this.props.paginationOptions.targetPagination);
        }
    }

    paginate = (e, optionalDirection) => {        
        e.preventDefault();
        let targetPagination = null;
        if(e.target.childNodes[0] != undefined && e.target.childNodes[0].length > 0 && !isNaN(e.target.childNodes[0].data)){
            let eventData = e.target.childNodes[0].data;
            targetPagination = parseInt(eventData);
            this.props.updatePaginationOptions(["currentPagination:" + parseInt(eventData)]);
        }
        else {
            let newCurrentPagination = this.props.paginationOptions.currentPagination;
            optionalDirection.toLowerCase() == "left" ? newCurrentPagination-- : newCurrentPagination++;
            this.props.updatePaginationOptions(["currentPagination:" + parseInt(newCurrentPagination)]);
            targetPagination = newCurrentPagination;
        }
        this.computePaginationEllipsis(targetPagination);
    }

    computePaginationEllipsis = (targetPagination, callback) => {
        if (this.props.paginationOptions.resultKeysCount > 0) {
            let xMAx = (targetPagination - 2) <= 2 ? 2 : (targetPagination - 2);
            let yMin = parseInt(targetPagination) + 2;
            let tempPaginationEllipsisLimits = [2, xMAx, yMin, this.props.paginationOptions.resultKeysCount - 1];
            this.setState({ paginationEllipsisLimits: tempPaginationEllipsisLimits });
            if(callback)
                callback();
        }
    }

    renderPagination = () => {
        let pagination = null;
        let pageNumbers = [];
        let currNumber = 1;
        let ellipsisControls = [false, false];
        let maxNormalPagination = this.windowWidth != null ? Math.round(this.windowWidth / this.widthDivisor) : undefined;
        if (this.props.paginationOptions.totalPagination) {
            while (currNumber <= this.props.paginationOptions.totalPagination) {
                let ellipsisMarkup = (<li key={currNumber}><a>...</a></li>);
                if(this.props.paginationOptions.totalPagination <= maxNormalPagination){
                    pageNumbers.push(
                        <li className={currNumber == this.props.paginationOptions.currentPagination ? "active" : ""} key={currNumber}>
                            <a href={currNumber != this.props.paginationOptions.currentPagination ? "#" : undefined} onClick={currNumber != this.props.paginationOptions.currentPagination ? event => this.paginate(event) : undefined}>{currNumber}</a>
                        </li>
                    );
                }
                else{
                    if  ((currNumber == 1 || currNumber == this.props.paginationOptions.totalPagination) || 
                        (currNumber >= (parseInt(this.props.paginationOptions.currentPagination) - 1) && currNumber <= (parseInt(this.props.paginationOptions.currentPagination) + 1))){
                            pageNumbers.push(
                                <li className={currNumber == this.props.paginationOptions.currentPagination ? "active" : ""} key={currNumber}>
                                    <a href={currNumber != this.props.paginationOptions.currentPagination ? "#" : undefined} onClick={currNumber != this.props.paginationOptions.currentPagination ? event => this.paginate(event) : undefined}>{currNumber}</a>
                                </li>
                            );
                    }
                    else if ((currNumber >= this.state.paginationEllipsisLimits[0] && currNumber <= this.state.paginationEllipsisLimits[1]) && ellipsisControls[0] == false ) {                                             
                        pageNumbers.push(ellipsisMarkup);
                        ellipsisControls[0] = true;
                    }
                    else if ((currNumber >= this.state.paginationEllipsisLimits[2] && currNumber <= this.state.paginationEllipsisLimits[3]) && ellipsisControls[1] == false ) {                                             
                        pageNumbers.push(ellipsisMarkup);
                        ellipsisControls[1] = true;
                    }
                }
                currNumber++;
            }
            if (this.props.paginationOptions.resultKeysCount > 0) {
                pagination =
                    <ul className="pagination--page-list">
                        <li className={(this.props.paginationOptions.currentPagination - 1) > 0 ? "page-prev active" : "page-prev"}>
                            <a href={(this.props.paginationOptions.currentPagination - 1) > 0 ? "#" : undefined} onClick={(this.props.paginationOptions.currentPagination - 1) > 0 ? event => this.paginate(event, "left") : undefined}>
                                <i className="fa fa-arrow-left"></i>
                            </a></li>
                        {pageNumbers}
                        <li className={this.props.paginationOptions.currentPagination <= parseInt(this.props.paginationOptions.totalPagination) - 1 ? "page-next active" : "page-next"}>
                            <a href={this.props.paginationOptions.currentPagination <= parseInt(this.props.paginationOptions.totalPagination) - 1 ? "#" : undefined} onClick={this.props.paginationOptions.currentPagination <= parseInt(this.props.paginationOptions.totalPagination) - 1 ? event => this.paginate(event, "right") : undefined}>
                                <i className="fa fa-arrow-right"></i>
                            </a>
                        </li>
                    </ul>;
            }
        }
        return (
            pagination
        );
    }

    render(){
        return(
            <div className={"page-pagination " + (this.props.paginationOptions.totalPagination > 1 ? "" : "hide")}>
                {this.renderPagination()}
            </div>
        );
    }
}

module.exports = Pagination;