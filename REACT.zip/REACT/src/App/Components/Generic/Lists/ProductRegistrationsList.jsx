import React from 'react';
import SitecoreHelper from '../../../Helpers/SitecoreHelper';
import moment from 'moment';

class ProductRegistrationsList extends React.Component {
    constructor(props) {
        super(props);
    }

    productsList = () => {
        let _list = [];
        if (this.props.list && this.props.isInitialized) {
            let _max = this.props.listSize ? parseInt(this.props.listSize) : null;
            this.props.list.forEach((data, i) => {
                if (_max && i < _max) {
                    if (parseInt(this.props.type) == 1) {
                        // Layout of list for promo-like structure
                        _list.push(
                            <React.Fragment key={i}>
                                <div className="product">
                                    <div className="product__title">{`${data.Product.ProductFamily}, ${data.Product.ProductId}`}</div>
                                    <div className="product__loc">{` ${data.StreetName} ${data.HouseNumber}, ${data.City}`}</div>
                                    <div className="product__date">{`${this.props.placeholders[0]}: ${moment(data.InstallationDate).format("DD MMMM YYYY")}`}</div>
                                    <div className="product__points">{`+${data.Points}`}</div>
                                </div>
                            </React.Fragment>
                        );
                    }
                    else if (parseInt(this.props.type) == 2) {
                        // Layout of list for errorform-like search result structure
                        let _children = React.Children.map(this.props.children, (child, index) => {
                            return React.cloneElement(child, {
                                callback: event => {(this.props.callback ? this.props.callback(event, data) : undefined);}
                            });
                        });
                        _list.push(
                            <React.Fragment key={i}>
                                <div className="result-item">
                                    <div className="product--img">
                                        <img src={data.imageSource ? data.imageSource : undefined} />
                                    </div>
                                    <div className="customer--info">
                                        <p className="customer--name">{`${data.Firstname} ${data.Lastname}`}</p>
                                        <p className="customer--address">{data.StreetName}</p>
                                    </div>
                                    <div className="product--info">
                                        <p className="product--title">{data.Product.Name}</p>
                                        <p className="product--serial">{data.Product.ProductId}</p>
                                    </div>
                                    {_children}
                                </div>
                            </React.Fragment>
                        );
                    }
                    else {
                        // Default layout for list
                        _list.push(
                            <React.Fragment key={i}>
                                <div className="registered-product--img">
                                    <img src={data.imageSource ? data.imageSource : undefined} />
                                </div>
                                <div className="registered-product--details">
                                    <a className="registered-product--title" href="#">{data.Product.Name}</a>
                                    <div className="registered-product--serial">{data.Product.ProductId}</div>
                                    <div className="registered-product--address">{` ${data.StreetName} ${data.HouseNumber}, ${data.City}`}</div>
                                </div>
                                <div className="registered-product--date">{moment(data.InstallationDate).format("DD-MM-YYYY")}</div>
                            </React.Fragment>
                        );
                    }
                }
            });
        }
        return _list;
    }

    render() {
        return (
            <div className={!this.props.wrapperClass ? "" : this.props.wrapperClass}>
                <div className={!this.props.containerClass ? "registered-product" : this.props.containerClass}>
                    {this.productsList()}
                </div>
            </div>
        );
    }
}

module.exports = ProductRegistrationsList;