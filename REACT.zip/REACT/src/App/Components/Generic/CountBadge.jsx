import React from 'react';

class CountBadge extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className={!this.props.wrapperClass ? "block--icon circle-icon" : this.props.wrapperClass}>{this.props.count}</div>
        );
    }
}

module.exports = CountBadge;

