import React from "react";

class LabeledFields extends React.Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            <React.Fragment>
                <div className="info-label" dangerouslySetInnerHTML={{ __html: this.props.label }}/> 
                <div className="info-value">{this.props.value}</div>
            </React.Fragment>
        );
    }

}

module.exports = LabeledFields;