import React from "react";
import { isNullOrUndefined } from 'util';
import SitecoreHelper from '../../Helpers/SitecoreHelper';

class ToggleInput extends React.Component {
    constructor(props) {
        super(props);
        this._id = "toggle-input";
        this._SwitchYesLabel = "Ja";
        this._SwitchNoLabel = "Nee";
        this._CheckedState = false;

        if (this.props.id) {
            this._id = this.props.id;
        }

        if (this.props.switchYesLabel) {
            this._SwitchYesLabel = this.props.switchYesLabel;
        }

        if (this.props.switchNoLabel) {
            this._SwitchNoLabel = this.props.switchNoLabel;
        }

        this.state = {
            SwitchLabel: this._CheckedState ? this._SwitchYesLabel : this._SwitchNoLabel,
            CheckedState: this._CheckedState
        };
    }

    componentDidMount() {
        if (this.props.defaultChecked) {
            this.overrideDefaultState();
        }
    }

    handleChange = (event) => {
        this.setState({
            CheckedState: event.target.checked,
            SwitchLabel: event.target.checked ? this._SwitchYesLabel : this._SwitchNoLabel
        }, () => {
            this.callback();
        });
    }

    callback = () => {
        let _value = this.state.CheckedState;
        if (this.props.callback)
            this.props.callback(this._id, _value);
    }

    overrideDefaultState = () => {
        this.setState({
            CheckedState: this.props.defaultChecked,
            SwitchLabel: this.props.defaultChecked ? this._SwitchYesLabel : this._SwitchNoLabel
        }, () => {
            this.callback();
        });
    }

    render() {
        let _wrapperClassName = isNullOrUndefined(this.props.wrapperClassName) ? " " : this.props.wrapperClassName;
        let _checked = undefined;
        if (this.props.defaultChecked && this.props.value){
            _checked = this.props.value;
        }
        else if (this.props.defaultChecked && !this.props.value){
            _checked = undefined;
        }
        else if (!this.props.defaultChecked && this.props.value){
            _checked = this.state.SwitchLabel;
        }
        return (
            <React.Fragment>
                <div className={_wrapperClassName}>
                    <input className="switch" type="checkbox"
                        name={this._id}
                        id={this._id}
                        ref={this.props.refData ? this.props.refData : undefined}
                        onChange={this.props.readOnly ? event.preventDefault() : event => this.handleChange(event)}
                        defaultChecked={this.props.value ? undefined : this.props.defaultChecked}
                        onClick={this.props.readOnly ? event => event.preventDefault() : undefined}
                    />
                    <label htmlFor={this._id} dangerouslySetInnerHTML={{ __html: this.state.SwitchLabel }}></label>
                    <p dangerouslySetInnerHTML={{ __html: this.props.label }} />
                </div>
            </React.Fragment>
        );
    }

}

module.exports = ToggleInput;