import React from "react";
import { isNullOrUndefined } from 'util';
import SitecoreHelper from '../../Helpers/SitecoreHelper';

class RadioInput extends React.Component {

    constructor(props) {
        super(props);

        this._id = "radio-input";

        if (this.props.id) {
            this._id = this.props.id;
        }

        this.state = {
            selected: null
        };
    }

    handleClick = (e) => {
        this.setState({ selected: e.target.value }, () => {
            this.callback();
        });

    }

    callback = () => {
        let _value = this.state.selected;
        if (this.props.callback)
            this.props.callback(this._id,_value);
    }

    renderOptionList = (options) => {
        if (options == undefined) return;
        let _return = [];
        let _optionList = [];
        let _options = options.split('&');
        _optionList = SitecoreHelper.getNameValuePair(_options, this.props.isEditing);
        if (this.props.checkedItem) {
            _optionList.map(option => {
                _return.push(
                    <label className="input-wrapper input--radio-button" key={option.Value}>
                        <input
                            type="radio"
                            name={this._id}
                            value={option.Value}
                            onClick={this.props.readOnly ? event => event.preventDefault() : event => this.handleClick(event)}
                            checked={option.Value === this.props.checkedItem ? true : false}
                        />
                        {option.Name}
                        <span className="checkmark"></span>
                    </label>
                );
            });
        }
        return _return;
    }

    render() {
        let _requiredClassName = isNullOrUndefined(this.props.required) ? " " : this.props.required;
        let _wrapperClassName = isNullOrUndefined(this.props.wrapperClassName) ? " " : this.props.wrapperClassName;

        return (
            <React.Fragment>
                <label className={_requiredClassName + _wrapperClassName} htmlFor={this._id}>
                    <span dangerouslySetInnerHTML={{ __html: this.props.label }} />
                </label>

                <div className="options-list">
                    {this.renderOptionList(this.props.options)}
                </div>
            </React.Fragment>
        );
    }

}

module.exports = RadioInput;