import React from 'react';

class Content extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }


    render() {
        return (
            <React.Fragment>
                <div className={this.props.wrapperClass ? this.props.wrapperClass : ""}>
                    <div className={this.props.containerClass ? this.props.containerClass : ""}>
                        <h2 className={this.props.titleClass ? this.props.titleClass : ""} dangerouslySetInnerHTML={{__html: this.props.title}} />
                        <div className={this.props.contentClass ? this.props.contentClass : ""}>
                            <p dangerouslySetInnerHTML={{__html: this.props.textContent}} ></p>
                        </div>
                        {this.props.children}
                    </div>
                </div>
            </React.Fragment>
        );
    }

}

module.exports = Content;