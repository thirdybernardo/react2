import React from 'react';

class Block extends React.Component {
    constructor(props) {
        super(props);
    }

    renderPartial = () => {
        let _text = !this.props.text ? undefined :
            (
                <div className={!this.props.textClass ? "block--text" : this.props.textClass} dangerouslySetInnerHTML={{ __html: this.props.text }} />
            );
        return (
            <div className={this.props.containerClass}>
                {_text}
                {this.props.children}
                <div className={!this.props.iconClass ? "block--icon show-for-small-only" : this.props.iconClass}>
                    <img src={this.props.iconSrc ? this.props.iconSrc : undefined} />
                </div>
            </div>
        );
    }

    render() {
        let _block = !this.props.columnSize ? this.renderPartial() : (
            <div className={`columns ${this.props.columnSize}`}>
                {this.renderPartial()}
            </div>
        );
        return (
            <React.Fragment>
                {_block}
            </React.Fragment>
        );
    }
}

module.exports = Block;