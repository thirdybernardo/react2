import React from "react";
import { isNullOrUndefined } from 'util';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import ValidationHelper from '../../Helpers/ValidationHelper';
import DisplayHelper from '../../Helpers/DisplayHelper';
import Validator from "../../Helpers/Validator";

class TextInput extends React.Component {
    constructor(props) {
        super(props);

        this._id = "text-input";
        this.validators = Validator;


        if (this.props.id) {
            this._id = this.props.id;
        }

        this.state = {
            value: null,
            validation: "",
            classValidation: ""
        };
    }

    inputChanged = (event) => {
        let _numbersOnly = /^[0-9\b]+$/;
        let _numbersOnlyPassed = _numbersOnly.test(event.target.value);
        let _val = event.target.value;
        if (this.props.numbersOnly && !_numbersOnlyPassed) {
            _val = event.target.value == "" ? null : this.state.value;
            this.props.refData.current.value = event.target.value == "" ? null : this.state.value;
        }
        this.setState({ value: _val }, () => {
            this.callback();
        });
    }

    callback = () => {
        let _value = this.state.value;
        if (this.props.type && this.props.validate && (_value || this.props.type === "required")) {
            _value = this.getFieldValidation(this.props.type, _value);
        }
        else {
            this.resetField();
        }

        if (this.props.callback)
            this.props.callback(this._id, _value);
    }

    getFieldValidation = (type, event, callback) => {
        let _validation = this.state.validation;
        let _classValidation = this.state.classValidation;
        let _isValid = ValidationHelper.checkIfFieldIsValid(type, event);

        if (!_isValid) {
            _validation = this.props.errorMessage ? this.props.errorMessage : this.validators[this.props.type].rules[0].message;
            _classValidation = "error";
        } else {
            _validation = "";
            _classValidation = "success";
        }
        if (type === "required" && !event) {
            _validation = this.props.errorMessage ? this.props.errorMessage : this.validators[this.props.type].rules[0].message;
            _classValidation = "error";
        }
        this.setState({
            validation: _validation,
            classValidation: _classValidation
        });

        if (_isValid)
            return event;
        else
            return "<<invalid-input>>";
    }

    resetField = (callback) => {
        this.setState({
            validation: " ",
            classValidation: " "
        });
    }

    displayValidationMessages = () => {
        let _return = null;
        if (this.state.validation != "")
            _return = (
                <span className="input-validation error">{this.state.validation}</span>
            );
        return _return;
    }

    render() {
        let _requiredClassName = isNullOrUndefined(this.props.required) ? " " : this.props.required;
        let _wrapperClassName = isNullOrUndefined(this.props.wrapperClassName) ? " " : this.props.wrapperClassName;
        let _classValidation = isNullOrUndefined(this.props.classValidation) ? this.state.classValidation : this.props.classValidation;
        let _inputHtml = this.props.isTextArea
            ? (
                <textarea
                    ref={this.props.refData ? this.props.refData : undefined}
                    id={this._id}
                    onChange={event => this.inputChanged(event)}
                    onKeyUp={event => { this.props.keyUp ? this.props.keyUp(event) : undefined; }}
                    placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.placeholder)}
                    value={this.props.value}
                />
            )
            : (
                <input
                    ref={this.props.refData ? this.props.refData : undefined}
                    className="has-default"
                    type="text"
                    id={this._id}
                    onChange={event => this.inputChanged(event)}
                    onKeyUp={event => { this.props.keyUp ? this.props.keyUp(event) : undefined; }}
                    placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.placeholder)}
                    value={this.props.value ? this.props.value : undefined}
                    maxLength={this.props.maxLength ? this.props.maxLength : undefined}
                    readOnly={this.props.readOnly ? "readonly" : undefined}
                />
            );
        return (
            <React.Fragment>
                <label htmlFor={this._id} className={_requiredClassName + _wrapperClassName}>
                    <span dangerouslySetInnerHTML={{ __html: this.props.label }} />
                </label>
                <label htmlFor={this._id} className={"input-wrapper " + _classValidation}>
                    {_inputHtml}
                </label>
                {this.props.validate ? this.displayValidationMessages() : ""}
            </React.Fragment>
        );
    }

}

module.exports = TextInput;