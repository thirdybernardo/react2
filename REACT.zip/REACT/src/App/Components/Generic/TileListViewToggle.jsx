import React from 'react';

class TileListViewToggle extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isTileView: false,
            isInitialized: false
        };
    }

    componentDidUpdate = () => {
        if (!this.state.isInitialized && this.props.data) {
            this.setState({ isInitialized: true }, () => {
                this.triggerTableViewChange(null, this.props.data.item.TableViewTileByDefault);
            });
        }
    }

    triggerTableViewChange = (e, val) => {
        this.setState({ isTileView: val}, () => {
            if(this.props.callback)
                this.props.callback(this.state.isTileView, this.props.dataRef, this.props.callbackKey);
            this.props.reInitChildComponent(true);
        });
    }

    renderTileView = () => {
        let _return = "";
        let _entries =[];
        _return.push(
        );
        _return = (            
            <div className="product-table--tile">
                {_entries}
            </div>
        );
        return _return;
    }

    render() {
        return (
            <div className={this.props.wrapperClass}>
                <label><span dangerouslySetInnerHTML={{ __html: this.props.title }} /></label>
                <div className={this.props.tableViewToggleClass}>
                    <button className={this.state.isTileView == false ? "" : "active"} onClick={event => this.triggerTableViewChange(event, true)}>
                        <i className="icons icon-tile-view"></i>
                    </button>
                    <button className={this.state.isTileView == true ? "" : "active"} onClick={event => this.triggerTableViewChange(event, false)}>
                        <i className="icons icon-list-view"></i>
                    </button>
                </div>
            </div>
        );
    }

}

module.exports = TileListViewToggle;