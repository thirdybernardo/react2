import React from "react";


class Modal extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
        };

        this.enums = {
            Type: {
                BO: "BulkEditEntry",
                IPO: "InstalledParkOverview",
                EF: "ErrorForm",
                EF2: "ErrorForm2",
                SC: "SuccessModal"
            }
        };
        this.topArea = React.createRef();
    }



    executeCallback = (e) => {
        if (this.props.callback)
            this.props.callback(e);
        else
            return undefined;
    }

    getProperClasses = () => {
        let _return = {};
        switch (this.props.type) {
            case (this.enums.Type.IPO):
                _return.modalClass = "modal--content small-right";
                break;
            case (this.enums.Type.BO):
                _return.modalClass = "product-registration";
                break;
            case (this.enums.Type.EF):
                _return.modalClass = "error-report";
                break;
            case (this.enums.Type.EF2):
                _return.modalClass = "modal--content small-left ";
                break;
            case (this.enums.Type.SC):
                _return.modalClass = "error-success ";
                break;
        }
        return _return;
    }

    renderContent = () => {
        if (this.props.modalContent) {
            return this.props.modalContent(this.resetTopScroll);
        }
        return (
            <h1>Hi! Please add content through my <code>innerContent</code> props</h1>
        );
    }

    closeEvent = () => {
        if (this.props.closeEvent && this.props.closeId) {
            this.props.closeEvent(this.props.closeId);
        }
    }

    resetTopScroll = () => {
        this.topArea.current.scrollTo(0, 0);
    }

    render() {
        let _classes = this.getProperClasses();
        let _modaClasses = this.props.wrapperClass ? this.props.wrapperClass : "";
        return (
            <div id="modal" className={`modal--container ${_modaClasses}`}>
                <div className="modal--block" />
                <div className="modal--outer">
                    <div className="modal--inner" ref={this.topArea}>
                        <div className={(this.props.noModalContentClass ? "" : "modal--content ") + (_classes.modalClass ? _classes.modalClass : "")}>
                            {
                                this.props.type != this.enums.Type.SC ?
                                    <div className="close" onClick={e => this.closeEvent()} />
                                    : undefined
                            }
                            {this.renderContent()}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

}

module.exports = Modal;