import React from "react";
import File from "../../Helpers/FileHelper";
import SitecoreHelper from '../../Helpers/SitecoreHelper';

class DownloadButton extends React.Component {
    constructor(props) {
        super(props);
    }

    downloadItem = (e) => {        
        let _fileUrl = this.props.fileUrl;
        if(this.props.isSitecore)
            _fileUrl = SitecoreHelper.getFileLink(_fileUrl);
        if(!this.props.isEditing)
            File.downloadFile(_fileUrl, this.props.fileName, this.props.isEditing);
    }

    render() {
        return (
            <React.Fragment>
                <a href="javascript:void(0)" className={this.props.className} onClick={event => this.downloadItem(event)}>
                    <span dangerouslySetInnerHTML={{ __html: this.props.text }} />
                </a>
            </React.Fragment>
        );
    }

}

module.exports = DownloadButton;