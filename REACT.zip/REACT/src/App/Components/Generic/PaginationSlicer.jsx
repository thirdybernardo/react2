import React from 'react';
import CustomDroplist from './CustomDroplist';

class PaginationSlicer extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            labelValue: "",
            droplistInitialized: false,
            selectedDroplist: {
                Text: "",
                Value: ""
            }
        };
    }

    componentDidMount() {
        this.initializeSlicer();
    }

    componentDidUpdate() {
        this.initializeSlicer();        
    }

    initializeSlicer = () => {
        if (!this.state.droplistInitialized && this.props.slices[0].Value && this.props.slices[0].Text){
            this.setState({ droplistInitialized: true }, () => {
                let _selected = Object.assign(this.state.selectedDroplist);
                _selected.Value = this.props.slices[0].Value;
                _selected.Text = this.props.slices[0].Text;
                this.setState({ selectedDroplist: _selected }, () => {
                    this.props.callback(_selected, this.props.dataRef, this.props.callbackKey);
                });
            });
        }
    }

    handleSliceChange = (e, identifier, val) => {
        this.setState({ selectedDroplist: val });
    }

    render() {
        return (
            <div className={this.props.wrapperClass}>
                <label><span dangerouslySetInnerHTML={{__html: this.props.title}} /></label>
                <CustomDroplist
                    dataRef={this.props.dataRef}
                    containerClass=""
                    list={this.props.slices}
                    selected={this.state.selectedDroplist}
                    action={this.handleSliceChange}
                    callback={this.props.callback}
                    callbackKey={this.props.callbackKey}
                    identifier="_paginationSlicer"
                    defaultTextDisplayed={this.props.sliderDistanceText}
                />
            </div>
        );
    }

}

module.exports = PaginationSlicer;