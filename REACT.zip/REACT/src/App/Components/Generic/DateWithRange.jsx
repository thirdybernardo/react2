import React from 'react';
import { DateRange } from 'react-date-range';
import { default as DutchLocale } from 'react-date-range/dist/locale/nl';
import { default as EnUSLocale } from 'react-date-range/dist/locale/en-US';
import moment from 'moment';

class DateWithRange extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            labelValue: "",
            isInitialized: false,
            isUsingDefaultRange: true,
            showDateRange: false,
            selectionRange: [{
                startDate: new Date(),
                endDate: new Date(),
                key: 'selection',
            }],
            browserWidth: 1920 // Temporary value for server processing, will be overridden when rendered on browser
        };
    }

    componentDidMount() {
        this.setState({
            isInitialized: true,
            browserWidth: window.outerWidth
        }, () => {
            this.handleSelect(this.props.initRange, true);
        });
    }

    componentDidUpdate(prevProps, prevState) {
        if (!this.state.isInitialized && this.props.initRange) {
            this.setState({ isInitialized: true }, () => {
                this.handleSelect(this.props.initRange, true);
            });
        }
        if (this.props.reInitChild != prevProps.reInitChild) {
            this.props.reInitChildComponent(false, () => {
                if (this.state.isUsingDefaultRange)
                    this.handleSelect(this.props.initRange, true);
            });
        }
    }

    getCalenderLocale = () => {
        switch (this.props.data.item.DatePickerLocale) {
            case "nl": {
                return DutchLocale;
            }
            case "enUS": {
                return EnUSLocale;
            }
            default: {
                return DutchLocale;
            }
        }
    }

    handleSelect = (ranges, preventDefaultRange) => {
        let _selectionRange = [...this.state.selectionRange];
        if(ranges.selection)
            _selectionRange[0] = ranges.selection;
        else
            _selectionRange[0] = ranges;
        this.setState({ selectionRange: _selectionRange}, () => {
            if (!preventDefaultRange)
                this.setState({isUsingDefaultRange: false });
            if (this.props.callback)
                this.props.callback(_selectionRange[0], this.props.dataRef, this.props.callbackKey);
        });
    }

    handleFocusChange = (focus) => {
        if(focus[0] == 0 && focus[1] == 0){
            this.triggerDateRangeVisibility(null, false);
        }
    }

    getDateText = () => {
        let _return = "";
        let _locale = this.props.data.item.DatePickerLocale;
        let _selectionRange = [...this.state.selectionRange];
        if(_selectionRange && _selectionRange[0].endDate || _selectionRange[0].startDate){
            let _startDate = moment(new Date(_selectionRange[0].startDate)).locale(_locale);
            let _endDate = moment(new Date(_selectionRange[0].endDate)).locale(_locale);
            if (moment(_selectionRange[0].startDate).format('DD.MM.YYYY') == moment(this.props.initRange.startDate).format('DD.MM.YYYY')
                && moment(_selectionRange[0].endDate).format('DD.MM.YYYY') == moment(this.props.initRange.endDate).format('DD.MM.YYYY')) {
                    if(this.props.isTileView)
                        _return = this.props.data.item.DateCurrentWeekText;
                    else
                        _return = this.props.data.item.DateCurrentMonthText;
            }
            else if (!this.state.isUsingDefaultRange
                && moment(_selectionRange[0].startDate).format('DD.MM.YYYY') == moment(this.props.fixedRanges[0].startDate).format('DD.MM.YYYY')
                && moment(_selectionRange[0].endDate).format('DD.MM.YYYY') == moment(this.props.fixedRanges[0].endDate).format('DD.MM.YYYY')) {
                _return = this.props.data.item.DateCurrentWeekText;
            }
            else if (!this.state.isUsingDefaultRange
                && moment(_selectionRange[0].startDate).format('DD.MM.YYYY') == moment(this.props.fixedRanges[1].startDate).format('DD.MM.YYYY')
                && moment(_selectionRange[0].endDate).format('DD.MM.YYYY') == moment(this.props.fixedRanges[1].endDate).format('DD.MM.YYYY')) {
                _return = this.props.data.item.DateCurrentMonthText;
            }
            else {
                let _monthFormat = "MMMM";
                if((this.state.browserWidth >= 1200 && this.state.browserWidth <= 1300) || (this.state.browserWidth <= 360))
                    _monthFormat = "MMM";
                _return = `${_startDate.format('D')} ${_startDate.format(_monthFormat)} - ${_endDate.format('D')} ${_endDate.format(_monthFormat)}`;
            }
        }

        return _return;
    }

    triggerDateRangeVisibility = (e, forceControl) => {
        if (forceControl == undefined || forceControl == null){
            let _newState = this.state.showDateRange == false ? true : false;
            this.setState({ showDateRange: _newState });
        }
        else{
            this.setState({ showDateRange: forceControl });
        }
    }

    render() {
        return (
            <div className={this.props.wrapperClass} ref={this.props.dataRef}>
                <label><span dangerouslySetInnerHTML={{ __html: this.props.title }} /></label>
                <label className={this.props.dateFilterClass} onClick={event => this.triggerDateRangeVisibility(event)}>
                    <span>{this.getDateText()}</span>
                </label>
                <DateRange
                    locale={this.getCalenderLocale()}
                    showMonthArrow={false}
                    ranges={this.state.selectionRange}
                    onChange={this.handleSelect}
                    onRangeFocusChange={this.handleFocusChange}
                    showPreview={false}
                    className={this.state.showDateRange == false ? "hide" : ""}
                />
            </div>
        );
    }

}

module.exports = DateWithRange;