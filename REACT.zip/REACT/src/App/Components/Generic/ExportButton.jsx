import React from 'react';
import File from '../../Helpers/FileHelper';

class ExportButton extends React.Component {
    constructor(props) {
        super(props);
    }

    exportItem = (e) => {
        // Do actual export of data into file here, then trigger download using FileHelper
        if (this.props.callback) {
            this.props.callback(e);
        }
    }

    render() {
        return (
            <div className={this.props.wrapperClassName}>
                <a href="javascript:void(0)" className={this.props.className} onClick={event => this.exportItem(event)}>
                    <span dangerouslySetInnerHTML={{ __html: this.props.text }} />
                </a>
            </div>
        );
    }

}

module.exports = ExportButton;