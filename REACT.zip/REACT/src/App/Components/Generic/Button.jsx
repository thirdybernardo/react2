import React from 'react';
import { isNullOrUndefined } from 'util';

class Button extends React.Component {
    constructor(props) {
        super(props);
    }

    renderPartial = () => {
        /*
         * Necessary classes default to the pre-defined classes below
         * if no attributes or props supplied for:
         * (1) wrapperClassName -> for the parent div
         * (2) className -> for the anchor tag
         * (3) text -> for the text displayed by the button
         * */
        let _buttonClassName = isNullOrUndefined(this.props.className) ? "button" : this.props.className;
        let _buttonText = isNullOrUndefined(this.props.text) ? "My Button" : this.props.text;
        return (
            <a href={this.props.link ? this.props.link : "javascript:void(0)"} className={_buttonClassName} onClick={this.props.callback ? (event => this.props.callback(event)) : undefined}>
                <span dangerouslySetInnerHTML={{ __html: _buttonText }} />
            </a>
        );
    }

    render() {
        let _wrapperClassName = isNullOrUndefined(this.props.wrapperClassName) ? "button-wrapper" : this.props.wrapperClassName;
        let _button = !this.props.noWrapper
            ? (<div className={_wrapperClassName}>
                {this.renderPartial()}
            </div>)
            : this.renderPartial();

        return (
            <React.Fragment>
                {_button}
            </React.Fragment>
        );
    }
}

module.exports = Button;