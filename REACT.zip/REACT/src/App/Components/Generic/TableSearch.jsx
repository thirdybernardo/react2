import React from 'react';
import Data from '../../Data/Data';
import SearchBox from './SearchBox';
import DateWithRange from './DateWithRange';
import PaginationSlicer from './PaginationSlicer';
import TileListViewToggle from './TileListViewToggle';
import TileListTable from '../ProductOverview/TileListTable';
import ErrorReport from '../ProductOverview/ErrorReport';
import moment from 'moment';
import SearchHelper from '../../Helpers/SearchHelper';
import QueryString from '../../Data/QueryString';
import Modal from './Modal';
import CustomDroplist from './CustomDroplist';
import ProductAPI from '../../API/ProductRegistration';
import { default as DutchLocale } from 'react-date-range/dist/locale/nl';
import { default as EnUSLocale } from 'react-date-range/dist/locale/en-US';
import Submit from '../Forms/Submit';
import SitecoreHelper from '../../Helpers/SitecoreHelper';

class TableSearch extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            myProducts: [],
            searchKeyword: "",
            refinedMyProducts: [],
            paginationSlice: {
                Text: "1",
                Value: 1
            },
            dateRange: {},
            tileInitDateRange: [{
                startDate: new Date(),
                endDate: new Date(),
                key: 'selection',
            }],
            listInitDateRange: [{
                startDate: new Date(),
                endDate: new Date(),
                key: 'selection',
            }],
            isTileView: true,
            modalOpened: false,
            errorFormModalOpened: false,
            registrationInfo: {},
            selectedOGP: null,
            OGPList: [{}],
            isMobile: false
        };
        this.enums = {
            Type: {
                IPO: "InstalledParkOverview"
            },
            CallbackKeys: {
                paginationSlice: "paginationSlice",
                dateRange: "dateRange",
                isTileView: "isTileView",
                ogpList: "ogpList"
            }
        };

        this.searchKeywordRef = React.createRef();
        this.paginatioSlicerRef = React.createRef();
        this.dateRangeRef = React.createRef();
        this.tableViewToggleRef = React.createRef();
        this.tableRef = React.createRef();
        this.ogpDroplistRef = React.createRef();
    }

    componentDidMount() {
        window.addEventListener("resize", this.resize.bind(this));
        this.resize();

        if (!this.props.isSitecore) {
            // Gets the list of registered products for the a specific installer using mock data.
            // The "MockInstallerRegisteredProducts" mocks registered products for one specific installer only
            Data.getData("MockInstallerRegisteredProducts", data => {
                if(data && data.Registered.length > 0) {
                    this.setState({
                        myProducts: data.Registered.filter( (x) => {
                            return x.IsDisabled === false
                        }),
                        refinedMyProducts: data.Registered.filter( (x) => {
                            return x.IsDisabled === false
                        })
                    }, () => {
                        this.handleSearch(this.state.searchKeyword)
                    })
                }
            })
            this.getOGPList() // REMOVE THIS WHEN INTEGRATING IN SITECORE BECAUSE RMH REACT-ONLY CANNOT CALL APIs
        } else {
            //call the actual database to retrieve installed/registered products for a specific installer
            this.getOGPList();
        }
        // Set initial date ranges for Tile View and List View  
        this.setState(function (prevState, props) {
            let _initRange = { key: 'selection' };
            let today = new Date(new Date().setHours(0, 0, 0, 0));
            let day = today.getDay() - 1;
            let date = today.getDate() - day;
            _initRange.startDate = new Date(today.setDate(date));
            _initRange.endDate = new Date(today.setDate(date + 6));
            return { tileInitDateRange: _initRange };
        });
        this.setState(function (prevState, props) {
            let _initRange = { key: 'selection' };
            _initRange.startDate = new Date(moment().startOf('month'));
            _initRange.endDate = new Date(moment().endOf('month'));
            return { listInitDateRange: _initRange };
        });
    }

    getOGPList = () => {
        ProductAPI.GetOGP((result) => {
            let _list = [{}];
            if (result.Results) {
                _list = result.Results.map((val) => {
                    let _val = {};
                    if (val) {
                        _val.Text = String(val.Description);
                        _val.Value = String(val.ServiceId);
                        return _val;
                    }
                });
            }
            this.setState({ OGPList: _list });
        });
    }

    updateOGP = (productId, extendedWarrantyId) => {
        let data = {
            InstallerId: QueryString.getValue("installerid"),
            ProductId: productId,
            WarrantyStatus: "approved",
            ExtendedWarranty: extendedWarrantyId
        };

        ProductAPI.UpdateProductRegistrationOGP(data, () => {
            this.handleSearch(null, this.setRegistrationInfo);
        });
    }

    setRegistrationInfo = () => {
        let _regInfo = this.state.registrationInfo;
        this.state.refinedMyProducts.find((val, ind) => {
            if (val.Product.ProductId == _regInfo.Product.ProductId) {
                this.setState({ registrationInfo: val });
            }
        });
    }

    handleStateChange = (val, ref, callbackKey) => {
        this.setState({ [callbackKey]: val }, () => {
            this.handleSearch();
        });
    }

    reInitChildComponent = (_bool, callback) => {
        this.setState({ reInitChild: _bool }, () => {
            if (callback)
                callback();
        });
    }


    getProperClasses = () => {
        let _return = {};

        switch (this.props.data.item.Type) {
            case (this.enums.Type.IPO):
                _return.searchWrapperClass = "product-overview--box product-overview--search";
                _return.searchClass = "product-overview--search-wrapper";
                _return.DateFilterWrapperClass = "product-overview--box product-overview--date";
                _return.DateFilterClass = "datepicker-wrapper";
                _return.paginationSlicerWrapperClass = "product-overview--box product-overview--sort";
                _return.tableViewToggleWrapperClass = "product-overview--box product-overview--view";
                _return.tableViewToggleClass = "product-overview--view-wrapper";
                _return.tableWrapperClass = "product-overview--table-container";
                break;
        }
        return _return;
    }

    renderConditionalElems = (_classes) => {
        let _return = [];
        if (this.props.data.item.ShowDateFilter) {
            _return.push(
                <DateWithRange
                    key={_return.length + 1}
                    title={this.props.data.item.DatePickerTitle}
                    wrapperClass={_classes.DateFilterWrapperClass}
                    dateFilterClass={_classes.DateFilterClass}
                    data={this.props.data}
                    initRange={this.state.isTileView ? this.state.tileInitDateRange : this.state.listInitDateRange}
                    isTileView={this.state.isTileView}
                    dataRef={this.dateRangeRef}
                    callback={this.handleStateChange}
                    callbackKey={this.enums.CallbackKeys.dateRange}
                    reInitChildComponent={this.reInitChildComponent}
                    reInitChild={this.state.reInitChild}
                    fixedRanges={[this.state.tileInitDateRange, this.state.listInitDateRange]}
                />
            );
        }
        if (this.props.data.item.ShowPaginationSlicer) {
            _return.push(
                <PaginationSlicer
                    key={_return.length + 1}
                    title={this.props.data.item.PaginationTitle}
                    wrapperClass={_classes.paginationSlicerWrapperClass}
                    slices={this.getPaginationSlices()}
                    dataRef={this.paginatioSlicerRef}
                    callback={this.handleStateChange}
                    callbackKey={this.enums.CallbackKeys.paginationSlice}
                />
            );
        }
        if (this.props.data.item.ShowTableViewToggle) {
            _return.push(
                <TileListViewToggle
                    key={_return.length + 1}
                    title={this.props.data.item.TableViewToggleTitle}
                    wrapperClass={_classes.tableViewToggleWrapperClass}
                    tableViewToggleClass={_classes.tableViewToggleClass}
                    data={this.props.data}
                    dataRef={this.tableViewToggleRef}
                    callback={this.handleStateChange}
                    callbackKey={this.enums.CallbackKeys.isTileView}
                    reInitChildComponent={this.reInitChildComponent}
                />
            );
        }
        return _return;
    }


    handleSearch = (val, callback) => {
        let _return = [...this.state.myProducts];
        let _query = "";
        if (val === null || val === undefined)
            _query = this.searchKeywordRef.current.value;
        else if (val.target)
            _query = val.target.value;
        else
            _query = val;
        switch (this.props.data.item.Type) {
            case this.enums.Type.IPO:
                if (!this.props.isSitecore) {
                    _return = [...this.state.myProducts].filter((val) => {
                        return String(val.PostalCode).toLowerCase().replace(/\s/g, '').includes(String(_query).toLowerCase().replace(/\s/g, ''))
                            || String(val.City).toLowerCase().includes(String(_query).toLowerCase())
                            || String(val.StreetName).toLowerCase().includes(String(_query).toLowerCase())
                            || String(val.TelephoneNo).toLowerCase().replace(/\s/g, '').includes(String(_query).toLowerCase().replace(/\s/g, ''))
                            || String(val.Product.KetelType).toLowerCase().includes(String(_query).toLowerCase())
                            || String(val.Product.ProductId).toLowerCase().includes(String(_query).toLowerCase())
                            || String(val.Product.Name).toLowerCase().includes(String(_query).toLowerCase())
                            || String(val.Points).toLowerCase().includes(String(_query).toLowerCase());
                    });
                }
                else {
                    let _startD = moment(new Date(this.state.dateRange.startDate)).format('YYYY-MM-DD');
                    let _endD = moment(new Date(this.state.dateRange.endDate)).format('YYYY-MM-DD');
                    let _installerId = QueryString.getValue('installerid');
                    SearchHelper.getRegistrations(_installerId, _query, _startD, _endD, data => {
                        if (data.Results) {
                            //Filter not rejected Product Registration
                            let filteredProductRegistration = data.Results.filter((x) => {
                                return x.IsDisabled === false
                            })
                            this.setState({ refinedMyProducts: filteredProductRegistration }, () => {
                                this.handleFilter(this.state.refinedMyProducts)
                                if (callback)
                                    callback();
                            });
                        }
                    });
                }

                break;
        }

        if (!this.props.isSitecore) {
            this.setState({ refinedMyProducts: _return }, () => {
                this.handleFilter(this.state.refinedMyProducts);
            });
        }
    }

    handleFilter = (val) => {
        // Apply filtering here then save state before passing to sort
        val = val.filter((_val) => {
            let _currD = moment(new Date(_val.InstallationDate)).format('YYYY-MM-DD');
            let _startModified = moment(new Date(this.state.dateRange.startDate)).subtract(1, 'd').format('YYYY-MM-DD');
            let _endModified = moment(new Date(this.state.dateRange.endDate)).add(1, 'd').format('YYYY-MM-DD');
            return moment(_currD).isBetween(_startModified, _endModified);
        });
        this.setState({ refinedMyProducts: val }, () => {
            this.handleSort(this.state.refinedMyProducts);
        });
    }

    handleSort = (val) => {
        let _val = val.sort((a, b) => {
            return new Date(b.InstallationDate) - new Date(a.InstallationDate);
        });
        this.setState({ refinedMyProducts: _val });
    }

    getPaginationSlices = () => {
        let _return = [{}];
        let _slices = this.props.data.item.PaginationSlices;
        if (_slices) {
            _return = _slices.split("|").map((val) => {
                let _val = {};
                if (!isNaN(val)) {
                    _val.Text = String(val);
                    _val.Value = parseInt(val);
                    return _val;
                }
            });
        }
        return _return;
    }

    modalRenderer = () => {
        if (this.state.modalOpened) {
            return (<Modal
                data={this.props.data}
                closeEvent={this.closeModal}
                closeId={"modalOpened"}
                type={this.props.data.item.Type}
                modalContent={this.modalContent} />);
        }
        else if (this.state.errorFormModalOpened) {
            return (<ErrorReport
                data={this.props.data}
                isSitecore={this.props.isSitecore}
                isEditing={this.props.isEditing}
                preModal={this.props.data.item.PreModalEnabled == 1 ? true : false}
                params={{
                    closeId: "errorFormModalOpened",
                    closeEvent: this.closeModal,
                    productContext: this.state.registrationInfo,
                    returnToProductInfo: () => { this.setState({ modalOpened: true, errorFormModalOpened: false }); }
                }}
            />);
        }
    }

    manageRegistration = (registrationInfo) => {
        if (this.state.registrationInfo !== registrationInfo) {
            this.setState({
                registrationInfo: registrationInfo,
                selectedOGP: null
            }, () => {
                this.setState({ modalOpened: true });
            });
        }
        else {
            this.setState({ modalOpened: true });
        }
    }

    closeModal = (key) => {
        this.setState({
            [key]: false
        });
    }

    getCalenderLocale = () => {
        if (this.props.data.item.DatePickerLocale) {
            return this.props.data.item.DatePickerLocale;
        }
        else {
            return "nl";
        }
    }

    /**
     * Hide OGP Droplist
     */

    hideOGPDropList = () => {
        this.setState({ showOGPList: false });
    }


    _handleOGPList = (e, ogpID, val) => {
        this.setState({ selectedOGP: val });
    }

    addYearToDate = (date, years) => {
        let _date = new Date(date);
        _date.setFullYear(_date.getFullYear() + years);
        return _date;
    }

    replaceTokens = (field, token, tokenValue) => {
        if(!this.props.isEditing && field != undefined)
            return field.replace(token, tokenValue);

        return field;
    }

    modalContent = () => {
        let _info = this.state.registrationInfo;
        if (_info) {
            let _guaranteeSection = "";
            let _projectSection = "";
            let _historySection = "";
            let _ogpSection = "";
            let guaranteeplan = this.replaceTokens(this.props.data.item.GuaranteePlan, "$(guaranteeplan)", String(_info.Product.WarrantyPeriod));
   
            if (_info.Project && _info.Project.ProjectName !== "") {
                _projectSection = (
                    <div>
                        <h4 dangerouslySetInnerHTML={{ __html: this.props.data.item.ProjectInfoTitle }} />
                        <div>
                            <p dangerouslySetInnerHTML={{ __html: `<b>Ja,</b> ${_info.Project.ProjectName} | ${_info.Project.Id}` }} />
                        </div>
                    </div>
                );
            }

            _guaranteeSection = (
                <div>
                    <h4 dangerouslySetInnerHTML={{ __html: this.props.data.item.Guarantee }} />
                    <div>
                        <p dangerouslySetInnerHTML={{ __html: moment(new Date(_info.Product.WarrantyEndDate)).locale(this.getCalenderLocale()).format('D MMMM YYYY') }}></p>
                        <p dangerouslySetInnerHTML={{ __html: `${this.props.data.item.FactoryWarranty}: ${guaranteeplan}` }} />
                    </div>
                </div>
            );

            if (_info.Product.WarrantyEnabled === 1) {
                let _ogpSelectionSection = "";
                let _selectedOGP = "";
                let ogpServiceName = "";
                let ogpEndDate = null;
                let _defaultSelectedOGP = {
                    Text: this.props.data.item.SelectOGPDefault,
                    Value: this.props.data.item.SelectOGPDefault
                };

                if(_info.Product.ServiceName){
                    let ogpPlan = String(_info.Product.WarrantyPeriod) + "+" + String(_info.Product.ServicePlan);
                    ogpServiceName = this.replaceTokens(this.props.data.item.OGPName, "$(guaranteeplan)", ogpPlan);
                    ogpEndDate = this.addYearToDate(_info.Product.WarrantyEndDate, _info.Product.ServicePlan);
                }

                _ogpSelectionSection = (
                    <div className="ogp-selection">
                        <CustomDroplist
                            dataRef={this.ogpDroplistRef}
                            containerClass=""
                            list={this.state.OGPList}
                            selected={!this.state.selectedOGP ? _defaultSelectedOGP : this.state.selectedOGP}
                            action={this._handleOGPList}
                            identifier="_ogpDroplist"
                        />
                        <div>
                            <a className={"button " + (this.state.selectedOGP ? "" : "disabled")} dangerouslySetInnerHTML={{ __html: this.props.data.item.SelectOGPButtonText }} onClick={event => this.updateOGP(_info.Product.ProductId, this.state.selectedOGP.Value)} />
                        </div>
                    </div>
                );

                let statusClass = "";
                let statusMessage = this.props.data.item.NoOGPMessage;
                let ogpDetailsClass = "";
                let ogpImg = "";
                let ogpType = "";

                switch (_info.Product.WarrantyStatus) {
                    case "pending":
                        statusClass = this.props.data.item.OGPPendingStatusClass;
                        statusMessage = this.props.data.item.OGPPendingStatusText;
                        ogpDetailsClass = "ogp-pending";
                        break;
                    case "disapproved":
                        statusClass = this.props.data.item.OGPFailedStatusClass;
                        statusMessage = this.props.data.item.OGPFailedStatusText;
                        ogpDetailsClass = "ogp-pending";
                        break;
                    case "approved":
                        statusClass = this.props.data.item.OGPSuccessStatusClass;
                        statusMessage = this.props.data.item.OGPSuccessStatusText;
                        break;
                }

                switch (_info.Product.ExtendedWarranty) {
                    case 1:
                        ogpImg = SitecoreHelper.getImage(this.props.data.item.OGPBronsImg);
                        ogpType = this.props.data.item.OGPBronsLabel;
                        break;
                    case 2:
                        ogpImg = SitecoreHelper.getImage(this.props.data.item.OGPZilverImg);
                        ogpType = this.props.data.item.OGPZilverLabel;
                        break;
                    case 3:
                        ogpImg = SitecoreHelper.getImage(this.props.data.item.OGPGoudImg);
                        ogpType = this.props.data.item.OGPGoudLabel;
                        break;
                }

                _selectedOGP = (
                    <div className={"ogp-details " + ogpDetailsClass}>
                        <div className="ogp-details--image">
                            <img src={ogpImg} alt="" />
                        </div>
                        <div className="ogp-details--desc">
                            <h4>{ogpType}</h4>
                            <p>{ogpServiceName}</p>
                            <p>
                                <span dangerouslySetInnerHTML={{ __html: this.props.data.item.OGPEndDateLabel }} />
                                <span> {ogpEndDate ? moment(new Date(ogpEndDate)).locale(this.getCalenderLocale()).format('D MMMM YYYY') : ""} </span>
                            </p>
                        </div>
                    </div>
                );

                _ogpSection = (
                    <div className="warranty-details">
                        <div className="contextual-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.AdditionalWarrantyTitle }} />
                        <div className={"warranty-message " + statusClass}>
                            <p>{statusMessage}</p>
                        </div>
                        {!_info.Product.WarrantyStatus || String(_info.Product.WarrantyStatus).toLowerCase() =="disapproved" ? (_ogpSelectionSection) : (_selectedOGP)}
                    </div>
                );
            }

            /**
             * To Render dynamically
             * Values are harcoded at the moment
             * Implementation TBD
             **/
            _historySection = (
                <div className="history">
                    <div className="contextual-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.HistoryTitle }} />
                    <div className="history-list">
                        <p><span className="history-date">00-00-0000</span>Bevestigings email naar klant verstuurd</p>
                        <p><span className="history-date">00-00-0000</span>Productregistratie afgerond</p>
                        <p><span className="history-date">00-00-0000</span>Pre-registratie voltooid</p>
                    </div>
                </div>
            );

            let _registrationDate = "";

            if (_info.InstallationDate) {
                _registrationDate = moment(new Date(_info.InstallationDate)).locale(this.getCalenderLocale()).format('dddd DD MMMM YYYY');
            }


            return (<React.Fragment>
                <div className="product-overview--edit">
                    <div className="close mobile" onClick={e => this.closeModal("modalOpened")} />
                    <div className="row">
                        <div className="overview-details modal--content-main">
                            <div className="modal--content-main-section">
                                <div>
                                    <div className="contextual-title-bold main-title" dangerouslySetInnerHTML={{ __html: _info.Product.Name }} />
                                    <div className="product-details">
                                        <p dangerouslySetInnerHTML={{ __html: `${this.props.data.item.SerialNumber}: ${_info.Product.ProductId}` }} />
                                        <p dangerouslySetInnerHTML={{ __html: `${this.props.data.item.InstalledOn}: ${_registrationDate}` }} />
                                    </div>
                                    <div>
                                        <h4 dangerouslySetInnerHTML={{ __html: this.props.data.item.RegisteredForTitle }} />
                                        <div>
                                            <p className="name" dangerouslySetInnerHTML={{ __html: `${_info.Firstname} ${_info.Lastname}` }} />
                                            <p className="address" dangerouslySetInnerHTML={{ __html: `${_info.StreetName} ${_info.HouseNumber}, ${_info.PostalCode} ${_info.City}` }} />
                                        </div>
                                    </div>
                                    {_guaranteeSection}
                                    {_projectSection}
                                </div>
                                {_ogpSection}
                                {_historySection}
                            </div>
                        </div>
                        <div className="overview-image modal--content-image">
                            <div className="overview-credits" dangerouslySetInnerHTML={{ __html: `+${_info.Points}` }} />
                            <img src={_info.imageSource} alt={_info.Product.Name} />
                            <div className="text-center">
                                <a  
                                    href="javascript:void(0)" 
                                    className="button red" 
                                    dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportAFault }} 
                                    onClick={event => { this.setState({ errorFormModalOpened: true, modalOpened: false }); }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>);
        }

    }

    getPrevWeek = () => {
        let _return = {};
        let _dateRange = this.state.dateRange;
        if (this.props.data.item.DatePickerLocale) {
            let _locale = this.props.data.item.DatePickerLocale;
            _return = {
                startDate: moment(new Date(_dateRange.startDate)).subtract(7, "days"),
                endDate: moment(new Date(_dateRange.startDate)).subtract(1, "days"),
            };
        }
        this.setState({
            dateRange: _return
        });
        this.handleSearch();
    }
    getNextWeek = () => {
        let _return = {};
        let _dateRange = this.state.dateRange;
        if (this.props.data.item.DatePickerLocale) {
            let _locale = this.props.data.item.DatePickerLocale;
            _return = {
                startDate: moment(new Date(_dateRange.startDate)).add(7, "days"),
                endDate: moment(new Date(_dateRange.startDate)).add(13, "days"),
            };
        }
        this.setState({
            dateRange: _return
        });
        this.handleSearch();
    }

    resize() {
        let isMobile = (window.innerWidth <= 639);

        if (isMobile !== this.state.isMobile) {
            let _isTileView = isMobile ? false : this.state.isTileView;
            let _slice = isMobile ? 3 : this.state.paginationSlice.Value;
            setTimeout(() => {
                this.setState({
                    isMobile: isMobile,
                    isTileView: _isTileView,
                    paginationSlice: {
                        Text: this.state.paginationSlice.Text,
                        Value: _slice
                    }
                });
            }, 1000);
        }
    }

    displayAllProducts = () => {
        this.setState({
            paginationSlice: {
                Text: this.state.paginationSlice.Text,
                Value: this.state.refinedMyProducts.length
            }
        });
    }

    render() {
        let _classes = this.getProperClasses();

        /**Filter Button -- Hidden for now (will not be rendered) */
        let _filterButton = (<div className="product-overview--box product-overview--button">
            <a href="javascript:void(0)" className="button secondary">{this.props.data.item.MoreFiltersText}</a>
        </div>);

        return (
            <div>
                <div className="row">
                    <div className="small-12">
                        <div className={this.props.data.item.WrapperClass}>
                            <SearchBox
                                title={this.props.data.item.SearchTitle}
                                searchPlaceholder={this.props.data.item.SearchPlaceholder}
                                onChangeFunc={this.handleSearch}
                                wrapperClass={_classes.searchWrapperClass}
                                searchClass={_classes.searchClass}
                                dataRef={this.searchKeywordRef}
                            />
                            {this.renderConditionalElems(_classes)}
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="small-12">
                        <TileListTable
                            wrapperClass={_classes.tableWrapperClass}
                            data={this.props.data}
                            dateRange={this.state.dateRange}
                            isTileView={this.state.isTileView}
                            refinedMyProducts={this.state.refinedMyProducts}
                            paginationSlice={this.state.paginationSlice.Value}
                            manageRegistration={this.manageRegistration}
                            getPrevWeek={this.getPrevWeek}
                            getNextWeek={this.getNextWeek}
                            isMobile={this.state.isMobile}
                            ref={this.tableRef}
                            displayAllProducts={this.displayAllProducts}
                        />
                    </div>
                </div>
                {this.modalRenderer()}
            </div>
        );
    }

}

module.exports = TableSearch;