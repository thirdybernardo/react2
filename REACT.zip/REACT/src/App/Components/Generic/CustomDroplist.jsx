import React from "react";

class CustomDroplist extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            showOptions: false
        };
    }

    createList = () => {
        let _list = [];
        if (this.props.list.length > 0) {
            this.props.list.forEach((val, i) => {
                let _content = this.props.isHtmlChoices
                    ? <div dangerouslySetInnerHTML={{ __html: val.Text }}></div>
                    : <span>{val.Text}</span>
                _list.push(
                    <li key={i} onClick={!val.Disabled ? event => this.handleListClick(event, val) : (this.props.action2 ? event => this.handleListClick(event, val, 2) : null)} className={(val.Disabled ? "disabled" : "") + (val.Disabled === false ? "enabled" : "")}>
                        {
                            _content
                        }
                    </li>
                );
            });
        }
        return _list;
    }

    triggerListVisibility = (e) => {
        if(this.state.showOptions){
            this.setState({ showOptions: false});
        }
        else if(!this.state.showOptions){
            this.setState({ showOptions: true });
        }
    }

    handleListClick = (e, val, type) => {
        let _initVisibility = this.state.showOptions;
        this.triggerListVisibility();
        if (type == undefined || type == 1) {
            this.props.action(e, this.props.identifier, val);
        }
        else if (type == 2) {
            this.props.action2(e, this.props.identifier, val);
        }
        if(this.props.callback)
            this.props.callback(val, this.props.dataRef, this.props.callbackKey);
    }

    render() {
        return (
            <div className={"installer--dropdown-wrapper " + this.props.containerClass}>
                <span ref={this.props.dataRef}
                    data-content={this.props.customSelectedProp ? this.props.selected[this.props.customSelectedProp] : this.props.selected.Text}
                    role="button"
                    tabIndex="0"
                    className="installer--dropdown-selected"
                    onClick={event => this.triggerListVisibility(event)}
                    dangerouslySetInnerHTML={this.props.isHtmlChoices ? { __html: (this.props.customSelectedProp ? this.props.selected[this.props.customSelectedProp] : this.props.selected.Text) } : undefined}>
                        {this.props.isHtmlChoices ? null : (this.props.customSelectedProp ? this.props.selected[this.props.customSelectedProp] : this.props.selected.Text)}
                </span>
                <div className={(!this.state.showOptions ? "hide " : "") + "installer--dropdown-options"}>
                    <ul>
                       {this.createList()}
                    </ul>
                </div>
            </div>
        );
    }

}

module.exports = CustomDroplist;