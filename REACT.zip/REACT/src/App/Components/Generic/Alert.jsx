import React from "react";
import InstallerHelper from '../../Helpers/InstallerHelper';

class Alert extends React.Component {
    constructor(props) {
        super(props);
        this.enums = {
            CountType: {
                IUR: "InstallerUnfinishedRegistration"
            }
        };
        this.state = {
        };
    }

    getCount = () => {
        // AlertCounterType is a field in Sitecore that should return a string which is looked up on the enums
        let _return = undefined;
        let _counterType = String(this.props.data.item.AlertCounterType).toLowerCase();
        switch(_counterType){
            case String(this.enums.CountType.IUR).toLowerCase():
                _return = (
                    <React.Fragment>
                        &nbsp;
                        <span>{InstallerHelper.getUnfinishedRegistrationsCount("PlaceholderInstallerID")}</span>
                        &nbsp;
                    </React.Fragment>
                );
                break;
            default:
                break;
        }
        return _return;
    }

    getUrl = () => {
        if (this.props.data.item.AlertLinkURL)
            return String(this.props.data.item.AlertLinkURL);
        else
            return "javascript:void(0)";
    }

    executeCallback = (e) => {        
        if (this.props.callback)
            this.props.callback(e);
        else   
            return undefined;
    }
 
    render() {
        return (
            <div>
                <div className={this.props.data.item.AlertWrapperClassName}>
                    <p>
                        <span dangerouslySetInnerHTML={{__html: this.props.data.item.AlertLeftText}} />
                        {this.getCount()}
                        <span dangerouslySetInnerHTML={{__html: this.props.data.item.AlertRightText}} />
                    </p>
                    <a href={this.getUrl()} className={this.props.data.item.AlertLinkClassName} onClick={event => this.executeCallback(event)}>
                        <span dangerouslySetInnerHTML={{__html: this.props.data.item.AlertLinkText}} />
                    </a>
                </div>
            </div>
        );
    }

}

module.exports = Alert;