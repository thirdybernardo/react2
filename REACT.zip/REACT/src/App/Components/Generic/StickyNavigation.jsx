import React from 'react';
import { isNullOrUndefined } from 'util';
import Button from "../../Components/Generic/Button";
import SitecoreHelper from '../../Helpers/SitecoreHelper';

class StickyNavigation extends React.Component {
    constructor(props) {
        super(props);
    }

    /*Will execute the function defined from the Button parent*/
    triggerEvent = (e, linkId) => {
        console.log(`link ${linkId} has been clicked`);
    }


    getNavLinks = (key) =>{
        if(key == undefined) return;
        let _key = key.split('&');

        if(key){
            return SitecoreHelper.getNameValuePair(_key, this.props.isEditing);
        }
    }

     generateLinks = () => {
        let _links = [];
        let navLinks = this.getNavLinks(this.props.data.item.OptionList);

        if (navLinks) {
            navLinks.map((item, i) => {
                if (item.Name) {
                    let _uri = isNullOrUndefined(item.Value) || item.Value === "" ? "javascript:void(0);" : item.Value.replace(/%23/g, '#');
                    _links.push(<a key={i} href={_uri} onClick={event => this.triggerEvent(event, i)}>{item.Name}</a>);
                }
            });
        }

        return _links;
    }

    render() {
         /*
         * Necessary classes default to the pre-defined classes below
         * if no attributes or props supplied for:
         * (1) wrapperClassName -> for the parent div
         * (2) className -> for child div
         * */
        let _wrapperClassName = isNullOrUndefined(this.props.wrapperClassName) ? "sticky-nav" : this.props.wrapperClassName;
        let _navLinksClassName = isNullOrUndefined(this.props.className) ? "nav-links" : this.props.className;

        return (
            <div className={_wrapperClassName}>
                <div className={_navLinksClassName}>
                    {this.generateLinks()}
                </div>
                <Button
                    text={this.props.data.item.SaveButton}
                    callback={this.props.callback}
                    isSitecore={this.props.isSitecore}
                />
                {/*Renders addional components/elements inside the StickyNavigation markup*/}
                {this.props.children}
                
            </div>
        );
    }
}

module.exports = StickyNavigation;