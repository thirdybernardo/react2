import React from 'react'

class Slider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isInitialized: false,
            value:0
            
        }
        this.initProps = {
            min: 1,
            max: 10,
            step: 1
        }
    }
    componentDidMount() {
        if (this.props.isSitecore && !this.state.isInitialized) {
            this.initializeValue()
        }
    }
    componentDidUpdate(prevProps) {
        if (!this.props.isSitecore && prevProps.data !== this.props.data) {
            if (!this.state.isInitialized) {
                this.initializeValue()
            }
        }
    }
    initializeValue = () => {
        this.setState({
            isInitialized: true
        }, () => {
            this.initProps = {
                min: this.props.data.item.SliderMin,
                max: this.props.data.item.SliderMax,
                step: this.props.data.item.SliderStep
            }
        })
    }
    handleChange = (min, max) => (event) => {
        const value = event.target.value
        this.setState({ value: value },this.props.callback(event))   
        } 
    render() {
        const progress = (this.state.value / this.initProps.max) * 100 -1.6 + '%'
        const rangeColor = {
            height:'13px',
            borderRadius:'8px',
            margin: '-3px 0px 10px',
            background: `linear-gradient(90deg,  #00a0e6 ${progress}, #f5f6f6 ${progress}, #f5f6f6 100%)`   
          };
       
        return (
          <div>
            <div 
              className="rangewhitebg"
               />
             <input
                type="range"
                className="inputR"              
                min={this.initProps.min}
                max={this.initProps.max}
                step={this.initProps.step}
                value={this.state.value}
                onChange={this.handleChange(this.initProps.min, this.initProps.max)}
              />
              <div style={rangeColor} /> 
           </div>);
      }
}

module.exports = Slider
