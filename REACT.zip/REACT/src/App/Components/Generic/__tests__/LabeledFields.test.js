import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import LabeledFields from '../../Generic/LabeledFields';

const fn = jest.fn();
const labeledFields = shallow(
    <LabeledFields 
        label="Remeha klantnummer" 
        value="123456987"
    />
);

test("Check state used in component", () => {
    expect(labeledFields.instance().props.label).toBe("Remeha klantnummer");
    expect(labeledFields.instance().props.value).toBe("123456987");
});






