import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import Slider from '../../Generic/Slider';
import SliderData from '../../../../../build/Data/json/ProfileFormFields.json';

describe('rendering', () => {
    let slider, props;
     beforeEach(() => {
       props =  {
         data: {Slider},
         initializeValue: jest.fn()
        };
     });

     it('componentDidUpdate', () => {
        slider = shallow(<Slider  {...props}/>);
        slider.setProps({        
            data: { 
                item: {
                "SliderMin": 6000,
                "SliderMax": 500000,
                "SliderStep": 2000
                }
            }
        });
     });
  });

  test("Check onChange", () => {
    const slider = shallow(<Slider  data={Slider} callback={jest.fn()}/>);
    const _input = slider.find("input");
    _input.props().onChange({
        target: {value: 8000}
    });
    expect(slider.instance().props.callback).toHaveBeenCalledTimes(1);
});






