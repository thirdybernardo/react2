import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import Greeting from '../../Generic/Greeting';
import GreetingData from '../../../../../build/Data/json/GreetingsFields.json';
import GreetingsHelper from '../../../Helpers/GreetingsHelper';

const fn = jest.fn();
const greeting = shallow(
    <Greeting 
        data={GreetingData}
        isEditing={false}
    />
);

test("Check state used in component", () => {
    expect(greeting.instance().props.data.item.MorningGreeting).toBe("Goedemorgen");
    expect(greeting.instance().props.data.item.AfternoonGreeting).toBe("Goedemiddag");
});





