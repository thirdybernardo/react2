import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import FileUpload from '../FileUpload';
import fileUploadData from '../../../../../build/Data/json/BulkRegistrationProductFields.json';
import renderer from 'react-test-renderer';

const filepondRef = React.createRef();
const fileUpload = shallow(
    <FileUpload
        maxFiles={1}
        filepondRef={filepondRef}
        hidden={false}
        server={"/"}
        allowFileTypeValidation={true}
        allowedFileTypes={String(fileUploadData.item.AcceptedMimeTypes).split("|")}
        instantUploadEnabled={false}
        handleInit={undefined}
        updateCallback={jest.fn()} />
);

test('FileUpload matches snapshot', () => {
    const tree = renderer.create(
        <FileUpload
            maxFiles={1}
            filepondRef={React.createRef()}
            hidden={false}
            server={"/"}
            allowFileTypeValidation={true}
            allowedFileTypes={String(fileUploadData.item.AcceptedMimeTypes).split("|")}
            instantUploadEnabled={false}
            handleInit={undefined}
            updateCallback={jest.fn()} />).toJSON();
    expect(tree).toMatchSnapshot();
});

/****** NOTHING FOLLOWS ******/
/*  <input type=file/> cannot be mocked because of security reasons. This is expected  */
/*  Thus, other functions of component cannot be automatically tested via unit test    */