import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import DownloadButton from '../DownloadButton';
import bulkRegistrationData from '../../../../../build/Data/json/BulkRegistrationProductFields.json';
import renderer from 'react-test-renderer';

const downloadButton = shallow(
    <DownloadButton
        className="button arrow-right"
        text={bulkRegistrationData.item.DownloadTemplateText}
        fileUrl={bulkRegistrationData.item.FileSource}
        fileName={bulkRegistrationData.item.FileName} />
);

test('DownloadButton matches snapshot', () => {
    const tree = renderer.create(
        <DownloadButton
        className="button arrow-right"
        text={bulkRegistrationData.item.DownloadTemplateText}
        fileUrl={bulkRegistrationData.item.FileSource}
        fileName={bulkRegistrationData.item.FileName} />).toJSON();
    expect(tree).toMatchSnapshot();
});

test('Simulate button click', () => {
    const button = downloadButton.find('a');
    expect(downloadButton.find('a span').html()).toEqual(expect.stringContaining("Download template"));
    const spy = jest.spyOn(downloadButton.instance(), "downloadItem");
    downloadButton.update();
    button.simulate('click');
    expect(spy).toHaveBeenCalledTimes(1);
});
