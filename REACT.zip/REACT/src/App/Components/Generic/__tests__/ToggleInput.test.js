import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import ToggleInput from '../../Generic/ToggleInput';

const fn = jest.fn();
const toggleInput = shallow(
    <ToggleInput 
        wrapperClassName="switch-wrapper"
        switchYesLabel="Yes"
        switchNoLabel="No"
        label="Title"
        callback={fn}
        handleChange={fn}
        id="toggle-input-id"
    />
);


test("Check state used in component", () => {
    expect(toggleInput.state().CheckedState).toBe(false);
    expect(toggleInput.state().SwitchLabel).toBe("No");
    expect(toggleInput.instance().props.callback).toBeDefined();
    expect(toggleInput.instance().props.id).toBe("toggle-input-id");
});

test("Check click event on input", () => {
    const _input = toggleInput.find(".switch-wrapper .switch");

    _input.props().onChange({
        target: {checked: true}
    });

    toggleInput.instance().setState({ CheckedState: true, SwitchLabel: "Yes" }, () => {
        expect(toggleInput.instance().props.callback).toBeDefined();
    });
    
});




