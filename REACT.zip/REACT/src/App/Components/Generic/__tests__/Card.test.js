import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import Card from '../Card';
import thankYouData from '../../../../../build/Data/json/ThankYouFields.json';
import renderer from 'react-test-renderer';

const card = shallow(
    <Card 
        columnSize={thankYouData.item.NewRegistrationCardSize}
        containerClass={"reg-box"}
        title={thankYouData.item.NewRegistrationTitle}
        content={thankYouData.item.NewRegistrationContent}
        linkVisible={thankYouData.item.NewRegistrationButtonVisible}
        linkClass={"button"}
        linkEvent={thankYouData.links.NewRegistrationLink}
        linkText={thankYouData.item.NewRegistrationLinkText} />
);

test('Card matches snapshot', () => {
    const tree = renderer.create(
        <Card
            columnSize={thankYouData.item.NewRegistrationCardSize}
            containerClass={"reg-box"}
            title={thankYouData.item.NewRegistrationTitle}
            content={thankYouData.item.NewRegistrationContent}
            linkVisible={thankYouData.item.NewRegistrationButtonVisible}
            linkClass={"button"}
            linkEvent={thankYouData.links.NewRegistrationLink}
            linkText={thankYouData.item.NewRegistrationLinkText} />).toJSON();
    expect(tree).toMatchSnapshot();
});