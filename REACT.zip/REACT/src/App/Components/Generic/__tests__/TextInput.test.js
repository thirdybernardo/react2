import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import TextInput from '../../Generic/TextInput';
import SitecoreHelper from '../../../Helpers/SitecoreHelper';
import Validator from "../../../Helpers/Validator";

const fn = jest.fn();
const _placeholder = SitecoreHelper.getPlaceholderText(false, "placeholder");
const textInput = shallow(
    <TextInput id="text-input" 
    label="Title"
    placeholder={_placeholder}
    required="text-required"
    callback={fn}
    type="telephone"
    validate={true}
    />
);


test("Check state used in component", () => {
    expect(textInput.state().value).toBeNull();
    expect(textInput.state().validation).toBe("");
    expect(textInput.state().classValidation).toBe("");
});

test("Check click event on input", () => {
    const _input = textInput.find(".input-wrapper .has-default");
    //valid value
    _input.props().onChange({
        target: {value: "+31324568741"}
    });

    textInput.instance().setState({ value: "+31324568741"}, () => {
        textInput.instance().callback();
        textInput.instance().getFieldValidation('telephone', "+31324568741"), ()=>{
            textInput.instance().setState({ validation: "", classValidation: "sucess"});
        };
        expect(textInput.instance().props.callback).toBeDefined();
    });

    //invalid value
    _input.props().onChange({
        target: {value: "+313245687411"}
    });

    textInput.instance().setState({ value: "+313245687411"}, () => {
        textInput.instance().callback();
        textInput.instance().getFieldValidation("telephone", "+313245687411"), ()=>{
            const _validation = this.validators["telephone"].rules[0].message;
            textInput.instance().setState({ validation: _validation, classValidation: "error"});
        };
        expect(textInput.instance().props.callback).toBeDefined();
    });
    
    //empty value
    _input.props().onChange({
        target: {value: ""}
    });

    textInput.instance().setState({ value: ""}, () => {
        expect(textInput.state().validation).toBe(" ");
        expect(textInput.state().classValidation).toBe(" ");
        expect(textInput.instance().props.callback).toBeDefined();
    });
});




