import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import ExportButton from '../../Generic/ExportButton';

const fn = jest.fn();
const exportButton = shallow(
    <ExportButton
        wrapperClassName="large-6 medium-6 small-12"
        className="button"
        callback={fn /*Queryable installer id. Must be dynamic*/}
        text="Exporteren naar bestand"
    />
);

test('Export button matches snapshot', () => {
    const tree = renderer.create(
        <ExportButton
        wrapperClassName="large-6 medium-6 small-12"
        className="button"
        callback={fn /*Queryable installer id. Must be dynamic*/}
        text="Exporteren naar bestand" />).toJSON();

    expect(tree).toMatchSnapshot();
});

test('Export Button on click', () => {
    // Check if certain elements exist using CSS selectors
    const _exportButton = exportButton.find(".button"); 
   
    _exportButton.simulate('click',{
        target: {value: 'test'}
    });
    expect(exportButton.instance().props.callback).toBeCalled();

});





