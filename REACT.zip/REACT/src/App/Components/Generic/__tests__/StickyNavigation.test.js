import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import StickyNavigation from '../../Generic/StickyNavigation';
import StickyNavigationData from '../../../../../build/Data/json/StickyNavFields.json';
import Button from '../../Generic/Button';

const fn = jest.fn();
const stickyNavigation = shallow(
    <StickyNavigation 
        data={StickyNavigationData}
    />
);

test("Check state used in component", () => {
    expect(stickyNavigation.instance().props.data.item.OptionList).toBe("Algemene_gegevens=#algemenegegevens&Werkgebied=#werkgebied&Diensten=#diensten");
});

test("Check button if exists", ()=>{
    expect(stickyNavigation.find(Button).length).toBe(1);
});

test("Check onclick function", ()=>{
    const trigger = jest.spyOn(stickyNavigation.instance(), "triggerEvent");
    const _anchor = stickyNavigation.find(".nav-links a");
    expect(_anchor.length).toBe(3);

    const _firstLink = _anchor.first();
    _firstLink.props().onClick({
        target: {value: "#algemenegegevens"}
    });

    expect(trigger).toHaveBeenCalled();
});





