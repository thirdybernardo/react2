import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import SearchBox from '../SearchBox';
import renderer from 'react-test-renderer';

const fakeHandleSearch = jest.fn();
const searchBox = shallow(
    <SearchBox
        searchPlaceholder="Unit test placeholder"
        wrapperClass="unit-test-wrapper"
        searchClass="unit-test-search"
        onChangeFunc={fakeHandleSearch} />);

test('SearchBox matches snapshot', () => {
    const tree = renderer.create(
        <SearchBox
            searchPlaceholder="Unit test placeholder"
            wrapperClass="unit-test-wrapper"
            searchClass="unit-test-search" />).toJSON();
    expect(tree).toMatchSnapshot();
});

test('searchChange is executed on input change', () => {
    const button = searchBox.find('input');
    const spy = jest.spyOn(searchBox.instance(), "searchChange");
    searchBox.update();
    button.simulate('change');
    expect(spy).toHaveBeenCalledTimes(1);
    expect(fakeHandleSearch).toHaveBeenCalled();
});