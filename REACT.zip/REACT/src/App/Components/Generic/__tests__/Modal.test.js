import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import ModalContent from '../../../../../build/Data/json/BulkRegistrationProductFields';
import Modal from '../../Generic/Modal';

const fn = jest.fn();
const modal = shallow(
    <Modal 
        data={ModalContent} 
        closeEvent={fn} 
        modalContent={fn}
    />
);

const undefinedModal = shallow(
    <Modal 
        data={ModalContent} 
        closeEvent={undefined} 
        modalContent={undefined}
    />
);

test("Check data used in component", () => {
    expect(modal.instance().props.data.item.Type).toEqual("BulkEditEntry");
});

test('Modal matches snapshot', () => {
    const tree = renderer.create(
        <Modal 
            data={ModalContent} 
            closeEvent={fn} 
            modalContent={fn} />).toJSON();

    expect(tree).toMatchSnapshot();
    
});

test('Modal checks defined props', () => {
    // Check if certain elements exist using CSS selectors
    const modalButton = modal.find(".modal--container .close"); 
    expect(modal.instance().props.modalContent).toBeDefined();
    const spy = jest.spyOn(modal.instance(), "closeEvent");
    modal.update();
    modalButton.simulate('click', ()=>{
        {"test";}
    });
    expect(spy).toBeCalled();

});

test('Modal checks undefine props ', () => {
    // Check if certain elements exist using CSS selectors
    const modalButton = undefinedModal.find(".modal--container div.close"); 
    expect(undefinedModal.find('.modal--container')).toHaveLength(1);
    expect(undefinedModal.instance().props.modalContent).toBeUndefined();
    modalButton.simulate('click', ()=>{
        {"test";}
    });
    expect(undefinedModal.instance().props.closeEvent).toBeUndefined();
    
});




