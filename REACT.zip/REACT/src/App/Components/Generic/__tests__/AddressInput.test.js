import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import AddressInput from '../../Generic/Forms/AddressInput';
import TextInput from '../../Generic/TextInput';
import SitecoreHelper from '../../../Helpers/SitecoreHelper';
import AddressHelper from "../../../Helpers/AddressHelper";

const fn = jest.fn();
const _placeholder = SitecoreHelper.getPlaceholderText(false, "placeholder");
const addressInputComponent = shallow(
    <AddressInput 
        callback={fn}
        label = "Postcode & huisnummer + toev"
        postCodeId="postcode-id"
        postcodePlaceholder = {_placeholder}
        houseNumberId="housenumber-id"
        houseNumberPlaceholder = {_placeholder}
        message="Not Found"
        required="text-required"
    />
);

test("Check state used in component", () => {
    expect(addressInputComponent.state().result).toBeNull();
    expect(addressInputComponent.instance().props.label).toBe("Postcode & huisnummer + toev");
});

test("Check test inputs", () => {
    const _textInput = addressInputComponent.find(TextInput);
    expect(_textInput.length).toEqual(2);
});


test('Check valid post code and house number', () => {
    const input_postcode = "1322 AP";
    const input_housenumber = 6;

    addressInputComponent.instance().setAddressInputs("postcode-id", input_postcode);
    addressInputComponent.instance().setAddressInputs("housenumber-id", input_housenumber);
});









