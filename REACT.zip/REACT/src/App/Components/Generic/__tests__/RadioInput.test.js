import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import RadioInput from '../../Generic/RadioInput';
import SitecoreHelper from '../../../Helpers/SitecoreHelper';

const fn = jest.fn();
const radioInput = shallow(
    <RadioInput 
        id="test-radio-input" 
        label="Radio Input Title" 
        options="De_heer=Deheer&Mevrouw=Mevrouw"
        required="required"
        isEditing={fn}
        callback={fn}
    />
);

test("Check state used in component", () => {
    expect(radioInput.state().selected).toBeNull();
    expect(radioInput.instance().props.callback).toBeDefined();
});




