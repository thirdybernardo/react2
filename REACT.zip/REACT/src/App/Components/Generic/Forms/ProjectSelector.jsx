﻿//  Project Selector V2

import React, { Component } from 'react';
import Data from "../../../Data/Data";
import CustomDroplist from "../../Generic/CustomDroplist";

class ProjectSelector extends Component {
    constructor(props) {
        super(props);
        this.refProjectInput = React.createRef();
        this.state = {
            projects: [],
            validationClass: "",
            selectedProject: null,
            isUpdating: false,
            _default: {
                Text: this.props.data.item.ProjectInputPlaceholder,
                Value: null,
                Display: this.props.data.item.ProjectInputPlaceholder
            }
        };
    }

    //Get projects from a source, mock or database
    componentDidMount() {
        if(!this.props.isEditing){
            if (!this.props.isSitecore) {
                Data.getData("MockProjects", data => {
                    this.setState({ projects: data.Projects });
                });
            }
        }
    }

    componentDidUpdate(prevProps) {
        if (prevProps.ZipCode !== this.props.ZipCode) {
            this.props.ProjectInputMessage("");
        }     
        if (prevProps.ValidProjects.length != this.props.ValidProjects.length && !this.state.isUpdating) {
            this.setState({ isUpdating: true }, () => {
                let val = this.state.selectedProject;
                let _validProducts = val ? this.props.ValidProjects.find((vproj) => { return vproj.ProjectNumber == val.Value }) : undefined;
                if (!_validProducts) {
                    this.selectProject(null, "projectsDroplist", this.state._default);
                    this.props.ProjectInputMessage(this.props.data.item.ProjectProductErrorMessage.replace("{{ProjectTitle}}", val.Display), () => { this.setState({ isUpdating: false }) })
                }
                else if (_validProducts)
                    this.props.ProjectInputMessage("", () => { this.setState({ isUpdating: false }) })
            })
        }
    }

    setFormValues = (projectId) => {
        //set object values to be merged in form field values
        var _obj = {
            ProjectId: projectId,
            Project: projectId
        };
        this.props.setFormValues(_obj);        
    }

    selectProject = (e, identifier, val) => {
        this.setState({ selectedProject: val }, () => {
            this.setFormValues(val.Value);
            this.props.ProjectInputMessage("");
        });
    }

    selectInvalidProject = (e, identifier, val) => {
        if (!val.ValidCount)
            this.props.ProjectInputMessage(this.props.data.item.ProjectCountErrorMessage.replace("{{ProjectTitle}}", val.Display))
        else if (!val.ValidZipCode && val.ValidZipCode != undefined)
            this.props.ProjectInputMessage(this.props.data.item.ProjectZipErrorMessage.replace("{{ProjectTitle}}", val.Display))
        else if (!val.ValidProducts)
            this.props.ProjectInputMessage(this.props.data.item.ProjectProductErrorMessage.replace("{{ProjectTitle}}", val.Display))
    }

    render() {
        let _options = [];
        _options.push(this.state._default);
        this.props.Projects.forEach((obj, i) => {
            let _obj = {};
            let _isValidZip = undefined;
            let _isValid = this.props.ValidProjects.find((vproj) => {
                // Check if valid zip code considering wildcards for each project
                _isValidZip = this.props.ValidProjects.length > 0
                    ? (vproj.ProjectZipCode.split(",").filter(zip => {
                        let _zip = zip.split("*").filter(_z => { return _z != "" });
                        if (_zip.length > 1)
                            return this.props.ZipCode.replace(/\s/g, '') == zip.replace(/\s/g, '');
                        else
                            return this.props.ZipCode.replace(/\s/g, '').startsWith(_zip[0].replace(/\s/g, ''));
                    }).length > 0 ? true : false) : undefined;
                return vproj.ProjectNumber == obj.ProjectNumber
            });
            _obj.Text = `${obj.ProjectName} <span class="proj-remaining-count">${obj.NumberOfRemainingRegistrations}</span> `;
            _obj.Value = obj.ProjectNumber;
            _obj.Display = obj.ProjectName;
            _obj.Disabled = obj.NumberOfRemainingRegistrations <= 0 || !_isValid || !_isValidZip ? true : false;
            _obj.ValidZipCode = _isValidZip;
            _obj.ValidCount = obj.NumberOfRemainingRegistrations <= 0 ? false : true;
            _obj.ValidProducts = _isValid ? true : false;
            _options.push(_obj);
        });
        let _selectedService = !this.state.selectedProject ? this.state._default : this.state.selectedProject;
        return (
            <React.Fragment>
                <div className="validation-wrapper">
                    <div className="input-btn-wrapper">
                        <CustomDroplist
                            containerClass=""
                            list={_options}
                            selected={_selectedService}
                            customSelectedProp="Display"
                            action={this.selectProject}
                            action2={this.selectInvalidProject}
                            isHtmlChoices={true}
                            identifier="projectsDroplist" />
                    </div>
                </div>
            </React.Fragment>
        );
    }

}
export default ProjectSelector;
