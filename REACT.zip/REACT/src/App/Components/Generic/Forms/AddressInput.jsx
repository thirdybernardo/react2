import React from 'react';
import TextInput from '../TextInput';
import AddressHelper from "../../../Helpers/AddressHelper";

class AddressInput extends React.Component {
    constructor(props) {
        super(props);

        this._postCodeId = "post-code";
        this._houseNumberId = "house-number";
        this._message = "Address Not Found";

        if (this.props.postCodeId)
            this._postCodeId = this.props.postCodeId;


        if (this.props.houseNumberId)
            this._houseNumberId = this.props.houseNumberId;

        if (this.props.message)
            this._message = this.props.message;

        this.state = {
            result: null,
            validationClass: "",
            className: "",
            addressInputs: {
                PostalCode: "",
                HouseNumber: ""
            },
            coordinates: {},
            isInitialized: false
        };
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.refPostCode && this.props.refHouseNumber) {
            this.initializeAddressInputs();
            if (this.props.refPostCode.current.value != prevProps.refPostCode.current.value || this.props.refHouseNumber.current.value != prevProps.refHouseNumber.current.value)
                this.setState({ isInitialized: false });
        }
    }

    initializeAddressInputs = () => {
        if ((this.props.refPostCode.current.value !== "" || this.props.refHouseNumber.current.value !== "") && !this.state.isInitialized) {
            let _initialAddressInput = {
                PostalCode: this.props.refPostCode.current.value,
                HouseNumber: this.props.refHouseNumber.current.value
            };
            this.setState({
                addressInputs: _initialAddressInput,
                isInitialized: true
            }, () => {
                this.handleAPITrigger();
            });
        }
    }

    handleAPITrigger = () => {
        this.setState({
            result: null,
            validationClass: "",
            className: ""
        });

        let obj = Object.assign(this.state.addressInputs);

        if (obj && obj[this._postCodeId] && obj[this._houseNumberId]) {
            AddressHelper.getAddressInfo(obj[this._postCodeId], obj[this._houseNumberId], data => {
                let _result = null;
                let _city = "";
                let _streetName = "";
                let _validationClass = " has-error";
                let _className = " error";

                if (!data || !data.response || data.response.numFound === 0)
                    _result = this._message;
                else if (data.response.numFound > 0) {
                    _result = data.response.docs[0].weergavenaam;
                    _validationClass = " has-success";
                    _className = " success";

                    //Sets the marker and address result of the map
                    if (this.props.setMapCoordinates) {
                        this.props.setMapCoordinates(_result, data.response.docs[0].centroide_ll);
                    }

                    _city = data.response.docs[0].woonplaatsnaam;
                    _streetName = data.response.docs[0].straatnaam;
                }
                else
                    _result = this._message;

                this.setState({
                    result: _result,
                    validationClass: _validationClass,
                    className: _className
                }, () => {
                    if (this.props.apiCallback) {
                        this.props.apiCallback(_result, _city, _streetName);
                    }
                });
            });
        }
    };


    setAddressInputs = (field, value) => {
        let obj = Object.assign(this.state.addressInputs);
        obj[field] = value;

        //Force an empty string so it triggers the API call, warning a user when emptying PostalCode or HouseNu fields
        if (obj[field] == "") {
            obj[field] = " ";
        }

        if (this.props.callback)
            this.props.callback(field,value);

        this.setState({ addressInputs: obj }, () => {
           
            this.handleAPITrigger();
        });

    }

    renderAddressResult = () => {
        let _return = null;
        if (this.state.result) {
            _return = (
                <div className="row section-field">
                    <div className="columns medium-12">
                        <span className={"input-validation" + this.state.validationClass}>{this.state.result}</span>
                    </div>
                </div>
            );
        }
        return _return;
    }

    render() {

        return (
            <React.Fragment>
                <div className="form-group">
                    <div className="row section-field">
                        <div className="columns medium-6">
                            <TextInput
                                id={this._postCodeId}
                                label={this.props.label}
                                placeholder={this.props.postcodePlaceholder}
                                callback={this.setAddressInputs}
                                classValidation={this.state.className}
                                required={this.props.required}
                                refData={this.props.refPostCode}
                                readOnly={this.props.readOnly ? this.props.readOnly : undefined}
                            />
                        </div>
                        <div className="columns medium-3">
                            <TextInput
                                id={this._houseNumberId}
                                label="&nbsp;"
                                placeholder={this.props.houseNumberPlaceholder}
                                callback={this.setAddressInputs}
                                classValidation={this.state.className}
                                refData={this.props.refHouseNumber}
                                readOnly={this.props.readOnly ? this.props.readOnly : undefined}
                            />
                        </div>
                    </div>
                    {this.renderAddressResult()}
                </div>
            </React.Fragment>
        );
    }

}

module.exports = AddressInput;