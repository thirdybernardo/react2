import React from 'react';

class MyCurrentPoints extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            points: undefined
        };
    }

    componentDidMount = () => {
        this.setState(function (prevState) {
            let _points = 0; // Scaffold Points only/temporarily while this is not yet part of the user story
            return { points: _points };
        });
    }

    render() {
        return (
            <React.Fragment>
                <span className={!this.props.containerClass ? "" : this.props.containerClass}>
                    {!this.props.overridePoints ? this.state.points : this.props.overridePoints}
                </span>
                {this.props.children}
            </React.Fragment>
        );
    }
}

module.exports = MyCurrentPoints;