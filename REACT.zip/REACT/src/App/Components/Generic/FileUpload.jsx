import React from "react";
import { FilePond, registerPlugin } from 'react-filepond';

class FileUpload extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isDoneImporting: false,
            files: []
        };
    }

    componentDidMount() {
        // Conditional imports of modules that uses window object for React.NET
        new Promise(async $export => {
            await require('filepond-polyfill');
            const FilePondPluginFileValidateType = await require('filepond-plugin-file-validate-type');
            registerPlugin(FilePondPluginFileValidateType);
            this.setState({ isDoneImporting: true});
        });
    }

    handleInit = () => {
        if (this.props.handleInit) {
            this.props.handleInit();
        }
    }

    updateCallback = () => {
        if (this.props.updateCallback) {
            this.props.updateCallback(this.state.files);
        }
    }

    renderLink = () =>{
        var renderedContent = '<span class="filepond--label-action">' + this.props.labelLink + '</span>';

        if (this.props.labelText != undefined){
            renderedContent = this.props.labelText + " " + renderedContent;
        }
        return renderedContent;
    }

    renderFilePond = () => {
        let _return = null;
        if(this.state.isDoneImporting){
            _return = (
                <FilePond
                    ref={this.props.filepondRef}
                    files={this.state.files}
                    allowMultiple={true}
                    maxFiles={this.props.maxFiles}
                    server={this.props.server}
                    allowFileTypeValidation={this.props.allowFileTypeValidation}
                    acceptedFileTypes={this.props.allowedFileTypes}
                    instantUpload={false}
                    oninit={() => this.handleInit()}
                    onremovefile={(error, file) => {
                        this.setState({ files: [] });
                    }}
                    onaddfile={(error, file) => {
                        let _files = this.state.files;
                        if (!error && _files.length < (this.props.maxFiles ? this.props.maxFiles : 2)) {
                            _files.push(file);
                            this.setState({
                                files: _files
                            }, () => {
                                this.updateCallback();
                            });
                        }
                        else
                            this.updateCallback();
                    }}
                    labelIdle={this.renderLink()}
                />
            );
        }
        return _return;
    }

    render() {
        var hiddenClass = !this.props.hidden ? "" : "hide";
        return (
            <div className={"bulk-input-wrapper " +  hiddenClass}>
                {this.renderFilePond()}
            </div>
        );
    }

}

module.exports = FileUpload;