import React, { Component } from 'react';
import moment from 'moment';
import { default as DutchLocale } from 'react-date-range/dist/locale/nl';
import { default as EnUSLocale } from 'react-date-range/dist/locale/en-US';
import { Calendar } from 'react-date-range';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import DisplayHelper from '../../Helpers/DisplayHelper';

class DatePicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isInitialized: false,
            hideDatepicker: true,
            selectedDate: new Date(),
            locale: "nl",
            dateFormat: "DD MMMM YYYY",
            todayLabel: "(Vandaag)"
        };
        this.today = new Date();
    }

    componentDidUpdate() {
        // Initialize fields used in controlling display of dates
        if (!this.state.isInitialized && !this.props.isEditing) {
            this.setState(function (prevState, props) {
                let _locale = this.props.locale ? this.props.locale : prevState.locale;
                let _dateFormat = this.props.dateFormat ? this.props.dateFormat : prevState.dateFormat;
                let _todaylabel = this.props.todayLabel ? this.props.todayLabel : prevState.todayLabel;
                return {
                    isInitialized: true,
                    locale: _locale,
                    dateFormat: _dateFormat,
                    todayLabel: _todaylabel
                };
            }, () => {
                if (this.props.defaultSelectedDate  && this.props.defaultSelectedDate instanceof Date){
                    this.setState({ selectedDate: this.props.defaultSelectedDate });
                }
            });
        }
    }

    getCalenderLocale = () => {
        switch (this.state.locale) {
            case "nl": {
                return DutchLocale;
            }
            case "enUS": {
                return EnUSLocale;
            }
            default: {
                return DutchLocale;
            }
        }
    }

    handleSelect = (e) => {
        this.setState({ selectedDate: new Date(e) }, () => {
            this.calendarHideShow();
            if (this.props.callback && this.props.callbackKey)
                this.props.callback(this.props.callbackKey, e);
        });
    }

    calendarHideShow = (toHide) => {
        if (!this.props.isEditing) {
            this.setState(function (prevState) {
                return { hideDatepicker: !toHide ? true : (prevState.hideDatepicker == false ? true : false) };
            });
        }
    }

    render() {
        return (
            <div className={"form-group " + (this.props.wrapperClass ? this.props.wrapperClass : "")} onTouchCancelCapture={e => this.calendarHideShow(false)} onMouseLeave={e => this.calendarHideShow(false)}>
                {this.props.children}
                <div className={!this.props.titleClass ? "row section-title" : this.props.titleClass}>
                    <div className={this.props.columnCLass ? this.props.columnCLass :"columns medium-12"}>
                        <label dangerouslySetInnerHTML={{ __html: this.props.title }} />
                    </div>
                </div>
                <div className={!this.props.containerClass ? "row section-field" : this.props.containerClass} onClick={event => this.calendarHideShow(event)}>
                    <div className={this.props.columnCLass ? this.props.columnCLass :"columns medium-12"}>
                        <label className="datepicker-wrapper">
                            <span>{DisplayHelper.toTitleCase(moment(this.state.selectedDate).locale(this.state.locale).format(this.state.dateFormat))}</span>
                            &nbsp;
                            <span className="datepicker-today">{moment(this.today).locale(this.state.locale).format(this.state.dateFormat) == moment(this.state.selectedDate).locale(this.state.locale).format(this.state.dateFormat) ? this.state.todayLabel : ""}</span>
                        </label>
                    </div>
                </div>
                <div className={(!this.props.datepickerClass ? "section-datepicker " : this.props.datepickerClass) + (this.state.hideDatepicker ? "hide" : "")} >
                    <Calendar
                        onChange={event => this.handleSelect(event)}
                        locale={this.getCalenderLocale()}
                        showMonthArrow={false}
                        date={this.state.selectedDate}
                        maxDate={!isNaN(parseInt(this.props.maxDate)) ? new Date(new Date().setDate(this.today.getDate() + parseInt(this.props.maxDate))) : undefined}
                        minDate={!isNaN(parseInt(this.props.maxDate)) ? new Date(new Date().setDate(this.today.getDate() - parseInt(this.props.minDate))) : undefined}
                    />
                </div>
            </div>
        );
    }
}

export default DatePicker;