import React from 'react';
import GreetingsHelper from '../../Helpers/GreetingsHelper';

class Greeting extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            nameOfUser: "{{Name}}"
        };

        this.nameOfUser = "{{Name}}";
    }

    verbalGreeting = () => {
        if(!this.props.isEditing)
            return GreetingsHelper.getVerbalGreeting(this.props.data.item.MorningGreeting,
            this.props.data.item.AfternoonGreeting,
            this.props.data.item.EveningGreeting);
        else
            return (<div> Good Morning </div>);
    }

    /*
     * Will not be rendered if in Sitecore.
     * A Text block will be used instead.
     * */
    renderProfileSubHeading = () => {
        return (
            <div>
                <span dangerouslySetInnerHTML={{ __html: this.props.data.item.Title }} /> &nbsp;
                    <a href="javascript:void(0);" dangerouslySetInnerHTML={{ __html: this.props.data.item.Subtitle }} ></a>
            </div>
        );
    }


    render() {
        let name = this.state.nameOfUser === this.nameOfUser ? "" : this.state.nameOfUser;
        return (
            <React.Fragment>
                <div className="profile-head">
                    <div className="form--title">
                        <h2>{this.verbalGreeting()} {name}</h2>
                        {this.renderProfileSubHeading()}
                    </div>
                </div>
            </React.Fragment>
        );
    }

}

module.exports = Greeting;