import React, { Component } from 'react';
import SitecoreHelper from "../../Helpers/SitecoreHelper";
import ValidatorHelper from "../../Helpers/Validator";
import UIDGenerator from "../../Helpers/UIDGenerator";

class RegistrationCustomerData extends Component {
    constructor(props) {
        super(props);

        this.refCustomerDataFirstName = React.createRef();
        this.refCustomerDataLastName = React.createRef();
        this.refCustomerDataTelephone = React.createRef();
        this.refCustomerDataEmailAddress = React.createRef();
        this.refEmailCheckBox = React.createRef();
        this.refAgreementCheckBox = React.createRef();

        this._CustomerId = UIDGenerator.Generate();
        this._RadioMr = UIDGenerator.Generate();
        this._RadioMrs = UIDGenerator.Generate();
        this._EmailId = UIDGenerator.Generate();

        
        this.state = {
            agreementSwitch: "Ja",
            emailSwitch: "Nee",
            emailChecked: false,
            agreementChecked: true,
            hasChange:false,
            validations: {
                email: "",
                telephone: ""
            },
            classValidations: {
                email: "",
                telephone: ""
            },
            salutation: ""
        };

        this.validators = ValidatorHelper;
    }

    componentDidMount = () => {
        this.handleBulkEntry();
    }

    componentDidUpdate(prevProps) {
        //init validation messages
        if(!this.props.isEditing){
            if (!this.props.isSitecore) {
                if(this.props.isBulk && this.props.singleEntry && this.state.hasChange){
                    this.refCustomerDataEmailAddress.current.value = this.props.singleEntry.EmailAddress;
                    this.checkFieldIfValid("email", this.refCustomerDataEmailAddress);
                    this.setState({hasChange: false});
                }
                if (prevProps.data.item != this.props.data.item) {
                    this.validators["required"].rules[0].message = this.props.data.item.RequiredErrorMesage;
                    this.validators["telephone"].rules[0].message = this.props.data.item.TelephoneInvalidMessage;
                    this.validators["email"].rules[0].message = this.props.data.item.EmailInvalidMessage;
                    this.refEmailCheckBox.current.checked = false;
                    this.refAgreementCheckBox.current.checked = true;
                }
            } else {
                //Code for getting data in Sitecore integration
            }
        }
    }

    handleBulkEntry = (callback) =>{
        let _entry = this.props.singleEntry;
        if(_entry && this.props.isBulk && _entry.IsAdditionalCustomerInfoAgreed){
            this.refCustomerDataFirstName.current.value = _entry.Firstname;
            this.refCustomerDataLastName.current.value = _entry.Lastname;
            this.refCustomerDataTelephone.current.value = _entry.TelephoneNo;
            this.checkFieldIfValid("telephone", this.refCustomerDataTelephone);
            if(_entry.IsEmailAddress){
                this.refEmailCheckBox.current.checked = _entry.IsEmailAddress;
                this.handleEmailChange(null, _entry.IsEmailAddress);
                this.setState({hasChange: true}, ()=>{
                    if(callback)
                        callback();
                });
            }

        }
    }

    setFormValues = (toReset) => {
        //set object values to be merged in form field values
        var _obj = {};
        if (!toReset) {
            _obj = {
                Firstname: this.refCustomerDataFirstName.current.value,
                Lastname: this.refCustomerDataLastName.current.value,
                TelephoneNo: this.refCustomerDataTelephone.current.value,
                IsEmailAddress: this.state.emailChecked,
                EmailAddress: this.refCustomerDataEmailAddress.current ? this.refCustomerDataEmailAddress.current.value : "",
                IsAdditionalCustomerInfoAgreed: this.state.agreementChecked,
                Salutation: this.state.salutation
            };
        }
        else {
            _obj = {
                Firstname: "",
                Lastname: "",
                TelephoneNo: "",
                IsEmailAddress: false,
                EmailAddress: "",
                IsAdditionalCustomerInfoAgreed: true,
                Salutation: ""
            };//reset here
        }
        this.props.setFormValues(_obj);
    }


    handleAgreementChange = (event) => {
        this.setState({
            agreementChecked: event.target.checked,
            agreementSwitch: event.target.checked ? this.props.data.item.SwitchYesLabel : this.props.data.item.SwitchNoLabel
        });
        if (this.state.agreementChecked) {
            // Reset when customer data switch will be set to off or false
            this.resetField("email");
            this.resetField("telephone");
            this.props.setValidationState(true, "email");
            this.props.setValidationState(true, "telephone");
            this.setFormValues(true);
            this.setState({
                emailChecked: false,
                emailSwitch: this.props.data.item.SwitchNoLabel
            });
        }else{
            this.setFormValues(false);
        }
        
        
    }

    handleEmailChange = (event, tempEvent) => {
        let target = null;
        if(event)
            target = event.target.checked;
        else
            target = tempEvent;

        this.setState({
            emailChecked: target,
            emailSwitch: target ? this.props.data.item.SwitchYesLabel : this.props.data.item.SwitchNoLabel
        });

        //When email switch is false, all validations on the field should be resetted.
        if (!target){
            this.props.setValidationState(true, "email");
            this.resetField("email");
        }

        this.setFormValues();
    }

    resetField = (field) => {
        let _validationMessage = this.state.validations;
        let _classValidations = this.state.classValidations;

        _validationMessage[field] = "";
        _classValidations[field] = "";

        this.setState({
            validations: _validationMessage,
            classValidations: _classValidations
        });
    }

    renderEmailAddressField = () => {
        let _return = null;

        if (this.state.emailChecked) {
            _return = (
                <label htmlFor="customer-email" className={"input-wrapper " + this.state.classValidations["email"]}>
                    <input
                        ref={this.refCustomerDataEmailAddress}
                        className={"has-default " + this.state.classValidations["email"]}
                        type="email"
                        id="customer-email"
                        autoFocus
                        placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.data.item.CustomerDataEmailAddressPlaceholder)}
                        onChange={event => this.checkFieldIfValid("email", event)}
                    />
                </label>);
        }

        return _return;
    }

    //Handling the validation for Email and Telephone
    checkFieldIfValid = (field, event) => {
        let _value = null;
        if (event.target)
            _value = event.target.value;
        else if (event.current)
            _value = event.current.value;
        let _errMsg = "";
        this.validators[field].valid = true;

        this.validators[field].rules.forEach((rule) => {
            if (rule.validate instanceof RegExp) {
                if (!rule.validate.test(_value)) {
                    this.validators[field].valid = false;
                    this.props.setValidationState(false, field);
                    _errMsg = rule.message; //replace to be configurable
                } else {
                    this.props.setValidationState(true, field);
                }
            }
        });

        let _validationMessage = this.state.validations;
        let _classValidations = this.state.classValidations;

        this.setFormValues();
        if (!this.validators[field].valid) {
            _validationMessage[field] = _errMsg;
            _classValidations[field] = "error";
            this.setState({ validations: _validationMessage });
            this.setState({ classValidations: _classValidations });
        } else {
            _validationMessage[field] = _errMsg;
            _classValidations[field] = "success";
            this.setState({ validations: _validationMessage });
            this.setState({ classValidations: _classValidations });
        }

        //When Telephone and Email items are cleared. Validation should be resetted.
        if (_value == "") {
            this.resetField(field);
            this.props.setValidationState(true, field);
        }
    }

    displayValidationMessages = (field) => {
        let _return = null;

        if (this.state.validations[field] != "")
            _return = (
                <span className="input-validation error">{this.state.validations[field]}</span>
            );

        return _return;
    }


    handleSalutationChange = (e) => {
        this.setState({ salutation: e.target.value }, () => {
            this.setFormValues();
        });
    }

    renderInputSection = () => {
        let _return = null;
        if (this.state.agreementChecked) {
            _return = (
                <div className="row section-field customer-input">
                    <div className="columns small-12 input-row--salutation">
                        <label >
                            <span className="text-required" dangerouslySetInnerHTML={{ __html: this.props.data.item.CustomerDataSalutation}}></span>
                        </label>

                        <label
                            htmlFor={this._RadioMr}
                            className="input-wrapper input--radio-button">
                            <input
                                type="radio"
                                id={this._RadioMr}
                                name="salutation"
                                onClick={e => this.handleSalutationChange(e)}
                                value={this.props.data.item.CustomerDataMaleSalutation}
                            />
                            <span
                                dangerouslySetInnerHTML={{
                                    __html: this.props.data.item.CustomerDataMaleSalutation
                                }}
                            />
                            <span className="checkmark" />
                        </label>
                        <label
                            htmlFor={this._RadioMrs}
                            className="input-wrapper input--radio-button">
                            <input
                                type="radio"
                                id={this._RadioMrs}
                                name="salutation" 
                                ref={this.mrsChecked}
                                onClick={e => this.handleSalutationChange(e)}
                                value={this.props.data.item.CustomerDataFemaleSalutation}
                            />
                            <span
                                dangerouslySetInnerHTML={{
                                    __html: this.props.data.item.CustomerDataFemaleSalutation
                                }}
                            />
                            <span className="checkmark" />
                        </label>
                    </div>
                    <div className="columns small-12 input-row--name">
                        <div className="input-row--first-name">
                            <label
                                dangerouslySetInnerHTML={{
                                    __html: this.props.data.item.CustomerDataFirstName
                                }}
                            />
                            <label htmlFor="customer-first-name" className="input-wrapper">
                                <input
                                    ref={this.refCustomerDataFirstName}
                                    onChange={event => this.setFormValues()}
                                    className="has-default"
                                    type="text"
                                    id="customer-first-name"
                                    placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.data.item.CustomerDataFirstNamePlaceholder)} />
                            </label>
                        </div>
                        <div className="input-row--last-name">
                            <label
                                dangerouslySetInnerHTML={{
                                    __html: this.props.data.item.CustomerDataLastName
                                }}
                            />
                            <label htmlFor="customer-last-name" className="input-wrapper">
                                <input
                                    ref={this.refCustomerDataLastName}
                                    onChange={event => this.setFormValues()}
                                    className="has-default"
                                    type="text"
                                    id="customer-last-name"
                                    placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.data.item.CustomerDataLastNamePlaceholder)} />
                            </label>
                        </div>
                    </div>

                    <div className="columns small-12">
                        <label htmlFor="customer-telefon"
                            dangerouslySetInnerHTML={{
                                __html: this.props.data.item.CustomerDataTelephone
                            }}
                        />
                        <label htmlFor="customer-telefon" className={"input-wrapper " + this.state.classValidations["telephone"]}>
                            <input
                                ref={this.refCustomerDataTelephone}
                                onChange={event => this.setFormValues()}
                                className={"has-default " + this.state.classValidations["telephone"]}
                                type="tel"
                                id="customer-telefon"
                                onChange={event => this.checkFieldIfValid("telephone", event)}
                                placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.data.item.CustomerDataTelephonePlaceholder)} />
                        </label>
                        {this.displayValidationMessages("telephone")}
                    </div>
                    <div className="columns small-12">
                        <label className=""
                            dangerouslySetInnerHTML={{
                                __html: this.props.data.item.CustomerDataEmailAddress
                            }}
                        />
                        <div className="switch-wrapper">
                            <input
                                ref={this.refEmailCheckBox}
                                className="switch"
                                type="checkbox"
                                name=""
                                id={this._EmailId}
                                onChange={event => this.handleEmailChange(event)}
                            />
                            <label htmlFor={this._EmailId}>{this.state.emailSwitch}</label>
                            <div className="validation-wrapper">
                                {this.renderEmailAddressField()}
                                {this.displayValidationMessages("email")}
                                {
                                    (this.state.emailChecked) &&
                                    <p className="sub-note"
                                        dangerouslySetInnerHTML={{
                                            __html: this.props.data.item.CustomerDataEmailAddressDisclaimerText
                                        }}
                                    />
                                }
                            </div>
                        </div>
                    </div>
                </div>
            );
        }


        return _return;
    }

    render() {
        return (
            <div className="form-group form-cus customer-data">
                <div className="row section-title">
                    <div className="columns medium-12">
                        <div className="contextual-title-bold">
                            <label>
                                <span>
                                Uw gegevens
                                </span>
                            </label>
                        </div>
                        <div className="switch-wrapper hide">
                            <input
                                ref={this.refAgreementCheckBox}
                                className="switch"
                                type="checkbox"
                                defaultChecked
                                name=""
                                id={this._CustomerId}
                                onChange={event => this.handleAgreementChange(event)} />
                            <label htmlFor={this._CustomerId}>{this.state.agreementSwitch}</label>
                        </div>
                    </div>
                </div>
                {this.renderInputSection()}
            </div>
        );
    }
}

export default RegistrationCustomerData;