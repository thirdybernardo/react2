import React, { Component } from 'react';
import AddressInput from '../Generic/Forms/AddressInput';
import TextInput from '../Generic/TextInput';
import ToggleInput from '../Generic/ToggleInput';
import ValidatorHelper from "../../Helpers/Validator";
import InstallerAPI from '../../API/Installer';
import InstallerHelper from "../../Helpers/InstallerHelper";
import Data from "../../Data/Data";


class ConsumerProfileFrom extends Component {
    constructor(props) {
        super(props);
        /**MODELS */
        this.enums = {
            PostalCode: "PostalCode",
            HouseNumber: "HouseNumber",
            CompanyEmailAddress: 'CompanyEmailAddress',
            CompanyTelephoneNo: 'CompanyTelephoneNo',
            CompanyWebsite: 'CompanyWebsite',
            PersonalEmailAddress: 'PersonalEmailAddress',
            PersonalTelephoneNo: 'PersonalTelephoneNo',
            Salutation: 'Salutation',
            Firstname: "Firstname",
            Lastname: "Lastname"
        };
        this.profileData = {
            Firstname: "",
            Lastname: "",
            Salutation: "",
            PostalCode: "",
            HouseNumber: "",
            Latitude: 0,
            Longitude: 0,
            PersonalTelephoneNo: "",
            CompanyTelephoneNo: "",
            PersonalEmailAddress: "",
            CompanyEmailAddress: "",
            CompanyWebsite: "",
            EmailUsedForBilling: false,
            EmailUsedForSvcReports: false,
            CompanyName: "",
            ClientNumber: "",
            CompanyAcctManager: "",
            IsSaleOfProductSvc: false,
            IsRentalOfProductSvc: false,
            IsRemehaConnectSvc: false,
            IsStoringSvc: false,
            IsMaintenanceSvc: false,
            AddressResult: ""

        };
        this.mapsConfiguration = {
            ApiKey: "",
            Language: "",
            DefaultLatitude: 0,
            DefaultLongitude: 0
        };
        /**MODELS */

        this.references = {
            PostalCode: React.createRef(),
            HouseNumber: React.createRef(),
            ProfileEmail: React.createRef(),
            ProfileTelephone: React.createRef(),
            Website: React.createRef(),
            CustomerEmail: React.createRef(),
            CustomerTelephone: React.createRef(),
            CustomerFirstname: React.createRef(),
            CustomerLastname: React.createRef()
        };

        this.state = {
            formValues: this.profileData,
            requiredClassName: "text-required",
            wrapperClassName: "switch-wrapper",
            isProfileDataLoaded: false,
            mapRadius: 5000,
            mapsConfiguration: this.mapsConfiguration,
            defaultDistanceList: [
                { Text: "+3km", Value: 3 },
                { Text: "+5km", Value: 5 },
                { Text: "+10km", Value: 10 }
            ],
            addressResult: "",
            stickyNavFields: {
                item: {},
                links: {}
            },
            userinfoFields: {
                item: {}
            }
        };
        this.validators = ValidatorHelper;
        this.formValues = null;
    }

    componentDidMount() {
        if (!this.props.isSitecore) {
           

            Data.getData("UserInformationFields", (data) => {
                this.setState({ userinfoFields: data });
            });
        }
        this.getInstallerInfo();

    }


    componentDidUpdate(prevProps, prevState) {
        //init validation messages
        if (!this.props.isSitecore) {
            if (prevProps.data.item != this.props.data.item) {
                this.validators["required"].rules[0].message = this.props.data.item.RequiredErrorMesage;
                this.validators["telephone"].rules[0].message = this.props.data.item.TelephoneInvalidMessage;
                this.validators["email"].rules[0].message = this.props.data.item.EmailInvalidMessage;
               }
        }
    }

    populateFieldValues = () => {
        if (this.state.formValues) {
  
            this.references.PostalCode.current.value = this.state.formValues.PostalCode;
            this.references.HouseNumber.current.value = this.state.formValues.HouseNumber;
            this.references.ProfileEmail.current.value = this.state.formValues.CompanyEmailAddress;
            this.references.ProfileTelephone.current.value = this.state.formValues.CompanyTelephoneNo;
            this.references.CustomerEmail.current.value = this.state.formValues.PersonalEmailAddress;
            this.references.CustomerTelephone.current.value = this.state.formValues.PersonalTelephoneNo;
            this.references.CustomerFirstname.current.value = this.state.formValues.Firstname;
            this.references.CustomerLastname.current.value = this.state.formValues.Lastname;

        }
    }

    setFormValues = (field, value, callback) => {
        let obj = Object.assign(this.state.formValues);
        obj[field] = value;
        this.setState({ formValues: obj }, () => {
            if (callback)
                callback();
        });
    }



    /*MAP SECTION RELATED--->*/

    renderServices = () => {
        let _return = [];
        let _self = this;

        if (this.props.data.item && this.props.data.dictionary && this.state.isProfileDataLoaded) {
            let _dictionary = this.props.data.dictionary;
            let _wrapperClassName = this.state.wrapperClassName;
            let switchYesLabel = this.props.data.item.SwitchYesLabel;
            let switchNoLabel = this.props.data.item.SwitchNoLabel;

            var _profileData = this.state.formValues;
            if (_profileData) {
                Object.keys(_dictionary).map(function (key, i) {
                    let fieldLabel = _dictionary[key];
                    let checkedState = false;
                    switch (key) {
                        case "IsSaleOfProductSvc":
                            checkedState = _profileData.IsSaleOfProductSvc;
                            break;
                        case "IsRentalOfProductSvc":
                            checkedState = _profileData.IsRentalOfProductSvc;
                            break;
                        case "IsStoringSvc":
                            checkedState = _profileData.IsStoringSvc;
                            break;
                        case "IsRemehaConnectSvc":
                            checkedState = _profileData.IsRemehaConnectSvc;
                            break;
                        case "IsMaintenanceSvc":
                            checkedState = _profileData.IsMaintenanceSvc;
                            break;
                    }

                    _return.push(
                        <div key={i} className="columns medium-12">
                            <ToggleInput id={key}
                                wrapperClassName={_wrapperClassName}
                                switchYesLabel={switchYesLabel}
                                switchNoLabel={switchNoLabel}
                                label={fieldLabel}
                                callback={_self.setFormValues}
                                defaultChecked={checkedState}
                            />
                        </div>
                    );
                });
            }

        }

        return _return;
    }
  
    /*MOVED*/
    submitProfile = () => {
        var errorLabels = document.getElementsByClassName("error");
        if (errorLabels.length > 0) {
            alert("Please correct form errors");
        }
        else {
            InstallerHelper.GetInstallerId(this.props.isSitecore, (_installerId) => {
                InstallerAPI.UpdateProfileData(_installerId, this.state.formValues, (callback) => {
                    if (callback && callback.status === 200) {
                        alert("Profile successfully updated!");
                    }
                });
            });
        }
    }

    getInstallerInfo = () => {
        InstallerHelper.GetInstallerId(this.props.isSitecore, (_installerId) => {
            if (_installerId) {
                InstallerAPI.GetInstallerInfo(_installerId, (data) => {
                    if (data.Results) {
                        this.setState({
                            formValues: data.Results.Installer,
                            mapsConfiguration: data.Results.MapsConfiguration,
                            addressResult: data.Results.Installer.AddressResult,
                            isProfileDataLoaded: true
                        }, () => {
                            this.populateFieldValues();
                        });
                    }
                });
            }
        });
    }
    /*MOVED*/

    render() {
        return (
            <div>
                <div className="profile-form">
                    <a className="anchor" name="algemenegegevens"></a>
                    <div className="general-data form">
                      <div className="form-group">
                        <div className="cus-radio-select">
                            <div className="form-group wh-cus-bg customer-data">
                                <div className="row section-title">
                                    <div className="columns medium-12">
                                        <div className="contextual-title-bold">Uw gegevens</div>
                                    </div>
                                </div>
                                <div className="row section-field customer-input">
                                <div className="small-12 input-row--salutation"> 
                                    <label for="PostalCode" className="text-required ">
                                        <span>Aanhef </span>
                                    </label>
                                    <label className="input-wrapper input--radio-button">
                                        <input type="radio" checked="checked" name="salutation2"/>
                                        De heer
                                        <span class="checkmark"></span>
                                    </label>
                                    <label className="input-wrapper input--radio-button">
                                        <input type="radio" name="salutation2"/> 
                                        Mevrouw
                                        <span className="checkmark"></span>
                                    </label>
                                </div>
                                </div>
                            </div>
                            </div>
                            <div className="row section-field input-row--name cprofilebuttom">

                                
                                <div className="columns medium-6 input-row--first-name">
                                    <TextInput id={this.enums.Firstname}
                                        label={this.props.data.item.CustomerDataFirstName}
                                        placeholder={this.props.data.item.CustomerDataFirstNamePlaceholder}
                                        refData={this.references.CustomerFirstname}
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                    />
                                </div>
                                <div className="columns medium-6 input-row--last-name">
                                    <TextInput id={this.enums.Lastname}
                                        label={this.props.data.item.CustomerDataLastName}
                                        placeholder={this.props.data.item.CustomerDataLastNamePlaceholder}
                                        refData={this.references.CustomerLastname}
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                    />
                                </div>
                            </div>
                        </div>
                        <AddressInput
                            callback={this.setFormValues}
                            label={this.props.data.item.AddressTitle}
                            postCodeId={this.enums.PostalCode}
                            postcodePlaceholder={this.props.data.item.PostcodePlaceholder}
                            refPostCode={this.references.PostalCode}
                            houseNumberId={this.enums.HouseNumber}
                            houseNumberPlaceholder={this.props.data.item.HousenumberPlaceholder}
                            refHouseNumber={this.references.HouseNumber}
                            message={this.props.data.item.NotFoundValidationMessage}
                            required={this.state.requiredClassName}
                            
                        />
                     
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-9">
                                    <TextInput id={this.enums.CompanyEmailAddress}
                                        label={this.props.data.item.CustomerDataEmailAddress}
                                        placeholder={this.props.data.item.CustomerDataEmailAddressPlaceholder}
                                        refData={this.references.ProfileEmail}
                                        type="email"
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        validate={true}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-9">
                                    <TextInput id={this.enums.PersonalTelephoneNo}
                                        label={this.props.data.item.CustomerDataTelephone}
                                        placeholder={this.props.data.item.CustomerDataTelephonePlaceholder}
                                        refData={this.references.CustomerTelephone}
                                        type="telephone"
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        validate={true}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

module.exports = ConsumerProfileFrom;