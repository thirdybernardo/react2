import React from "react";


class CusModal extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
              addClass: false
        };

        this.enums = {
            Type: {
                BO: "BulkEditEntry",
                IPO: "InstalledParkOverview",
                EF: "ErrorForm",
                EF2: "ErrorForm2",
                SC: "SuccessModal"
            }
        };
        this.topArea = React.createRef();
        
    }

    toggleAdd = () => {
        this.setState({addClass: !this.state.addClass});
    }

    executeCallback = (e) => {
        if (this.props.callback)
            this.props.callback(e);
        else
            return undefined;
    }

    getProperClasses = () => {
        let _return = {};
        switch (this.props.type) {
            case (this.enums.Type.IPO):
                _return.modalClass = "modal--content small-right";
                break;
            case (this.enums.Type.BO):
                _return.modalClass = "product-registration";
                break;
            case (this.enums.Type.EF):
                _return.modalClass = "error-report";
                break;
            case (this.enums.Type.EF2):
                _return.modalClass = "modal--content small-left ";
                break;
            case (this.enums.Type.SC):
                _return.modalClass = "error-success ";
                break;
        }
        return _return;
    }

    renderContent = () => {
        if (this.props.modalContent) {
            return this.props.modalContent(this.resetTopScroll);
        }
        return (
            <div>
                <h3>Waar kun je het serienummer vinden?</h3> 
                <span>Het 12 of 13 cijferige serienummer kun je vinden op een grijze sticker aan 
                de onderzijde of bovenzijde van je ketel of op het garantieregistratieformulier.</span>
               <img src="http://remeha.be/wp-content/uploads/2016/11/tzerra_label.jpg"/>
            </div>
 
        );
    }

    closeEvent = () => {
        if (this.props.closeEvent && this.props.closeId) {
            this.props.closeEvent(this.props.closeId);
           
        }else{
            console.log("test",this.props.closeId);
        }
    }

    resetTopScroll = () => {
        this.topArea.current.scrollTo(0, 0);
    }

    operationClose() {
        this.setState({
            closemodal:!this.state.closemodal
        })
      } 

    render() {
        let _classes = this.getProperClasses();
        let _modaClasses = this.props.wrapperClass ? this.props.wrapperClass : "";
        let boxClass = ["box"];
        if(this.state.addClass) {
          boxClass.push('hide');
        }
    return (     
    <div className={boxClass.join(' ')}>  
        <div id="modal" className={`modal--container ${_modaClasses} `}>
            <div className="modal--block" />
                <div className="modal--outer">
                    <div className="modal--inner" ref={this.topArea}>
                        <div className={(this.props.noModalContentClass ? "" : "modal--content ") + (_classes.modalClass ? _classes.modalClass : "")}>
                              <div className="close" onClick={this.toggleAdd.bind(this)} />
                            {this.renderContent()}
                        </div>
                    </div>
                </div>
            </div>
         </div>
        );
    }

}

module.exports = CusModal;