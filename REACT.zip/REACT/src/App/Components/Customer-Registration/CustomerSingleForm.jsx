import React, { Component } from "react";
import RegistrationProductSearchCustomer from "../Customer-Registration/RegistrationProductSearchCustomer";
import DatePicker from "../Forms/DatePicker";
import Submit from "../Forms/Submit";
import ServiceButton from "../Forms/ServiceButton";
import Save from "../Forms/Save";
import ServiceWindow from "../Forms/ServiceWindow";
import ConsumerProfileFrom from "../Customer-Registration/ConsumerProfileFrom";
import { isNullOrUndefined, isRegExp } from "util";
import Data from "../../Data/Data";
import ProxyData from "../../Data/ProxyData";
import QueryString from "../../Data/QueryString";
import UIDGenerator from "../../Helpers/UIDGenerator";
import ProductAPI from "../../API/ProductRegistration";
import SitecoreHelper from "../../Helpers/SitecoreHelper";
import InstallerSearch from "./InstallerSearch";

//import RegistrationAddress from "../Forms/RegistrationAddress";

class CustomerSingleForm extends Component {
    constructor(props) {
        super(props);

        this._ProductSearchTitle = "Serienummer van het product";
        this._ProductSNMonthLimit = "11";

        if (this.props.data.item.ProductSearchTitle) {
            this._ProductSearchTitle = this.props.data.item.ProductSearchTitle;
        }

        if (this.props.data.item.ProductSNMonthLimit) {
            this._ProductSNMonthLimit = this.props.data.item.ProductSNMonthLimit;
        }

        let _formFieldModel = {
            Id: "",
            InstallerId: "",
            AddressResponse: {},
            PostalCode: "",
            HouseNumber: "",
            SerialNumber: [],
            Products: [],
            Points: 0,
            InstallationDate: "",
            IsProject: false,
            ProjectId: "",
            Salutation: "",
            Firstname: "",
            Lastname: "",
            TelephoneNo: "",
            IsEmailAddress: false,
            EmailAddress: "",
            IsAdditionalCustomerInfoAgreed: false,
            TotalAddressFound: 0,
            TotalProductsFound: 0
        };

        this.state = {
            ShowPoints: true,
            showServiceWindow: false,
            productsResult: [], // Products Search Result
            productsServices: [], // Services For eligible products on productsResult
            addedProducts: [], // Storage of added products -- acts like a cart
            registeredProducts: [],
            isDuplicate: false,
            isRegistered: false,
            isSerialNumberActive: true,
            productSearchTitle: this._ProductSearchTitle,
            productSNMonthLimit: this._ProductSNMonthLimit,
            productLimitCtr: 0,
            isProductLimitReached: false,
            formValues: _formFieldModel,
            profileFormFields: {
                item: {},
                dictionary: {}
            },
            formValidation: {
                isEmailValid: true,
                isTelephoneValid: true,
                isAddressValid: false,
                isProductsValid: false,
                isProjectValid: true
            },
            queryValues: {
                serialNumber: "",
                installationDate: ""
            },
            submitButtonEnabled: false,
            isSubmitting: false
        };

        this.enums = {
            Email: 'email',
            Telephone: 'telephone',
            Address: 'address',
            Products: 'products',
            Project: 'project'
        };
    }

    componentDidMount() {
        if (!this.props.isEditing) {
            if (!this.props.isSitecore) {
                //Gets the list of registered products
                Data.getData("MockRegisteredProducts", data => {
                    this.setState({ registeredProducts: data.Products });
                    console.log(this.state.registeredProducts);
                });
                Data.getData("ProfileFormFields", (data) => {
                    this.setState({ profileFormFields: data });
                })

                this.handleBulkEntry();
                console.log(this.props.singleEntry);
            }
            let _queryValues = {
                serialNumber: QueryString.getValue("serialNumber"),
                installationDate: QueryString.getValue("installationDate")
            };
            if (_queryValues.serialNumber != "" || _queryValues.installationDate != "")
                this.setState({ queryValues: _queryValues });
        }
    }

    handleBulkEntry = () => {
        let _regProducts = this.props.registeredProducts;
        if (_regProducts && this.props.isBulk) {
            this.setState({ registeredProducts: _regProducts });
        }
    }

    renderFormAction = () => {
        let buttonClasses = "arrow-right ";
        if (this.props.isBulk) {
            return (<Save data={this.props.data} removeEntry={this.props.removeEntry} action={this.saveAction} buttonClass={this.state.submitButtonEnabled == false ? "hide" : buttonClasses} />);
        }
        else {
            return (
                <Submit data={this.props.data} action={this.submitForm} buttonClass={this.state.submitButtonEnabled == false ? "hide" : buttonClasses}>
                    {this.renderServiceButton()}
                </Submit>
            );
        }
    }

    saveAction = () => {
        let _obj = this.state.formValues;
        if (this.props.saveAction) {
            this.props.saveAction(_obj);
        }
    }


    togglePoints = (checked_state) => {
        this.setState({
            ShowPoints: checked_state ? false : true
        });
        var _obj = {
            Points: 0
        };
        if (!checked_state) {
            this.state.addedProducts.forEach((val) => {
                _obj.Points += val.ProductPoints;
            });
            _obj.ProjectId = "";
            _obj.Project = ""; //Reset ProjectId when project toggle turned to false
        }
        this.setFormValues(_obj);
    }

    renderServiceButton = () => {
        let _return = null;
        let _showService = false;
        this.state.addedProducts.forEach((obj) => {
            if (obj.WarrantyEnabled) {
                _showService = true;
            }
        });
        if (this.props.data.item.EnableServiceButton) {
            _return = <ServiceButton data={this.props.data} isVisible={_showService} TriggerServiceWindow={this.triggerServiceWindow} />;
        }
        return _return;
    }

    // Validate and add product in the productsResult
    addProduct = (val, productsData) => {
        return new Promise((resolve, reject) => {
            let _return = false;

            //Remove the limit if Product List has available for a single product
            if (this.checkIfCantAddCombiProduct())
                this.setState({
                    isProductLimitReached: false
                });

            let _item = null;
            let _isSerialNumberActive = true;
            if (!this.props.isSitecore) {
                // If not in Sitecore - Use the mock data that contains all products when not in sitecore
                productsData.forEach(item => {
                    if (item.ProductId === val.ProductId) {
                        _return = true;
                        _item = item;
                        this.addProductExtension(val, _item);
                    }
                });
                resolve(_return);
            }
            else {
                // If in Sitecore - Use the API
                let snLimit = this.state.productSNMonthLimit;
                let route = 'api/products?serialNumber=' + val.ProductId + "&snLimit=" + snLimit;
                ProxyData.getData(route, (response) => {
                    if (!response.Result)
                        resolve(_return);
                    else {
                        _item = response.Result;
                        _return = this.addProductExtension(val, _item);
                        resolve(_return);
                    }
                }, true);
            }
        });
    }

    addProductExtension = (val, _item, callback) => {
        let _isDuplicate = false;
        let _isRegistered = false;
        let _return = false;
        if (_item.ProductId) {
            _return = true;
            _isDuplicate = this.checkDuplicateProductsOnAddedProducts(val.ProductId);
            this.setState({ isDuplicate: _isDuplicate }, () => {
                if (!this.state.isDuplicate) {
                    this.checkIfProductIsRegistered(val.ProductId).then((result) => {
                        _isRegistered = result;
                        this.setState({ isRegistered: _isRegistered }, () => {
                            if (this.state.isSerialNumberActive && !this.state.isRegistered) {
                                if (_item != null &&
                                    _item.CombiProducts != null &&
                                    _item.CombiProducts.length >= 1 &&
                                    this.checkIfCantAddCombiProduct()) {
                                    this.setState({
                                        isProductLimitReached: true
                                    });
                                } else {
                                    let _pr = this.state.productsResult.slice();
                                    _pr.pop(); //to show only 1 result
                                    _pr.push(_item);

                                    this.setState({
                                        isProductLimitReached: false,
                                        productsResult: _pr
                                    }, () => {
                                        if (callback)
                                            callback();
                                    });
                                }
                            }
                        });
                    });
                }
            });
        }
        return _return;
    }

    checkDuplicateProductsOnAddedProducts = (input) => {
        let _arr = this.state.addedProducts;

        if (_arr.length > 0) {
            let _item = _arr.find(key => {
                return key.ProductId === input;
            });

            if (_item != null)
                return true;
        }

        return false;
    }

    checkIfProductIsRegistered = (input) => {
        return new Promise((resolve, reject) => {
            if (!this.props.isSitecore) {
                // If not in Sitecore - loop through the mock data
                let _arr = this.state.registeredProducts;

                if (_arr.length > 0) {
                    let _item = _arr.find(key => key.ProductId === input);

                    if (_item != null && _item.IsDisabled === 0)
                        resolve(true)
                    else
                        resolve(false)
                }
            }
            else {
                // If in Sitecore - use the API 
                let _isSerialNumberActive = true;
                let snLimit = this.state.productSNMonthLimit;
                let route = 'api/products?serialNumber=' + input + "&snLimit=" + snLimit;
                ProxyData.getData(route, (response) => {
                    if (!response.Result)
                        resolve(false);
                    // For Dropdown when serial number is unrecognized - Temporaryly return 'true' if the product selected is already registered
                    // but it will show error message for serial number already exsits, no design or acceptance criteria for selecting a products that's alreqady registered
                    // Confirm if 'products/all' should only return unregistered products (currently returns all products)
                    else {
                        _isSerialNumberActive = response.Result.isSerialNumberActive === 1 ? true : false
                        this.setState({ isSerialNumberActive: _isSerialNumberActive })
                        resolve((response.Result.isRegistered == 1 && response.Result.isDisabled === false) ? true : false)
                    }
                }, true);
            }
        });
    }

    checkIfCantAddCombiProduct = () => {
        let _return = false;
        if (((parseInt(this.props.data.item.ProductLimit) - this.state.productLimitCtr) - this.state.addedProducts.length) === 1)
            _return = true;
        else
            _return = false;

        return _return;
    }

    // Remove product in the productsResult
    removeProduct = (val) => {
        let _prodLimitCtr = this.state.productLimitCtr;

        this.setState({
            productsResult: this.state.productsResult.filter(key => {
                return key.ProductId !== val;
            }),
            productsServices: this.state.productsServices.filter(key => {
                return key.ProductId !== val;
            }),
            addedProducts: this.state.addedProducts.filter(key => {
                //When a combi product is remove it should delete a counter in the Product Limit Counter
                if (key.ProductId === val) {
                    if (key.CombiProducts != null && key.CombiProducts.length >= 1) {
                        _prodLimitCtr--;
                        this.setState({
                            productLimitCtr: _prodLimitCtr
                        });
                    }
                }

                //Remove the limit if Product List has available for a single product
                if (this.state.addedProducts.length >= 3 && ((parseInt(this.props.data.item.ProductLimit) - this.state.productLimitCtr) - this.state.addedProducts.length) >= 1)
                    this.setState({
                        isProductLimitReached: false
                    });
                return key.ProductId !== val;
            })
        }, () => {
            //Check if Added product is empty then change the Product Search Title
            if (this.state.addedProducts.length === 0)
                this.setState({
                    productSearchTitle: this.props.data.item.ProductSearchTitle
                });
            this.saveProductData(false, val);
        });
    }

    clearResult = () => {
        this.setState({ productsResult: [] });
    }


    // Hide or show Service section and hide or show the main form
    triggerServiceWindow = (val) => {
        this.setState({ showServiceWindow: Boolean(val) });
    }

    updateOGP = (installerId, products) => {
        let data = {
            InstallerId: installerId,
            ProductRegistrations: products
        };
        ProductAPI.UpdateProductRegistrationOGP(data, (response) => {
            if (response.status === 200)
                this.redirectAfterSubmit();
            else {
                alert("Something went wrong on our end when we tried to register your product. Please contact us for more information.");
            }
        });
    }

    // Add or Remove services or warranty from a product
    manageProductService = (e, productId, val) => {
        let _obj = {};
        let _exists = false;
        if (val.Value !== "" && val.Value !== this.props.data.item.NoServiceTitle) {
            _obj.ProductId = productId;
            _obj.Text = val.Text;
            _obj.Value = val.Value;
            let _productService = this.state.productsServices.slice();
            _productService.forEach(function (obj, i) {
                if (obj.ProductId === productId) {
                    _productService[i] = _obj;
                    _exists = true;
                }
            });
            if (!_exists) {
                _productService.push(_obj);
            }

            this.state.formValues.Products.map(key => {
                if (key.ProductId === productId) {
                    key.ServiceName = val.Text,
                        key.WarrantyStatus = "approved",
                        key.ExtendedWarranty = val.Value;
                }
            });

            this.setState({ productsServices: _productService });
        }
        else {
            this.setState({
                productsServices: this.state.productsServices.filter(key => {
                    return key.ProductId !== productId;
                })
            });
        }
    }

    deltaLimitCtr = (delta) => {
        return (previousState) => {
            return { ...previousState, productLimitCtr: previousState.productLimitCtr + delta };
        };
    }

    addProductToContainer = (value, refProductSearchInput, callback) => {
        if (isNullOrUndefined(value))
            callback(false);
        else {
            let _isDuplicate = false;
            let _isRegistered = false;
            let _prodLimitCtr = this.state.productLimitCtr;

            _isDuplicate = this.checkDuplicateProductsOnAddedProducts(value.ProductId);
            this.checkIfProductIsRegistered(value.ProductId).then((result) => {
                _isRegistered = result;
                this.setState({ isDuplicate: _isDuplicate }, () => {
                    if (_isDuplicate) {
                        callback(false);
                        return;
                    }
                    this.setState({ isRegistered: _isRegistered }, () => {
                        if (_isRegistered) {
                            callback(true);
                            return;
                        }
                        if (value != null &&
                            value.CombiProducts != null &&
                            value.CombiProducts.length >= 1 &&
                            this.checkIfCantAddCombiProduct()) {
                            this.setState({
                                isProductLimitReached: true
                            });
                            if (callback)
                                callback(true);
                            return;
                        } else {

                            this.setState({ addedProducts: [...this.state.addedProducts, value], productsResult: [] }, () => {
                                //Will only set the field into empty when the limit is not yet reached
                                if (this.state.addedProducts.length < (parseInt(this.props.data.item.ProductLimit) - this.state.productLimitCtr))
                                    refProductSearchInput.current.inputElement.value = "";

                                if (this.state.addedProducts.length > 0)
                                    this.setState({
                                        productSearchTitle: this.props.data.item.ProductSearchTitleAfterSelection
                                    });

                                if (value.CombiProducts != null && value.CombiProducts.length >= 1) {
                                    _prodLimitCtr++;
                                    this.setState(this.deltaLimitCtr(_prodLimitCtr));
                                }

                                this.saveProductData(true);

                                if (callback)
                                    callback(true);
                                return;
                            });
                        }
                    });
                });
            });
        }
    }


    clearProductResults = () => {
        this.setState({ productsResult: [] });
    }

    clearWarnings = () => {
        if (this.state.isDuplicate || this.state.isRegistered || !this.state.isSerialNumberActive) {
            this.setState({ isDuplicate: false, isRegistered: false, isSerialNumberActive: true });
        }
    }

    setValidationState = (value, field) => {
        let _obj = Object.assign(this.state.formValidation);

        if (field === this.enums.Email)
            _obj.isEmailValid = value;
        else if (field === this.enums.Telephone)
            _obj.isTelephoneValid = value;
        else if (field === this.enums.Address)
            _obj.isAddressValid = value;
        else if (field === this.enums.Products)
            _obj.isProductsValid = value;
        else if (field === this.enums.Project)
            _obj.isProjectValid = value;

        this.setState({
            formValidation: _obj
        });

    }

    verifyIfFormIsValid = () => {
        let _obj = this.state.formValidation;
        let _results = Object.values(_obj);
        let _return = false;

        let _result = _results.filter(val => val == false);

        if (_result.length === 0)
            _return = true;
        else
            _return = false;



        this.setState({ submitButtonEnabled: _return });

        return _return;
    }

    submitForm = (e) => {
        if (!this.props.isSitecore) {
            sessionStorage.setItem(UIDGenerator.Generate(), JSON.stringify(this.state.formValues));
            this.redirectAfterSubmit();
        }
        else {
            if (!this.state.isSubmitting) {
                this.setState({ isSubmitting: true }, () => {
                    ProductAPI.SubmitSingleRegistration(this.state.formValues, (response) => {
                        if (response.status === 200) {
                            this.redirectAfterSubmit();
                        }
                        else
                            alert("Something went wrong on our end when we tried to register your product. Please contact us for more information.");
                        // Temporary alert because no design is provided for form submission errors
                        this.setState({ isSubmitting: false });
                    });
                });
            }
        }
    }

    redirectAfterSubmit = () => {
        let _qs = QueryString.setValue("pointsEarned", this.state.formValues.Points, false);
        let _thankYouUrl = !this.props.isSitecore ? this.props.data.item.ThankYouPage : SitecoreHelper.getLink(this.props.data.item.ThankYouPage);
        let _redirectUrl = "/";
        if (_thankYouUrl != undefined && _thankYouUrl != "")
            _redirectUrl = _thankYouUrl;
        location.href = _redirectUrl + _qs;
    }

    saveProductData = (toAdd, productId) => {
        let _products = {
            Products: [],
            Points: 0,
            SerialNumber: [],
            TotalProductsFound: 0
        };

        if (this.state.addedProducts.length > 0 && this.state.addedProducts.length < 6) {
            this.setValidationState(true, "products");
            _products.TotalProductsFound = this.state.addedProducts.length;
        }

        else
            this.setValidationState(false, "products");

        // If true then add products, else remove
        if (toAdd) {
            this.state.addedProducts.forEach((val) => {
                val.ServiceId = this.getAssignedService(val.ProductId);
                _products.Products.push(val);
                _products.SerialNumber.push(val.ProductId);
            });
            //Calculate Points before submitting
            if (this.state.ShowPoints) {
                this.state.addedProducts.forEach((val) => {
                    _products.Points += parseInt(val.ProductPoints);
                });
            }
            else
                _products.Points = 0;
        }
        else if (!toAdd && productId) {
            this.state.addedProducts.forEach((val) => {
                if (val.ProductId != productId) {
                    val.ServiceId = this.getAssignedService(val.ProductId);
                    _products.Products.push(val);
                    _products.SerialNumber.push(val.ProductId);
                }
            });
            //Calculate Points before submitting
            if (this.state.ShowPoints) {
                this.state.addedProducts.forEach((val) => {
                    _products.Points += parseInt(val.ProductPoints);
                });
            }
            else
                _products.Points = 0;
        }

        this.setFormValues(_products);
        return this.state.formValues;
    }

    setFormValues = (obj) => {
        return new Promise((resolve, reject) => {
            let _formIsValid = false;
            if (!this.props.isEditing) {
                let values = Object.assign(this.state.formValues, obj);
                let _installerId = null;
                if (!this.props.isSitecore) {
                    /** Get the installer id from query string **/
                    _installerId = QueryString.getValue("installerid");
                    if (_installerId) {
                        values.InstallerId = _installerId;
                    }
                    this.setState({
                        formValues: values
                    }, () => {
                        _formIsValid = this.verifyIfFormIsValid();
                        resolve(_formIsValid);
                    });
                }
                else {
                    /** TEMPORARY WHILE LOGIN IS NOT AVAILABLE - Get the installer id from query string **/
                    _installerId = QueryString.getValue("installerid");
                    if (_installerId) {
                        values.InstallerId = _installerId;
                    }
                    this.setState({
                        formValues: values
                    }, () => {
                        _formIsValid = this.verifyIfFormIsValid();
                        resolve(_formIsValid);
                    });
                }
            }
            _formIsValid = this.verifyIfFormIsValid();
            resolve(_formIsValid);
        });
    }

    getAssignedService = (productId) => {
        let _service = this.state.productsServices.find(item => item.ProductId === productId);

        if (_service) {
            return _service.Value; //the Service Id
        }

        return null;
    }

    getCombiProducts = (items, className) => {
        let _return = [];

        items.forEach((item, i) => {
            _return.push(
                <div key={i} className={"product-list--" + className + " " + "product-list--combi"}>
                    <div className="product-list--img">
                        <img src={item.ProductImage} alt={item.ProductName} />
                    </div>
                    <div className="product-list--desc">
                        <p className="product-list--title">{item.ProductName}</p>
                    </div>
                </div>
            );
        });

        return _return;
    }

    formatProductId = (productId) => {
        let part1 = String(productId).substr(0, 2); // 00
        let part2 = String(productId).substr(2, 4); // 0000
        let part3 = String(productId).substr(6, 7); // 0000000
        return `${part1} ${part2} ${part3}`; //00 0000 0000000
    }

    render() {
        return (
            <div>
                <div className={"form-customer form--single-upload " + (this.state.showServiceWindow === true ? "hide" : "")}>
                    <div className="form">
                        <div className="cu-gy">
                            <div className="contextual-title-bold">
                                <span>Uw productinformatie</span>
                            </div>

                            <RegistrationProductSearchCustomer
                                data={this.props.data}
                                isSitecore={this.props.isSitecore}
                                defaultInputValue={this.state.queryValues.serialNumber != "" ? this.state.queryValues.serialNumber : undefined}
                                showPoints={this.state.ShowPoints}
                                productsResult={this.state.productsResult}
                                addedProducts={this.state.addedProducts}
                                AddProduct={this.addProduct}
                                AddProductToContainer={this.addProductToContainer}
                                RemoveProduct={this.removeProduct}
                                ClearProductResults={this.clearProductResults}
                                isRegistered={this.state.isRegistered}
                                isSerialNumberActive={this.state.isSerialNumberActive}
                                isDuplicate={this.state.isDuplicate}
                                ClearWarnings={this.clearWarnings}
                                ClearResult={this.clearResult}
                                productSearchTitle={this.state.productSearchTitle}
                                productLimitCtr={this.state.productLimitCtr}
                                isProductLimitReached={this.state.isProductLimitReached}
                                GetCombiProducts={this.getCombiProducts}
                                FormatProductId={this.formatProductId}
                                isBulk={this.props.isBulk}
                                singleEntry={this.props.singleEntry}
                                isEditing={this.props.isEditing}
                            />
                            <DatePicker data={this.props.data}
                                defaultSelectedDate={this.state.queryValues.installationDate != "" ? new Date(this.state.queryValues.installationDate) : undefined}
                                setFormValues={this.setFormValues}
                                isSitecore={this.props.isSitecore}
                                isBulk={this.props.isBulk}
                                singleEntry={this.props.singleEntry} />
                        </div>
                        <InstallerSearch
                            paginationSlice="4"
                            callback={this.testLog}
                            data={this.props.data}
                        />
                        <div className="registration-customer-form">
                            <div className="cu-white cprofile">
                                <ConsumerProfileFrom data={this.state.profileFormFields} />
                            </div>
                        </div>
                        <div className="cu-yellow">
                            <div className="form-group form-cus">
                                <div className="contextual-title-bold">
                                    Blijf in contact en ontvang als eerste informatie over:</div>
                                <div className="row">
                                    <div className="columns medium-9">
                                        <div>
                                            <span>*Nieuwe modellen, duurzaamheid en innovaties</span>
                                        </div>
                                        <div>
                                            <span>*Speciale aanbiedingen en (kortings)acties</span>
                                        </div>
                                        <div>
                                            <span>*tips en trucs omtrent jouw apparatuur</span>
                                        </div>
                                    </div>
                                    <div className="columns medium-3">
                                        <div className="dashboard--promo-new-product__img">
                                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzUV5al5IIIwrHFbycg7syEcvcWDzHbvf5g37elHFpPGCCYLcb" />
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="checkbox-selection">
                                        <div>
                                            <label className="checkbox-wrapper" htmlFor="geen-cv">
                                                <input type="checkbox" name="storing" id="geen-cv" value="geenCV" />
                                                <span>Ja, ik ontvang graag e-mailnieuwsbrieven van
                                                    Remeha over bovenstaande onderwerpen</span>
                                            </label>
                                            <label>
                                                <div className="checkbtn">In onze <a href="#">privacyverklaring</a>  kan je lezen hoe wij jouw gegevens verzamelen, verwerken en gebruiken.</div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="cu-white-privacy">
                            <div className="form-group form-cus">
                                <div className="form-group">
                                    <div className="checkbox-selection">
                                        <div>
                                            <label className="checkbox-wrapper" htmlFor="agree2">
                                                <input type="checkbox" name="agreebox" id="agree2" value="agree2" />
                                                <span>Ja, ik ga akkoord met de <a href="#">gebruikersvoorwaarden</a> van MijnRemeha
                                                </span>
                                            </label>
                                            <label>
                                                <div className="checkbtn">Met jouw registratie ga je akkoord met de verzameling en verwerking van jouw persoonsgegevens voor naleving van de garantieregistratie, conform de <a href="#">privacyverklaring</a> van Remeha. </div>
                                            </label>
                                            <div className="input-row--first-name">
                                             <a href="" className="button grey arrow-right" id="project_select">
                                              <span>Registreren</span>
                                             </a>
                                           </div>
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <ServiceWindow
                    data={this.props.data}
                    productsResult={this.state.addedProducts}
                    productsServices={this.state.productsServices}
                    showPoints={this.state.ShowPoints}
                    showServiceWindow={this.state.showServiceWindow}
                    triggerServiceWindow={this.triggerServiceWindow}
                    ManageProductService={this.manageProductService}
                    GetCombiProducts={this.getCombiProducts}
                    FormatProductId={this.formatProductId}
                    isEditing={this.props.isEditing}
                    isSitecore={this.props.isSitecore}
                    action={this.submitForm}
                />

            </div>
        );
    }
}

module.exports = CustomerSingleForm;
