import React, { Component } from "react";

class Helppopup  extends Component {
    constructor(props) {
        super(props);
    

    this.state = {
        showModal: false
    };
   }

    modalC = () => {
        this.setState({ showModal: !this.state.showModal });
         
    }  
    render() {
        return (
         <div>
            <div class="helpbtn button secondary" onClick={this.modalC}><span>Zoeken</span></div>
        </div>
     );
   
}
}
 
export default Helppopup;