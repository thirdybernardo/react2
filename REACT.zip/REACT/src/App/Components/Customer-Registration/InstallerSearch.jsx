import React from "react";
import InstallerSvc from "../../API/Installer";
import TextInput from "../Generic/TextInput";
import Pagination from '../Generic/Pagination';
import AddressInput from '../Generic/Forms/AddressInput';
import DisplayHelper from '../../Helpers/DisplayHelper';


class InstallerSearch extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            results: [],
            didSearch: false,
            isManualInput: false,
            paginationOptions: {
                currentPagination: 1,
                targetPagination: 1,
                totalPagination: 0,
                resultKeysCount: 0
            },
            paginationSlicesFallback: 1,
            formValues: {},
            addressDidMatch: false,
            tempMatchedInstaller: {}
        };

        this.refInstallerName = React.createRef();
        this.refInstallerLocation = React.createRef();
        this.refLastname = React.createRef();
        this.refFirstname = React.createRef();
        this.refStreetName = React.createRef();
        this.refCity = React.createRef();
        this.refInstallerLastname = React.createRef();
        this.refHouseNumber = React.createRef();
        this.refPostCode = React.createRef();

        this.paginationStyle = { //TO BE WORKED ON BY FED
            height: "fit-content"
        };

        this.enums = {
            rdoManual: "manual",
        };
        this.addressFields = {
            houseNumber: "HouseNumber",
            postalCode: "PostalCode"
        };
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.results != this.state.results) {

            let _data = [...this.state.results];
            let _slice = this.props.paginationSlice <= 0 ? this.state.paginationSlicesFallback : this.props.paginationSlice;
            let _totalP = (_data.length / _slice);
            _totalP = (_totalP % 1).toFixed(1).substring(2) != 0 ? Math.floor(_totalP) + 1 : _totalP;
            this.updatePaginationOptions(["resultKeysCount:" + _data.length, "totalPagination:" + _totalP, "currentPagination:" + 1]);
        }
    }

    updatePaginationOptions = (newParams) => {
        let paginationOptionsCopy = Object.assign({}, this.state.paginationOptions);
        newParams.forEach((val, index) => {
            let thisVal = String(val).split(":");
            paginationOptionsCopy[thisVal[0]] = thisVal[1];
        });
        this.setState({ paginationOptions: paginationOptionsCopy });
    }

    callback = (e) => {
        if (this.props.callback)
            this.props.callback(e);
        else
            return undefined;
    }

    searchInstaller = () => {
        if (this.refInstallerName.current.value || this.refInstallerLocation.current.value)
            InstallerSvc.searchInstaller(this.refInstallerName.current.value, this.refInstallerLocation.current.value, (data) => {
                this.setState({
                    results: data,
                    didSearch: true
                });
            });
    }

    searchInstallerByAddress = (postalCode, houseNumber) => {
        if (postalCode && houseNumber)
            InstallerSvc.searchInstallerByAddress(postalCode, houseNumber, (data) => {
                this.setState({
                    addressDidMatch: data != null,
                    tempMatchedInstaller: data
                });
            });
    }

    searchOnEnter = (e) => {
        if (e.key === 'Enter') {
            this.searchInstaller();
        }

    }

    renderSearchResultsHeader = (resultsCount) => {
        let _resultsCount = resultsCount === undefined ? 0 : resultsCount;
        let _name = this.refInstallerName.current.value;
        let _location = this.refInstallerLocation.current.value;
        let _query = _location + " " + _name;
        _query = !_name ? _query.trimRight() : _query.trimLeft();

        return (
            `Er zijn ${_resultsCount} resultaten gevonden voor <b>'${_query}'</b>`
        );
    }

    renderDetailsList = (value) => {
        let _info = [];
        _info = value.AddressResult.split(',').reverse();
        _info.push(value.PersonalEmailAddress);
        return (
            <ul>
                {_info.map((v, i) => {
                    return <li key={i}>{v}</li>;
                })}
            </ul>
        );
    }

    setFormValues = (field, value, callback) => {
        let obj = Object.assign(this.state.formValues);
        obj[field] = value;
        this.setState({ formValues: obj }, () => {
            if (callback)
                callback();
        });


        this.suggestInstaller(field, obj);
    }

    suggestInstaller = (field, obj) => {
        if (field === this.addressFields.postalCode || field === this.addressFields.houseNumber) {
            let postalCode = obj[this.addressFields.postalCode];
            let houseNumber = obj[this.addressFields.houseNumber];
            let tempPostalCode = this.state.tempMatchedInstaller ? this.state.tempMatchedInstaller[this.addressFields.postalCode] : "";
            let tempHouseNumber = this.state.tempMatchedInstaller ? this.state.tempMatchedInstaller[this.addressFields.houseNumber] : "";
            if (postalCode != tempPostalCode || houseNumber != tempHouseNumber)
                this.searchInstallerByAddress(postalCode, houseNumber);

            if (postalCode === "" && houseNumber === "") {
                this.setState({
                    addressDidMatch: false,
                    tempMatchedInstaller: {}
                });
            }
        }
    }

    onRadioSelect = (e) => {
        let _radioValue = e.target.value;

        if (_radioValue === this.enums.rdoManual) {
            this.setState({
                isManualInput: true,
                formValues: {}
            });
        } else {
            this.setState({
                isManualInput: false,
                formValues: {}
            });
            this.setFormValues("Id", _radioValue);
        }

    }

    renderMatchingInstaller = () => {
        if (this.state.addressDidMatch) {
            return (<div className="column small-12"><i>{this.props.data.item.InstallerSearchSuggestQuestion} <a href='javascript:void(0);' onClick={e => this.populateInstallerForm()}>{this.state.tempMatchedInstaller["Firstname"]} {this.state.tempMatchedInstaller["Lastname"]}</a>?</i><br /></div>);
        }
        return "";
    }

    populateInstallerForm = () => {
        this.setState({
            addressDidMatch: false
        });
        DisplayHelper.ChangeInputElemValueProgramatically(this.refFirstname, this.state.tempMatchedInstaller["Firstname"]);
        DisplayHelper.ChangeInputElemValueProgramatically(this.refLastname, this.state.tempMatchedInstaller["Lastname"]);
        DisplayHelper.ChangeInputElemValueProgramatically(this.refPostCode, this.state.tempMatchedInstaller["PostalCode"]);
        DisplayHelper.ChangeInputElemValueProgramatically(this.refHouseNumber, this.state.tempMatchedInstaller["HouseNumber"]);
        DisplayHelper.ChangeInputElemValueProgramatically(this.refStreetName, this.state.tempMatchedInstaller["StreetName"]);
        DisplayHelper.ChangeInputElemValueProgramatically(this.refCity, this.state.tempMatchedInstaller["City"]);
    }

    searchForm = () => {
        return (
            <div className="installerform">
                <div className="cu-white">
                    <div className="form-group form-cus customer-data">
                        <div className="row section-title">
                            <div className="columns medium-12">
                                <div className="contextual-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.InstallerSearchWhoInstalledTitle }}></div>
                            </div>
                        </div>
                        <div className="row section-field customer-input">
                            <div className="small-12 input-row--salutation">
                                <label>
                                    <span dangerouslySetInnerHTML={{ __html: this.props.data.item.InstallerSearchWhoInstalledSubTitle }} />
                                </label>
                            </div>
                            <div className="small-12 input-row--name">
                                <div className="input-row--first-name">
                                    <label htmlFor="installerFullnamenew" className="input-wrapper">
                                        <TextInput
                                            id="installerFullname"
                                            label={this.props.data.item.InstallerSearchLocationInputLabel}
                                            placeholder={this.props.data.item.InstallerSearchLocationInputPlaceholder}
                                            refData={this.refInstallerLocation}
                                            keyUp={e => this.searchOnEnter(e)}
                                        />
                                    </label>
                                </div>
                                <div className="center-name">
                                    <span>of</span>
                                </div>
                                <div className="input-row--last-namenew">
                                    <label htmlFor="customer-last-name" className="input-wrapper">
                                        <TextInput
                                            id="customer-last-name"
                                            label={this.props.data.item.InstallerSearchNameInputLabel}
                                            placeholder={this.props.data.item.InstallerSearchNameInputPlaceholder}
                                            refData={this.refInstallerName}
                                            keyUp={e => this.searchOnEnter(e)}
                                        />
                                    </label>
                                </div>
                                <div className="input-row--first-name">
                                    <a href="javascript:void(0);" onClick={() => this.searchInstaller()} className="button secondary" id="project_select">
                                        <span dangerouslySetInnerHTML={{ __html: this.props.data.item.InstallerSearchSearchButton }} />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    searchResults = () => {
        let _html = !this.state.didSearch ? "" :
            <div className="result-form">
                <div className="cu-lightblue">
                    <div className="product-registration--campaign">
                        <div className="campaign--for">
                            <div className="form--email-confirmation">
                                <div>
                                    <span
                                        className="title"
                                        dangerouslySetInnerHTML={{ __html: this.renderSearchResultsHeader(this.state.results.length) }}
                                    />
                                </div>
                                <div className="radiobuttons-container">
                                    {
                                        this.state.results.length > 0 ?
                                            this.state.results.map((value, i) => {
                                                if (i < (this.props.paginationSlice * this.state.paginationOptions.currentPagination) && i >= (this.props.paginationSlice * (this.state.paginationOptions.currentPagination - 1))) {
                                                    return (<label key={i} htmlFor={`inst_${i}`} className="mdl-radio mdl-js-radio">
                                                        <input className="mdl-radio__button" id={`inst_${i}`} type="radio" name="map-message" value={value.ClientNumber} onClick={e => this.onRadioSelect(e)} />
                                                        <span className="mdl-radio__label">{`${value.Firstname} ${value.Lastname}`}</span>
                                                        {this.renderDetailsList(value)}
                                                    </label>);
                                                }
                                            }) : ""
                                    }
                                </div>
                                <div className="pagination-container" style={this.paginationStyle}>
                                    <Pagination
                                        data={this.props.data}
                                        paginationOptions={this.state.paginationOptions}
                                        updatePaginationOptions={this.updatePaginationOptions}
                                    />
                                </div>
                                <label htmlFor="manualInstaller" className="mdl-radio mdl-js-radio">
                                    <input id="manualInstaller" className="mdl-radio__button" type="radio" name="map-message" value={this.enums.rdoManual} onClick={e => this.onRadioSelect(e)} />
                                    <span
                                        className="mdl-radio__label"
                                        dangerouslySetInnerHTML={{ __html: ` ${this.props.data.item.InstallerSearchManualRdoLabel}` }}
                                    />
                                </label>
                                {/*MANUAL INSTALLER FORM HERE*/}
                                {this.installerForm()}
                            </div>
                        </div>
                    </div>
                </div>
            </div >;
        return _html;
    }

    installerForm = () => {
        if (this.state.isManualInput) {
            return (<div className="row">
                <div className="column medium-12">
                    <div className="general-data form">
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns small-6">
                                    <label htmlFor="Firstname" className="input-wrapper">
                                        <TextInput
                                            id="Firstname"
                                            label={this.props.data.item.InstallerSearchFirstName}
                                            placeholder={this.props.data.item.InstallerSearchFirstNamePlaceholder}
                                            refData={this.refFirstname}
                                            required="text-required"
                                            type="required"
                                            validate={true}
                                            callback={this.setFormValues}
                                        />
                                    </label>
                                </div>
                                <div className="columns small-6">
                                    <label htmlFor="Lastname" className="input-wrapper">
                                        <TextInput
                                            id="Lastname"
                                            label={this.props.data.item.InstallerSearchLastName}
                                            placeholder={this.props.data.item.InstallerSearchLastNamePlaceholder}
                                            refData={this.refLastname}
                                            required="text-required"
                                            type="required"
                                            validate={true}
                                            callback={this.setFormValues}
                                        />
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                {this.renderMatchingInstaller()}
                                <div className="columns small-12">
                                    <AddressInput
                                        callback={this.setFormValues}
                                        label={this.props.data.item.InstallerSearchAddressTitle}
                                        postCodeId="PostalCode"
                                        postcodePlaceholder={this.props.data.item.InstallerSearchAddressPostalPlaceholder}
                                        refPostCode={this.refPostCode}
                                        houseNumberId="HouseNumber"
                                        houseNumberPlaceholder={this.props.data.item.InstallerSearchAddressHouseNrPlaceholder}
                                        refHouseNumber={this.refHouseNumber}
                                        message={this.props.data.item.InstallerSearchNotFoundAddress}
                                        required="text-required"
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns small-12">
                                    <label htmlFor="StreetName" className="input-wrapper">
                                        <TextInput
                                            id="StreetName"
                                            label={this.props.data.item.InstallerSearchStreetNameTitle}
                                            placeholder={this.props.data.item.InstallerSearchStreetNamePlaceholder}
                                            refData={this.refStreetName}
                                            required="text-required"
                                            type="required"
                                            validate={true}
                                            callback={this.setFormValues}
                                            readOnly={true}
                                        />
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns small-12">
                                    <label htmlFor="City" className="input-wrapper">
                                        <TextInput
                                            id="City"
                                            label={this.props.data.item.InstallerSearchCityTitle}
                                            placeholder={this.props.data.item.InstallerSearchCityPlaceholder}
                                            refData={this.refCity}
                                            required="text-required"
                                            type="required"
                                            validate={true}
                                            callback={this.setFormValues}
                                            readOnly={true}
                                        />
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>);
        }
        return "";
    }

    render() {
        return (
            <React.Fragment>
                {this.searchForm()}
                {this.searchResults()}
            </React.Fragment>
        );
    }
}

module.exports = InstallerSearch;