import React, { Component } from 'react';
import AddressInput from '../Generic/Forms/AddressInput';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import TextInput from '../Generic/TextInput';
import RadioInput from '../Generic/RadioInput';
import ToggleInput from '../Generic/ToggleInput';
import ValidatorHelper from "../../Helpers/Validator";
import GoogleMap from '../Maps/GoogleMap';
import Slider from '../Generic/Slider';
import DistanceDroplist from '../Maps/DistanceDroplist';
import InstallerAPI from '../../API/Installer';
import InstallerHelper from "../../Helpers/InstallerHelper";
import UserInformation from './UserInformation';
import StickyNavigation from '../Generic/StickyNavigation';
import Data from "../../Data/Data";


class ProfileForm extends Component {
    constructor(props) {
        super(props);
        /**MODELS */
        this.enums = {
            PostalCode: "PostalCode",
            HouseNumber: "HouseNumber",
            CompanyEmailAddress: 'CompanyEmailAddress',
            CompanyTelephoneNo: 'CompanyTelephoneNo',
            CompanyWebsite: 'CompanyWebsite',
            PersonalEmailAddress: 'PersonalEmailAddress',
            PersonalTelephoneNo: 'PersonalTelephoneNo',
            Salutation: 'Salutation',
            Firstname: "Firstname",
            Lastname: "Lastname"
        };
        this.profileData = {
            Firstname: "",
            Lastname: "",
            Salutation: "",
            PostalCode: "",
            HouseNumber: "",
            Latitude: 0,
            Longitude: 0,
            PersonalTelephoneNo: "",
            CompanyTelephoneNo: "",
            PersonalEmailAddress: "",
            CompanyEmailAddress: "",
            CompanyWebsite: "",
            EmailUsedForBilling: false,
            EmailUsedForSvcReports: false,
            CompanyName: "",
            ClientNumber: "",
            CompanyAcctManager: "",
            IsSaleOfProductSvc: false,
            IsRentalOfProductSvc: false,
            IsRemehaConnectSvc: false,
            IsStoringSvc: false,
            IsMaintenanceSvc: false,
            AddressResult: ""

        };
        this.mapsConfiguration = {
            ApiKey: "",
            Language: "",
            DefaultLatitude: 0,
            DefaultLongitude: 0
        };
        /**MODELS */

        this.references = {
            PostalCode: React.createRef(),
            HouseNumber: React.createRef(),
            ProfileEmail: React.createRef(),
            ProfileTelephone: React.createRef(),
            Website: React.createRef(),
            CustomerEmail: React.createRef(),
            CustomerTelephone: React.createRef(),
            CustomerFirstname: React.createRef(),
            CustomerLastname: React.createRef()
        };

        this.state = {
            formValues: this.profileData,
            requiredClassName: "text-required",
            wrapperClassName: "switch-wrapper",
            isProfileDataLoaded: false,
            mapRadius: 5000,
            mapsConfiguration: this.mapsConfiguration,
            defaultDistanceList: [
                { Text: "+3km", Value: 3 },
                { Text: "+5km", Value: 5 },
                { Text: "+10km", Value: 10 }
            ],
            addressResult: "",
            stickyNavFields: {
                item: {},
                links: {}
            },
            userinfoFields: {
                item: {}
            }
        };
        this.validators = ValidatorHelper;
        this.formValues = null;
    }

    componentDidMount() {
        if (!this.props.isSitecore) {
            Data.getData("StickyNavFields", (data) => {
                this.setState({ stickyNavFields: data });
            });

            Data.getData("UserInformationFields", (data) => {
                this.setState({ userinfoFields: data });
            });
        }
        this.getInstallerInfo();

    }


    componentDidUpdate(prevProps, prevState) {
        //init validation messages
        if (!this.props.isSitecore) {
            if (prevProps.data.item != this.props.data.item) {
                this.validators["required"].rules[0].message = this.props.data.item.RequiredErrorMesage;
                this.validators["telephone"].rules[0].message = this.props.data.item.TelephoneInvalidMessage;
                this.validators["email"].rules[0].message = this.props.data.item.EmailInvalidMessage;
                this.validators["website"].rules[0].message = this.props.data.item.WebsiteInvalidMessage;
            }
        }
    }

    populateFieldValues = () => {
        if (this.state.formValues) {
            this.references.Website.current.value = this.state.formValues.CompanyWebsite;
            this.references.PostalCode.current.value = this.state.formValues.PostalCode;
            this.references.HouseNumber.current.value = this.state.formValues.HouseNumber;
            this.references.ProfileEmail.current.value = this.state.formValues.CompanyEmailAddress;
            this.references.ProfileTelephone.current.value = this.state.formValues.CompanyTelephoneNo;
            this.references.CustomerEmail.current.value = this.state.formValues.PersonalEmailAddress;
            this.references.CustomerTelephone.current.value = this.state.formValues.PersonalTelephoneNo;
            this.references.CustomerFirstname.current.value = this.state.formValues.Firstname;
            this.references.CustomerLastname.current.value = this.state.formValues.Lastname;

        }
    }

    setFormValues = (field, value, callback) => {
        let obj = Object.assign(this.state.formValues);
        obj[field] = value;
        this.setState({ formValues: obj }, () => {
            if (callback)
                callback();
        });
    }


    /*<---MAP SECTION RELATED*/
    setMapCoordinates = (addressResult, points = "") => {
        if (addressResult) {
            points = points.substring(5).replace('(', '').replace(')', '').split(" ");
            let _lng = parseFloat(points[0]);
            let _lat = parseFloat(points[1]);

            let _config = this.state.mapsConfiguration;
            _config.DefaultLongitude = _lng;
            _config.DefaultLatitude = _lat;

            let _formValues = this.state.formValues;
            _formValues.Longitude = _lng;
            _formValues.Latitude = _lat;
            _formValues.AddressResult = addressResult;
            this.setState({
                mapsConfiguration: _config,
                formValues: _formValues,
                addressResult: addressResult
            });
        }
    }

    adjustRadius = (e) => {
        let _value = null;
        //IF TRIGGERED BY SLIDER
        if (e.target) {
            _value = e.target.value;
        }
        //IF TRIGGERED BY CUSTOM DROPLIST
        else if (e.Value) {
            _value = (e.Value * 1000);
        }
        this.setState({
            mapRadius: _value
        });
    }

    getDistanceText = () => {
        let _value = this.state.mapRadius / 1000;
        return `+${_value}km`;
    }

    /*MAP SECTION RELATED--->*/

    renderServices = () => {
        let _return = [];
        let _self = this;

        if (this.props.data.item && this.props.data.dictionary && this.state.isProfileDataLoaded) {
            let _dictionary = this.props.data.dictionary;
            let _wrapperClassName = this.state.wrapperClassName;
            let switchYesLabel = this.props.data.item.SwitchYesLabel;
            let switchNoLabel = this.props.data.item.SwitchNoLabel;

            var _profileData = this.state.formValues;
            if (_profileData) {
                Object.keys(_dictionary).map(function (key, i) {
                    let fieldLabel = _dictionary[key];
                    let checkedState = false;
                    switch (key) {
                        case "IsSaleOfProductSvc":
                            checkedState = _profileData.IsSaleOfProductSvc;
                            break;
                        case "IsRentalOfProductSvc":
                            checkedState = _profileData.IsRentalOfProductSvc;
                            break;
                        case "IsStoringSvc":
                            checkedState = _profileData.IsStoringSvc;
                            break;
                        case "IsRemehaConnectSvc":
                            checkedState = _profileData.IsRemehaConnectSvc;
                            break;
                        case "IsMaintenanceSvc":
                            checkedState = _profileData.IsMaintenanceSvc;
                            break;
                    }

                    _return.push(
                        <div key={i} className="columns medium-12">
                            <ToggleInput id={key}
                                wrapperClassName={_wrapperClassName}
                                switchYesLabel={switchYesLabel}
                                switchNoLabel={switchNoLabel}
                                label={fieldLabel}
                                callback={_self.setFormValues}
                                defaultChecked={checkedState}
                            />
                        </div>
                    );
                });
            }

        }

        return _return;
    }
  
    /*MOVED*/
    submitProfile = () => {
        var errorLabels = document.getElementsByClassName("error");
        if (errorLabels.length > 0) {
            alert("Please correct form errors");
        }
        else {
            InstallerHelper.GetInstallerId(this.props.isSitecore, (_installerId) => {
                InstallerAPI.UpdateProfileData(_installerId, this.state.formValues, (callback) => {
                    if (callback && callback.status === 200) {
                        alert("Profile successfully updated!");
                    }
                });
            });
        }
    }

    getInstallerInfo = () => {
        InstallerHelper.GetInstallerId(this.props.isSitecore, (_installerId) => {
            if (_installerId) {
                InstallerAPI.GetInstallerInfo(_installerId, (data) => {
                    if (data.Results) {
                        this.setState({
                            formValues: data.Results.Installer,
                            mapsConfiguration: data.Results.MapsConfiguration,
                            addressResult: data.Results.Installer.AddressResult,
                            isProfileDataLoaded: true
                        }, () => {
                            this.populateFieldValues();
                        });
                    }
                });
            }
        });
    }
    /*MOVED*/

    render() {
        return (
            <div>
                {/* START STICKY NAV COMPONENT */}
                <StickyNavigation data={this.props.data} isSitecore={this.props.isSitecore} callback={this.submitProfile} />
                {/* END STICKY NAV COMPONENT */}
                {/* START USER INFO COMPONENT */}
                <UserInformation data={this.props.data} isSitecore={this.props.isSitecore} />
                {/* END USER INFO COMPONENT */}

                <div className="profile-form">
                    <a className="anchor" name="algemenegegevens"></a>
                    <div className="general-data form">
                        <div className="contextual-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.GeneralDataLabel }}></div>
                        <AddressInput
                            callback={this.setFormValues}
                            label={this.props.data.item.AddressTitle}
                            postCodeId={this.enums.PostalCode}
                            postcodePlaceholder={this.props.data.item.PostcodePlaceholder}
                            refPostCode={this.references.PostalCode}
                            houseNumberId={this.enums.HouseNumber}
                            houseNumberPlaceholder={this.props.data.item.HousenumberPlaceholder}
                            refHouseNumber={this.references.HouseNumber}
                            message={this.props.data.item.NotFoundValidationMessage}
                            required={this.state.requiredClassName}
                            setMapCoordinates={this.setMapCoordinates}
                        />
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-6">
                                    <TextInput id={this.enums.CompanyTelephoneNo}
                                        label={this.props.data.item.CustomerDataTelephone}
                                        placeholder={this.props.data.item.CustomerDataTelephonePlaceholder}
                                        refData={this.references.ProfileTelephone}
                                        type="telephone"
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        validate={true}
                                    />
                                </div>
                                <div className="columns medium-6">
                                    <TextInput id={this.enums.CompanyWebsite}
                                        label={this.props.data.item.Website}
                                        placeholder={this.props.data.item.WebsitePlaceholder}
                                        refData={this.references.Website}
                                        type="website"
                                        callback={this.setFormValues}
                                        validate={true}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-9">
                                    <TextInput id={this.enums.CompanyEmailAddress}
                                        label={this.props.data.item.CustomerDataEmailAddress}
                                        placeholder={this.props.data.item.CustomerDataEmailAddressPlaceholder}
                                        refData={this.references.ProfileEmail}
                                        type="email"
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        validate={true}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="inner-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.ContactDataLabel }}></div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-12">
                                    <RadioInput
                                        id={this.enums.Salutation}
                                        label={this.props.data.item.CustomerDataSalutation}
                                        options={this.props.data.item.Salutation}
                                        required={this.state.requiredClassName}
                                        isEditing={this.props.isEditing}
                                        callback={this.setFormValues}
                                        checkedItem={this.state.formValues.Salutation}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field input-row--name">
                                <div className="columns medium-6 input-row--first-name">
                                    <TextInput id={this.enums.Firstname}
                                        label={this.props.data.item.CustomerDataFirstName}
                                        placeholder={this.props.data.item.CustomerDataFirstNamePlaceholder}
                                        refData={this.references.CustomerFirstname}
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        type="required"
                                        validate={true}

                                    />
                                </div>
                                <div className="columns medium-6 input-row--last-name">
                                    <TextInput id={this.enums.Lastname}
                                        label={this.props.data.item.CustomerDataLastName}
                                        placeholder={this.props.data.item.CustomerDataLastNamePlaceholder}
                                        refData={this.references.CustomerLastname}
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        type="required"
                                        validate={true}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-9">
                                    <TextInput id={this.enums.PersonalTelephoneNo}
                                        label={this.props.data.item.CustomerDataTelephone}
                                        placeholder={this.props.data.item.CustomerDataTelephonePlaceholder}
                                        refData={this.references.CustomerTelephone}
                                        type="telephone"
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        validate={true}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-9">
                                    <TextInput id={this.enums.PersonalEmailAddress}
                                        label={this.props.data.item.CustomerDataEmailAddress}
                                        placeholder={this.props.data.item.CustomerDataEmailAddressPlaceholder}
                                        refData={this.references.CustomerEmail}
                                        type="email"
                                        required={this.state.requiredClassName}
                                        callback={this.setFormValues}
                                        validate={true}
                                    />
                                </div>
                            </div>
                        </div>

                    </div>
                    <a className="anchor" name="werkgebied"></a>
                    <div className="working-area form">
                        <div className="contextual-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.WorkAreaLabel }}></div>
                        <div className="form-group">
                            <div className="row section-field">
                                <div className="columns medium-12">
                                    <span className="input-validation has-success">{this.state.addressResult}</span>
                                </div>
                            </div>
                            <div className="row section-field">
                                <div className="columns medium-9">
                                    <Slider
                                        data={this.props.data}
                                        callback={this.adjustRadius}
                                        value={this.state.mapRadius}
                                        isSitecore={this.props.isSitecore}
                                    />
                                </div>
                                <div className="columns medium-3 distancedrop">
                                    <DistanceDroplist
                                        distanceList={this.state.defaultDistanceList}
                                        callback={this.adjustRadius}
                                        sliderDistanceText={this.getDistanceText()} />
                                </div>
                            </div>
                            <div className="row section-field">
                                <div className="columns medium-12">
                                    <div className="map-container">
                                        <GoogleMap
                                            data={this.props.data}
                                            radius={this.state.mapRadius}
                                            config={this.state.mapsConfiguration}
                                            isSitecore={this.props.isSitecore}
                                            addressResult={this.state.addressResult}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a className="anchor" name="diensten"></a>
                    <div className="services form">
                        <div className="contextual-title-bold" dangerouslySetInnerHTML={{ __html: this.props.data.item.ServicesLabel }}></div>
                        <p dangerouslySetInnerHTML={{ __html: this.props.data.item.ServicesDescription }}></p>
                        <div className="service-options">

                        </div>
                        <div className="form-group">
                            <div className="row section-field">
                                {this.renderServices()}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

module.exports = ProfileForm;