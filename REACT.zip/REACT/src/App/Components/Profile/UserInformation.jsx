import React from 'react';
import Data from '../../Data/Data';
import LabeledFields from '../Generic/LabeledFields';


class Information extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            profileData: {
                CompanyName: "{{Company Name}}",
                KvKNummer: "{{KvK nummer}}",
                Klantnummer: "{{KlantNummer}}",
                AccountManager: "{{Account Manager}}"
            }
        };
    }

    componentDidMount() {
        if (!this.props.isEditing) {
            if (!this.props.isSitecore) {
                //Gets the list of registered products
                Data.getData("ProfileMockup", data => {
                    this.setState({ profileData: data.Profile });
                });
            }
        } else {
            this.setState({
                profileData: {
                    CompanyName: "{{Company Name}}",
                    KvKNummer: "{{KvK nummer}}",
                    Klantnummer: "{{KlantNummer}}",
                    AccountManager: "{{Account Manager}}"
                }
            });
        }
    }


    render() {
        return (
            <React.Fragment>
                <div className="installer-info">
                    <div className="title">{this.state.profileData.CompanyName} </div>
                    <LabeledFields
                        label={this.props.data.item.ClientNumberLabel}
                        value={this.state.profileData.Klantnummer}
                    />
                    <LabeledFields
                        label={this.props.data.item.AccountManagerLabel}
                        value={this.state.profileData.AccountManager}
                    />
                    <LabeledFields
                        label={this.props.data.item.KvkNumberLabel}
                        value={this.state.profileData.KvKNummer}
                    />
                    {this.props.children}
                </div>
            </React.Fragment>
        );
    }

}

module.exports = Information;