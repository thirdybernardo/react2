import React from 'react';
import Block from '../Generic/Block';
import Button from '../Generic/Button';
import CountBadge from '../Generic/CountBadge';
import ProductRegistrationsList from '../Generic/Lists/ProductRegistrationsList';
import Data from '../../Data/Data';
import QueryString from '../../Data/QueryString';
import SearchHelper from '../../Helpers/SearchHelper';

class RecentRegistrationsTile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isInitialized: false,
            recentProducts: []
        };
    }

    componentDidMount() {
        if (!this.props.isSitecore) {
            Data.getData("MockInstallerRegisteredProducts", (data) => {
                this.setState({ recentProducts: data.Registered });
            });
        }
        else {
            let _installerId = QueryString.getValue("installerid");
            let _query = "";
            let _startD = undefined;
            let _endD = undefined;
            SearchHelper.getRegistrations(_installerId, _query, _startD, _endD, data => {
                if (data.Results) {
                    let _products = data.Results.sort((a, b) => {
                        return new Date(b.InstallationDate) - new Date(a.InstallationDate);
                    });
                    this.setState({ recentProducts: _products });
                }
            }, true);
        }
        this.setState({ isInitialized: true });
    }

    redirectToOverview = () => {
        let _redirect = this.props.data.links.InstalledParkOverviewPage;
        if (_redirect) {
            location.href = _redirect;
        }
    }

    render() {
        return (
            <Block
                containerClass="complete-registration rblock"
                textClass="block--text"
                text={this.props.data.item.Title}
            >
                <CountBadge count={this.state.recentProducts.length} />
                <ProductRegistrationsList
                    isInitialized={this.state.isInitialized}
                    isSitecore={this.props.isSitecore}
                    list={this.state.recentProducts}
                    listSize={this.props.data.item.MaxListSize}
                    wrapperClass="registrations-list hide-for-small"
                />
                <Button
                    text={`${this.props.data.item.ButtonText} (${this.state.recentProducts.length})`}
                    wrapperClassName="hide-for-small"
                    className="button secondary"
                    callback={this.redirectToOverview}
                />
            </Block>
        );
    }
}

module.exports = RecentRegistrationsTile;