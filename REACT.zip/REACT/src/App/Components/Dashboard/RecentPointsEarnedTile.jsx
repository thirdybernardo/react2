import React from 'react';
import Block from '../Generic/Block';
import Button from '../Generic/Button';
import MyCurrentPoints from '../Generic/MyCurrentPoints';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import ProductRegistrationsList from '../Generic/Lists/ProductRegistrationsList';
import Data from '../../Data/Data';
import SearchHelper from '../../Helpers/SearchHelper';
import QueryString from '../../Data/QueryString';
import moment from 'moment';

class RecentPointsEarnedTile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isInitialized: false,
            dateToday: new Date(),
            recentProducts: []
        };
    }

    componentDidMount() {
        if (!this.props.isSitecore) {
            Data.getData("MockInstallerRegisteredProducts", (data) => {
                this.setState({ recentProducts: data.Registered });
            });
        }
        else {
            let _installerId = QueryString.getValue("installerid");
            let _query = "";
            let _startD = undefined;
            let _endD = undefined;
            SearchHelper.getRegistrations(_installerId, _query, _startD, _endD, data => {
                if (data.Results) {
                    let _products = data.Results.sort((a, b) => {
                        return new Date(b.InstallationDate) - new Date(a.InstallationDate);
                    });
                    this.setState({ recentProducts: _products });
                }
            }, true);
        }
        this.setState({ isInitialized: true });
    }

    redirectToShop = () => {
        let _redirect = this.props.data.links.ShopPage;
        if (_redirect) {
            location.href = _redirect;
        }
    }

    render() {
        return (
            <div className="promo-ds dashboard--promo-products">
                <Block
                    containerClass="dashboard--promo-products__title"
                    textClass="date"
                    text={moment(this.state.dateToday).format("DD MMMM YYYY")}
                >
                    <div className="title" dangerouslySetInnerHTML={{ __html: this.props.data.item.Title }} />
                    <MyCurrentPoints
                        containerClass="points"
                        overridePoints={625}
                    />
                </Block>
                <ProductRegistrationsList
                    isInitialized={this.state.isInitialized}
                    isSitecore={this.props.isSitecore}
                    list={this.state.recentProducts}
                    listSize={this.props.data.item.MaxListSize}
                    type={1}
                    containerClass="dashboard--promo-products__products"
                    placeholders={[SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.data.item.InstalledOnLabel)]}
                />
                <Button
                    text={this.props.data.item.ButtonText}
                    wrapperClassName="dashboard--promo-products__button"
                    className="button blue arrow-right"
                    callback={this.redirectToShop}
                />
            </div>
        );
    }
}

module.exports = RecentPointsEarnedTile;