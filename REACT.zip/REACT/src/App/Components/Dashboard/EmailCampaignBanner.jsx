import React from 'react';
import Block from '../Generic/Block';
import Content from '../Generic/Content';
import Button from '../Generic/Button';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import CookieHelper from '../../Helpers/CookieHelper';

class EmailCampaignBanner extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,
            image: undefined
        };
        this.cookieName = "installerEmailCampaignEnable";
    }

    componentDidMount() {
        let _image = this.props.data.item.Image ? (!this.props.isSitecore ? this.props.data.item.Image : SitecoreHelper.getImage(this.props.data.item.Image)) : undefined;
        this.setState({ image: _image });
        if (!CookieHelper.getCookie(this.cookieName)) {
            this.hideShowBanner();
        }
    }

    emailOptIn = () => {
        CookieHelper.setCookie(true, this.cookieName);
        this.hideShowBanner();
        // TODO add non-cookie storing of consent for email campaigns somewhere - currently out of scope of user story
    }

    hideShowBanner = () => {
        this.setState(function (prevState) {
            return { isVisible: prevState.isVisible == false ? true : false };
        });
    }

    render() {
        return (
            <Block
                containerClass={`promo promo-wide promo-blue ${this.state.isVisible ? "" : "hide"}`}
            >
                <div className="image-container">
                    <img src={this.state.image} alt="" />
                </div>
                <Content
                    wrapperClass="content-container"
                    textContent={this.props.data.item.TextContent}
                >
                    <Button
                        noWrapper={true}
                        className="button"
                        text={this.props.data.item.ButtonText}
                        callback={this.emailOptIn}
                    />
                    <Button
                        noWrapper={true}
                        className="button secondary"
                        text={this.props.data.item.ButtonText2}
                        callback={this.hideShowBanner}
                    />
                </Content>
            </Block>
        );
    }

}

module.exports = EmailCampaignBanner;