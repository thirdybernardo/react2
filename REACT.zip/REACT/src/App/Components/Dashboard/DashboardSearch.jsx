import React from 'react';
import SearchBox from '../Generic/SearchBox';

class DashboardSearch extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
        this.dashboardSearchRef = React.createRef();
    }

    handleSearch = (e) => {
        // Scaffold searching
        console.log(`Search Keyword: ${e.target.value}`);
    }


    render() {
        return (
            <SearchBox
                isEditing={this.props.isEditing}
                searchPlaceholder={this.props.data.item.SearchPlaceholder}
                onChangeFunc={this.handleSearch}
                wrapperClass="dashboard--search"
                searchClass="search-wrapper"
                dataRef={this.dashboardSearchRef}
            />
        );
    }

}

module.exports = DashboardSearch;