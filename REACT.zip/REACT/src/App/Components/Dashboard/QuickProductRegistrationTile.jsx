import React from 'react';
import Block from '../Generic/Block';
import DatePicker from "../Generic/DatePicker";
import TextInput from '../Generic/TextInput';
import Button from '../Generic/Button';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import CookieHelper from '../../Helpers/CookieHelper';
import QueryString from '../../Data/QueryString';
import moment from 'moment';
import MaskedInput from 'react-text-mask';

class QuickProductRegistrationTile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isInitialized: false,
            formValues: {
                serialNumber: "",
                installationDate: new Date()
            }
        };
        this.serialInput = React.createRef();
        this._mask = [/[0-9]/, /[0-9]/, ' ',
        /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, ' ',
        /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/];
    }

    componentDidMount() {
        this.setState({ isInitialized: true });
    }

    setFormValues = (callbackKey, value) => {
        this.setState(function (prevState) {
            prevState.formValues[callbackKey] = value;
            return { formValues: prevState.formValues};
        });
    }

    redirectToRegistration = () => {
        let _qs = QueryString.setValue("serialNumber", this.state.formValues.serialNumber);
        _qs = `${_qs}${QueryString.setValue("installationDate", moment(this.state.formValues.installationDate).format("YYYY-DD-MMMM"))}`;
        _qs= _qs.replace(/(?!^)\?/g, '&');
        let _id = "installertabber"; //The tabber target id of the product registration
        let _value = 1;
        CookieHelper.setCookie(`${_id}${(_value)}`, _id);
        CookieHelper.setCookie(true, "fromSelection");
        let _target = `${_id}${_value}`;
        location.href = `${this.props.data.links.ProductRegistrationPage}${_qs}#${_target}`;
    }

    deleteSpaceMask = (e) => {
        let _key = e.key.toLowerCase();
        if (_key === 'backspace' || _key === 'delete'){
            let _val = e.target.value.slice(0, -1);
            e.target.value = _val;
        }
    }

    render() {
        return (
            <Block
                containerClass="form register-products rblock blue"
                textClass="block--text"
                text={this.props.data.item.Title}
                iconClass="block--icon show-for-small-only"
                iconSrc={!this.props.isSitecore ? this.props.data.item.Image : (this.state.isInitialized ? SitecoreHelper.getImage(this.props.data.item.Image) : "")}
            >
                <div className="hide-for-small">
                    <div className="form">
                        <MaskedInput
                            autoFocus="true"
                            type="text"
                            id="serialNumber"
                            placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.data.item.SerialNumberInputPlaceholder)}
                            mask={this._mask}
                            guide={false}
                            ref={this.serialInput}
                            onChange={event => {this.setFormValues("serialNumber", event.target.value);}}
                            onKeyDown={event => this.deleteSpaceMask(event)}
                        />
                        <DatePicker
                            isEditing={this.props.isEditing}
                            title={this.props.data.item.DatePickerTitle}
                            locale={this.props.data.item.DatePickerLocale}
                            defaultSelectedDate={this.state.formValues.installationDate}
                            dateFormat={this.props.data.item.DatePickerFormat}
                            todayLabel={this.props.data.item.DatePickerTodayLabel}
                            minDate={this.props.data.item.DatePickerMinDays}
                            maxDate={this.props.data.item.DatePickerMaxDays}
                            callback={this.setFormValues}
                            callbackKey="installationDate"
                        />
                    </div>
                    <Button 
                        text={this.props.data.item.ButtonText}
                        wrapperClassName=""
                        className="button secondary"
                        callback={this.redirectToRegistration}
                    />
                </div>
            </Block>
        );
    }
}

module.exports = QuickProductRegistrationTile;