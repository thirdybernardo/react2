import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import QuickProductRegistrationTile from '../QuickProductRegistrationTile';
import quickProductRegistrationTilerData from '../../../../../build/Data/json/QuickProductRegistrationTileFields.json';
import renderer from 'react-test-renderer';

const quickProductRegistrationTile = shallow(
    <QuickProductRegistrationTile
            data={quickProductRegistrationTilerData} />);

// test('QuickProductRegistrationTile matches snapshot', () => {
//     var _formValues = quickProductRegistrationTile.state().formValues
//     _formValues.installationDate = "19 June 2019"
//     quickProductRegistrationTile.setState({ formValues: _formValues})
//     const tree = renderer.create(quickProductRegistrationTile).toJSON()
//     expect(tree).toMatchSnapshot()
// })

test('isInitialized state is true', () => {
    expect(quickProductRegistrationTile.state().isInitialized).toEqual(true);
});

test('setFormValues function properly sets formValues state', () => {
    const instance = quickProductRegistrationTile.instance();
    const testSerial = '000000000001';
    const testDate = "18 June 2019";
    instance.setFormValues('serialNumber', testSerial);
    instance.setFormValues('installationDate', testDate);
    expect(quickProductRegistrationTile.state().formValues.serialNumber).toEqual(testSerial);
    expect(quickProductRegistrationTile.state().formValues.installationDate).toEqual(testDate);
});