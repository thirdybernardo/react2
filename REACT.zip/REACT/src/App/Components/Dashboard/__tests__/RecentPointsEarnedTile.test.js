import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import RecentPointsEarnedTile from '../RecentPointsEarnedTile';
import recentPointsEarnedTileData from '../../../../../build/Data/json/RecentPointsEarnedTileFields.json';
import renderer from 'react-test-renderer';

const recentPointsEarnedTile = shallow(
    <RecentPointsEarnedTile
            data={recentPointsEarnedTileData} />);

test('RecentPointsEarnedTile matches snapshot', () => {
    recentPointsEarnedTile.setState({ dateToday: "01 January 2019"});
    const tree = renderer.create(recentPointsEarnedTile).toJSON();
    expect(tree).toMatchSnapshot();
});

