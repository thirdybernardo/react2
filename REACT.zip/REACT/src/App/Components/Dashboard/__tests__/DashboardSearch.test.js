import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import DashboardSearch from '../DashboardSearch';
import dashboardSearchData from '../../../../../build/Data/json/dashboardSearchFields.json';
import renderer from 'react-test-renderer';

global.console = {
    warn: jest.fn(),
    log: jest.fn()
};

const dashboardSearch = shallow(
    <DashboardSearch
            data={dashboardSearchData} />);

test('DashboardSearch matches snapshot', () => {
    const tree = renderer.create(
        <DashboardSearch
            data={dashboardSearchData} />).toJSON();
    expect(tree).toMatchSnapshot();
});

test('Search callback is executed', () => {
    const testQuery = 'test query';
    dashboardSearch.instance().handleSearch({target: {value: testQuery}});
    expect(global.console.log).toHaveBeenCalledWith(`Search Keyword: ${testQuery}`);
});