import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import EmailCampaignBanner from '../EmailCampaignBanner';
import emailCampaignBannerData from '../../../../../build/Data/json/EmailCampaignBannerFields.json';
import renderer from 'react-test-renderer';

const emailCampaignBanner = shallow(
    <EmailCampaignBanner
            data={emailCampaignBannerData} />);

test('EmailCampaignBanner matches snapshot', () => {
    const tree = renderer.create(
        <EmailCampaignBanner
            data={emailCampaignBannerData} />).toJSON();
    expect(tree).toMatchSnapshot();
});

test('Initial isVisible state is false', () => {
    // Expect visible banner because requried cookie is empty or null
    expect(emailCampaignBanner.state().isVisible).toEqual(true);
});