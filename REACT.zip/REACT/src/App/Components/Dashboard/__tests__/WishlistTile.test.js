import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import WishlistTile from '../WishlistTile';
import wishlistTileData from '../../../../../build/Data/json/WishlistTileFields.json';
import renderer from 'react-test-renderer';

const wishlistTileTile = shallow(
    <WishlistTile
            data={wishlistTileData} />);

test('WishlistTile matches snapshot', () => {
    const tree = renderer.create(
        <WishlistTile
            data={wishlistTileData} />).toJSON();
    expect(tree).toMatchSnapshot(); 
});