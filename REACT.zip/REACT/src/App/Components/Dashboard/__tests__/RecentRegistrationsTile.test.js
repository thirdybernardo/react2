import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import RecentRegistrationsTile from '../RecentRegistrationsTile';
import recentRegistrationsTileData from '../../../../../build/Data/json/RecentRegistrationsTileFields.json';
import renderer from 'react-test-renderer';

const recentRegistrationsTileTile = shallow(
    <RecentRegistrationsTile
            data={recentRegistrationsTileData} />);

test('RecentRegistrationsTile matches snapshot', () => {
    const tree = renderer.create(
        <RecentRegistrationsTile
            data={recentRegistrationsTileData} />).toJSON();
    expect(tree).toMatchSnapshot(); 
});