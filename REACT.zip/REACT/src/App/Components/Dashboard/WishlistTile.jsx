import React from 'react';
import Block from '../Generic/Block';
import Data from '../../Data/Data';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import QueryString from '../../Data/QueryString';
import SearchHelper from '../../Helpers/SearchHelper';

class WishlistTile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            productRegistrations: []
        };
        this.cookieName = "ProductWishlist";
    }

    componentDidMount() {
        if (!this.props.isSitecore) {
            Data.getData("MockInstallerRegisteredProducts", (data) => {
                this.setState({ productRegistrations: data.Registered });
            });
        }
        else {
            let _installerId = QueryString.getValue("installerid");
            let _query = "";
            let _startD = undefined;
            let _endD = undefined;
            SearchHelper.getRegistrations(_installerId, _query, _startD, _endD, data => {
                if (data.Results) {
                    let _products = data.Results.sort((a, b) => {
                        return new Date(b.InstallationDate) - new Date(a.InstallationDate);
                    });
                    this.setState({ productRegistrations: _products });
                }
            }, true);
        }
    }

    renderTile = () => {
        let _size = this.props.data.item.MaxListSize;
        let _return = [];
        if (parseInt(_size) && this.state.productRegistrations.length > 0){
            for(var i = 0; i < _size; i++){
                _return.push(
                    <div className="promo-ds dashboard--promo-new-product" key={i+1}>
                        <div className="dashboard--promo-new-product__title" dangerouslySetInnerHTML={{ __html: this.props.data.item.Title }} />
                        <div className="dashboard--promo-new-product__img">
                            <img src={this.state.productRegistrations[i].imageSource ? this.state.productRegistrations[i].imageSource : undefined} />
                        </div>
                        <div className="dashboard--promo-new-product__name">
                            {this.state.productRegistrations[i].Product.Name}
                        </div>
                        <div className="dashboard--promo-new-product__points">
                            <span className="currency-icon">
                                <img src={!this.props.isSitecore ? this.props.data.item.CurrencyIcon : SitecoreHelper.getImage(this.props.data.item.CurrencyIcon)} />
                            </span>
                            &nbsp;
                            {this.state.productRegistrations[i].Points}
                        </div>
                    </div>
                );
            }
        }
        return _return;
    }

    render() {
        return (
            <Block
                containerclassName="promo-ds dashboard--promo-new-product"
            >
                {this.props.isEditing ? <p>Wishlist Tile Component. Please go to live view.</p>: ""}
                {this.renderTile()}
            </Block>
        );
    }

}

module.exports = WishlistTile;