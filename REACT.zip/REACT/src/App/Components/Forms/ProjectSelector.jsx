﻿import React, { Component } from 'react';
import Data from "../../Data/Data";
import ProxyData from "../../Data/ProxyData";
import SH from "../../Helpers/SitecoreHelper";

class ProjectSelector extends Component {
    constructor(props) {
        super(props);
        this.refProjectInput = React.createRef();
        this.state = {
            projects: [],
            validationClass: ""
        };
    }

    //Get projects from a source, mock or database
    componentDidMount() {
        if(!this.props.isEditing){
            if (!this.props.isSitecore) {
                Data.getData("MockProjects", data => {
                    this.setState({ projects: data.Projects });
                    
                });
            }
            this.handleBulkEntry();
        }
    }

    handleBulkEntry = () =>{
        let _entry = this.props.singleEntry;
        if(_entry && this.props.isBulk){
            if(_entry.ProjectId){
                this.refProjectInput.current.value = _entry.ProjectId;
                this.handleProjectInput(null, _entry.ProjectId);
            }
        }
    }

    handleKeyPress = (event) => {
        if(event.key === " "){             
            event.preventDefault();  
        }
    }

    searchProject = (_input) => {
        return new Promise((resolve, reject) => { 
            if (!this.props.isSitecore) {
                let _projects = Object.assign(this.state.projects);
                let _match = _projects.find((obj) => {
                    return (String(obj.ProjectId).toUpperCase() == String(_input.toUpperCase()));
                });
                resolve(_match);
            }
            else {
                let route = 'api/projects?project=' + _input;
                ProxyData.getData(route, (response) => {
                    if(response.status)
                        reject(response.statusText);
                    resolve(response.Result);
                }, true);
            }
        });
    }

    handleProjectInput = (e, tempE) => {
        // Remove spaces from input value and look for a value inside this.state.projects. Then, update the message below the toggle        
        let _msg = this.props.data.item.ProjectErrorMessage;
        let _input = null;
        if(e)
            _input = e.target.value;
        else{
            _input = tempE;
        }

        _input = _input.replace(/\s/g, '');         
            if(_input !== ""){  
                this.searchProject(_input)
                    .then((_match) => {
                        if (!_match) {
                            this.setState({ validationClass: "error" });
                            this.props.setValidationState(false, "project");
                        }
                        else {
                            _msg = _match.ProjectName + ", " + _match.ProjectHandler;
                            this.setState({ validationClass: "success" });
                            this.props.setValidationState(true, "project");
                        }
                        this.setFormValues(_input);
                        this.props.ProjectInputMessage(_msg);
                    })
                    .catch((result) => {
                        this.props.setValidationState(false, "project");
                        this.setFormValues(_input);
                        this.props.ProjectInputMessage(_msg);
                    });
            }
            else{                
                this.props.ProjectInputMessage("");
                this.props.setValidationState(true, "project");
                this.setState({validationClass:""});
                this.setFormValues(_input);
            }
    }

    setFormValues = (projectId) => {
        //set object values to be merged in form field values
        var _obj = {
            ProjectId: projectId,
            Project: projectId
        };
        this.props.setFormValues(_obj);
        
    }

    render() {
        return (
            <React.Fragment>
                <div className="validation-wrapper">
                    <div className="input-btn-wrapper">
                        <label htmlFor="" className={"input-wrapper " + this.state.validationClass}>
                            <input
                                ref={this.refProjectInput}
                                onKeyPress={event => this.handleKeyPress(event)}
                                onChange={event => this.handleProjectInput(event)}
                                className={"has-default " + this.state.validationClass}
                                type="text"
                                maxLength="10"
                                placeholder={SH.getPlaceholderText(this.props.isEditing, this.props.data.item.ProjectInputPlaceholder)}
                                id="project-selector"
                                autoFocus />
                        </label>
                        <a href="" className="button arrow-right" id="project_select">
                            <span
                                dangerouslySetInnerHTML={{
                                    __html: this.props.data.item.ProjectSelectorButton
                                }}
                            />
                        </a>
                    </div>
                </div>
            </React.Fragment>
        );
    }

}
export default ProjectSelector;
