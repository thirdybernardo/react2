import React, { Component } from 'react';
import BulkOverviewFilter from './BulkOverviewFilter';
import BulkOverViewTable from './BulkOverviewTable';
import BulkActionButton from './BulkActionButton';
import QueryString from "../../Data/QueryString";
import SitecoreHelper from "../../Helpers/SitecoreHelper";
import ProductAPI from "../../API/ProductRegistration";

class BulkOverview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            uploaded: [],
            refinedUploads: [],
            selectedForDeletion: [],
            initialize: false,
            uploadBasicInfo: {},
            fileName: "",
            paginationSlice: {
                Text: "1",
                Value: 1
            },
            searchValue: null,
            bulkTotalPoints: "0"
        };
    }

    componentDidMount() {
        this.setState({
            uploaded: this.props.uploaded,
            refinedUploads: this.props.uploaded,
            uploadBasicInfo: this.props.uploadBasicInfo,
            fileName: this.props.fileName
        });
    }

    componentDidUpdate(prevState){
        if(prevState.refinedUploads !== this.state.refinedUploads && this.state.refinedUploads.length === 0
            || prevState.uploaded !== this.state.uploaded && this.state.uploaded.length === 0){
            this.props.returnToBulkUpload();
        }
    }

    updatePaginationSlice = (val) => {
        this.setState({ paginationSlice: val });
    }

    setInitialize = (value, callback) => {
        this.setState({
            initialize: value
        }, () => {
            if (callback)
                callback();
        });
    }

    removeEntry = (_id, callback) => {
        if (confirm(this.props.data.item.OverviewDeleteConfirmation)) {
            let _refineUpload = [...this.state.refinedUploads].filter(key => {
                return key.Id !== _id;
            });

            let _uploaded = [...this.state.uploaded].filter(key => {
                return key.Id !== _id;
            });

            this.setState({
                refinedUploads: _refineUpload,
                uploaded: _uploaded
            }, () => {
                this.props.setEntryAnalysation(true);
                if (callback)
                    callback();
            });
        }
    }

    saveAction = (obj, callback) => {
        let _refineUpload = [...this.state.refinedUploads].map(key => {
            return key.Id === obj.Id ? obj : key;
        });

        this.setState({
            refinedUploads: _refineUpload,
            uploaded: _refineUpload
        }, () => {
            this.props.setEntryAnalysation(true);
            if (callback)
                callback();
        });
    }

    deleteSelected = () => {
        if (confirm(this.props.data.item.OverviewDeleteConfirmation)) {
            this.setState({
                refinedUploads: this.state.refinedUploads.filter(item => !this.state.selectedForDeletion.includes(item.Id)),
                uploaded: this.state.uploaded.filter(item => !this.state.selectedForDeletion.includes(item.Id)),
                selectedForDeletion: []
            }, () => {
                this.setInitialize(false);
            });
        }
    }

    checkboxSelect = (event, id) => {
        if (event.target.checked) {
            this.setState({
                selectedForDeletion: [...this.state.selectedForDeletion, id]
            });
        }
        else {
            this.setState({
                selectedForDeletion: this.state.selectedForDeletion.filter(function (_id) {
                    return _id !== id;
                })
            });
        }
    }

    checkboxMultipleSelect = (event, ids) => {
        if (event.target.checked) {
            this.setState({
                selectedForDeletion: ids
            });
        } else {
            this.undoSelection();
        }

    }

    handleSearch = (val, tempQry) => {
        let _return = [...this.state.uploaded];
        let _query = "";
        if (val) {
            _query = val.target.value;
        }
        else {
            _query = tempQry;
        }

        _return = [...this.state.uploaded].filter((val) => {
            return String(val.Firstname).toLowerCase().replace(/\s/g, '').includes(String(_query).toLowerCase().replace(/\s/g, ''))
                || String(val.Lastname).toLowerCase().replace(/\s/g, '').includes(String(_query).toLowerCase().replace(/\s/g, ''))
                || String(`${val.Firstname} ${val.Lastname}`).toLowerCase().includes(String(_query).toLowerCase())
                || String(`${val.Lastname} ${val.Firstname}`).toLowerCase().includes(String(_query).toLowerCase())
                || val.AddressResponse != null && (String(val.AddressResponse.response.docs[0].woonplaatsnaam).toLowerCase().includes(String(_query).toLowerCase())
                    || String(val.AddressResponse.response.docs[0].postcode).toLowerCase().includes(String(_query).toLowerCase())
                    || String(val.AddressResponse.response.docs[0].huisnummer).toLowerCase().includes(String(_query).toLowerCase())
                    || String(val.AddressResponse.response.docs[0].straatnaam).toLowerCase().includes(String(_query).toLowerCase())
                    || String(val.AddressResponse.response.docs[0].gemeentenaam).toLowerCase().includes(String(_query).toLowerCase()))
                || String(val.TelephoneNo).toLowerCase().replace(/\s/g, '').includes(String(_query).toLowerCase().replace(/\s/g, ''))
                || String(val.SerialNumber).toLowerCase().includes(String(_query).toLowerCase())
                || String(val.EmailAddress).toLowerCase().includes(String(_query).toLowerCase())
                || val.InstallationDate.includes(_query)
                || val.Products != null && val.Products.some(x => String(x.ProductName).toLowerCase().includes(String(_query).toLowerCase()));
        });

        this.setState({
            refinedUploads: _return,
            searchValue: _query
        }, () => {
            this.setInitialize(false);
        });
    }

    redirectAfterSubmit = () => {
        let _qs = QueryString.setValue("pointsEarned", this.state.bulkTotalPoints, false);
        let _thankYouUrl = !this.props.isSitecore ? this.props.data.item.ThankYouPage : SitecoreHelper.getLink(this.props.data.item.ThankYouPage);
        let _redirectUrl = "/";
        if (_thankYouUrl != undefined && _thankYouUrl != "")
            _redirectUrl = _thankYouUrl;
        location.href = _redirectUrl + _qs;
    }

    bulkSubmit = () => {
        let _points = 0;
        let snLimit = this.props.productSNMonthLimit;
        let _installerId = QueryString.getValue("installerid");
        let _refinedUploads = [...this.state.refinedUploads].map((val) => {
            if(!val.isProject && val.ProjectId == ""){
                _points += val.Points;
            }
            val["InstallerId"] = _installerId;
            return val;
        });
        ProductAPI.SubmitBulkRegistration(snLimit,_refinedUploads, (response) => {
            if (response.status === 200) {
                this.setState({ bulkTotalPoints: _points }, () => {
                    this.redirectAfterSubmit();
                });
            }
            else
                alert("Something went wrong on our end when we tried to register your products. Please contact us for more information.");
                // Temporary alert because no design is provided for form submission errors
        });
    }

    undoSelection = () => {
        this.setState({
            selectedForDeletion: []
        });
    }

    render() {
        return (
            <React.Fragment>
                <BulkOverviewFilter
                    data={this.props.data}
                    handleSearch={this.handleSearch}
                    uploadBasicInfo={this.state.uploadBasicInfo}
                    fileName={this.state.fileName}
                    updatePaginationSlice={this.updatePaginationSlice}
                    isEditing={this.props.isEditing}
                />
                <BulkOverViewTable
                    data={this.props.data}
                    uploaded={this.state.refinedUploads}
                    checkboxSelect={this.checkboxSelect}
                    checkboxMultipleSelect={this.checkboxMultipleSelect}
                    deleteSelected={this.deleteSelected}
                    selectedForDeletion={this.state.selectedForDeletion}
                    setBulkErrorValidation={this.props.setBulkErrorValidation}
                    setEntryAnalysation={this.props.setEntryAnalysation}
                    removeEntry={this.removeEntry}
                    saveAction={this.saveAction}
                    isEditing={this.props.isEditing}
                    isSitecore={this.props.isSitecore}
                    initialize={this.state.initialize}
                    setInitialize={this.setInitialize}
                    paginationSlice={this.state.paginationSlice.Value}
                    undoSelection={this.undoSelection}
                    searchValue={this.state.searchValue}
                    handleSearch={this.handleSearch}
                />
                <BulkActionButton
                    data={this.props.data}
                    returnToBulkUpload={this.props.returnToBulkUpload}
                    bulkSubmit={this.bulkSubmit}
                />
            </React.Fragment>
        );
    }
}

export default BulkOverview;