import React, { Component } from 'react';

class BulkAlert extends Component {
    constructor(props) {
        super(props);
        this.state = {
            alertMessage: "",
            initialize: false
        };
    }
    componentDidUpdate(prevProps) {
        if (Object.values(this.props.data.item).length > 0 && this.props.entryAnalysationDone) {
            this.props.setEntryAnalysation(false, () => {
                let _alertMsg = this.getNumberOfError();
                this.setState({alertMessage: _alertMsg});
                this.setState({initialize: true});
            });            
        }
    }

    getNumberOfError = () => {
        let _msg = this.props.data.item.FileAlertImportErrorMessage;
        if(!this.props.isEditing && _msg != undefined)
            return _msg.replace("$(variable1)",this.props.bulkErrorValidation.numberOfError);

        return _msg;
    }

    render = () => {
        return (
            <React.Fragment>                
                {this.props.bulkErrorValidation.hasError && 
                    <React.Fragment>
                        <div className="tool-tip-info">
                            <a href="javascript:void(0)">
                                <img src={this.props.tooltipIcon} alt="" />
                            </a>
                        </div>
                        <div className="contextual-title-bold">
                            <span dangerouslySetInnerHTML={{__html: this.props.data.item.FileAlertImportTitle}}></span>
                        </div>
                        <div className="product-reg-message-text">
                            <p>{this.state.alertMessage}</p>
                        </div>
                    </React.Fragment>
                }
             </React.Fragment>
        );
    }
}

export default BulkAlert;