import React, { Component } from 'react';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import moment from 'moment';
import { Calendar, DateRange } from 'react-date-range';
import { default as DutchLocale } from 'react-date-range/dist/locale/nl';
import { default as EnUSLocale } from 'react-date-range/dist/locale/en-US';


class DatePicker extends Component {
    constructor(props) {
        super(props);
        this.fallbackDateFormat = "dddd, DD MMMM";
        this.properDateFormat = "DD MMMM YYYY";
        this.fallbackLocale = "nl";
        this.fallbackTodayLabel = "(Vandaag)";

        this.state = {
            selectedDate: this.getDate(new Date()),
            properDate: new Date(),
            displayClassName: "hide",
            activeClassName: "",
            todayLabel: this.fallbackTodayLabel,
            isDateSelecting: false,
            isOnLoad:true,
            isInitialized: false
        };

        this.maxDate = new Date();
        this.minDate = new Date();
        this.setFormValues();
    }
    

    componentDidUpdate(prevProps, prevState) {
        if (this.state.selectedDate !== prevState.selectedDate) {
            this.setFormValues();
        }

        if (!this.props.isSitecore){
            if (prevProps.data.item !== this.props.data.item) {
                this.setDateLimit();
            }
        }
        else {
            //Code for getting data in Sitecore integration
            if(this.state.isOnLoad && this.props.data.item.DatePickerMaxDays != undefined && this.props.data.item.DatePickerMinDays != undefined){
                this.setDateLimit();
                this.setState({isOnLoad: false});
            }
        }
    }

    componentDidMount = () => {
        this.handleBulkEntry();
    }

    handleBulkEntry = () =>{
        if(this.props.singleEntry && this.props.isBulk){
            this.handleSelect(new Date(this.props.singleEntry.InstallationDate));
            this.setDateLimit();
        }
    }

    setDateLimit = () => {
        let _currentDate = new Date();

        this.maxDate = new Date(new Date().setDate(_currentDate.getDate() + parseInt(this.props.data.item.DatePickerMaxDays)));
        this.minDate = new Date(new Date().setDate(_currentDate.getDate() - parseInt(this.props.data.item.DatePickerMinDays)));
    }

    getCalenderLocale = () => {
        switch (this.props.data.item.DatePickerLocale) {
            case "nl": {
                return DutchLocale;
            }
            case "enUS": {
                return EnUSLocale;
            }
            default: {
                return DutchLocale;
            }
        }
    }

    toggleDatePicker = () => {
        this.setState(prevState => ({
            displayClassName: prevState.displayClassName === "hide" ? "" : "hide",
            activeClassName: prevState.activeClassName === "active" ? "" : "active",
            isDateSelecting: false
        }));
    }

    handleSelect = (date) => {

        this.setState({
            selectedDate: this.getDate(date),
            properDate: date,
            todayLabel: this.getTodayLabel(date)
        });
        if(!this.props.isBulk){
            this.toggleDatePicker();
        }
        
    }

    getDate = (date) => {
        let _locale = this.fallbackLocale;
        let _format = this.fallbackDateFormat;

        if (this.props.data.item.DatePickerLocale)
            _locale = this.props.data.item.DatePickerLocale;
        if (this.props.data.item.DatePickerFormat)
            _format = this.props.data.item.DatePickerFormat;

        let selectedDate = moment(date).locale(_locale).format(_format) + " ";

        return this.toTitleCase(selectedDate);
    }

    getTodayLabel = (date) => {
        let _todayLabel = this.fallbackTodayLabel;

        if (this.props.data.item.DatePickerTodayLabel)
            _todayLabel = this.props.data.item.DatePickerTodayLabel;

        var now = moment().format("MM/DD/YYYY");
        var selected = moment(date).format("MM/DD/YYYY");

        if (now === selected)
            return _todayLabel;
        return "";
    }

    toTitleCase = (string) => {
        return string.replace(/\w\S*/g, function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    }

    setFormValues = () => {
        //set object values to be merged in form field values
        if(this.state.properDate){
            var _obj = {
                InstallationDate: this.state.properDate.toISOString()
            };
            this.props.setFormValues(_obj);
        }
    }

    hideDatePicker = () => {
        if (this.state.activeClassName === "active" && !this.state.isDateSelecting) {
            this.setState({
                displayClassName: "hide",
                activeClassName: ""
            });
        }
    }

    preventCalendarHiding = () => {
        if (!this.state.isDateSelecting) {
            this.setState({ isDateSelecting: true });
        }
    }

    render() {
        return (
            <div className="form-group">
                <div className="form-datepicker" onTouchCancelCapture={e => this.hideDatePicker()} onMouseLeave={e => this.hideDatePicker()}>
                    <div className="row section-title">
                        <div className="columns medium-12">
                            <label>
                            <span dangerouslySetInnerHTML={{ __html: this.props.data.item.DatePickerTitle }}>
                                </span>
                            </label>
                        </div>
                    </div>
                    <div className="row section-field">
                        <div className="columns small-12 large-7 medium-7">
                            <label className={"datepicker-wrapper " + this.state.activeClassName} onClick={event => this.toggleDatePicker()}>
                                <span>{this.state.selectedDate}</span>
                                <span className="datepicker-today">{this.state.todayLabel}</span>
                            </label>
                        </div>
                    </div>
                    <div onClick={e => this.preventCalendarHiding()} className={"section-datepicker " + this.state.displayClassName}>
                        <Calendar
                            onChange={event => this.handleSelect(event)}
                            locale={this.getCalenderLocale()}
                            showMonthArrow={false}
                            date={new Date(this.state.properDate)}
                            maxDate={this.maxDate}
                            minDate={this.minDate}
                        />
                    </div>
                </div>
            </div>
        );
    }
}

export default DatePicker;