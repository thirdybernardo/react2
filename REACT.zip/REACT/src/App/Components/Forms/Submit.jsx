import React, { Component } from 'react';
import Button from '../Generic/Button';

class Submit extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }


    render() {
        return (
            <div className="form-group service-buttons">
                {this.props.children}
                <Button
                    className = {"button submit green " + this.props.buttonClass}
                    text={this.props.data.item.SubmitButton}
                    callback ={this.props.action}
                    noWrapper = {true}
                />
                <Button
                    className = {"button submit-mobile " + this.props.buttonClass}
                    text={this.props.data.item.SubmitButtonMobile}
                    callback ={this.props.action}
                    noWrapper = {true}
                />
            </div>
        );
    }
}

export default Submit;