﻿import React, { Component } from 'react';
import { isFunction } from 'util';
import ProjectSelector from '../Generic/Forms/ProjectSelector';
import UIDGenerator from "../../Helpers/UIDGenerator";

class ToggleSwitch extends Component {
    constructor(props) {
        super(props);
        this._SwitchYesLabel = "Ja";
        this._SwitchNoLabel = "Nee";
        this._CheckedState = false;
        this._SwitchId = UIDGenerator.Generate();
        this.refCheckBox = React.createRef();
        this._toggleSwitchBtn = false;

        if (this.props.data.item.SwitchYesLabel) {
            this._SwitchYesLabel = this.props.data.item.SwitchYesLabel;
        }
        if (this.props.data.item.SwitchNoLabel) {
            this._SwitchNoLabel = this.props.data.item.SwitchNoLabel;
        }
        if (this.props.CheckedState) {
            this._CheckedState = this.props.CheckedState;
        }
        if (this.props.toggleSwitchBtn) {
            this._toggleSwitchBtn = this.props.toggleSwitchBtn;
        }

        this.state = {
            isInitialized: false,
            SwitchLabel: this._CheckedState ? this._SwitchYesLabel : this._SwitchNoLabel,
            CheckedState: this._CheckedState,
            projectInputMessage: ""
        };
        this.setFormValues();
    }

    componentDidMount = () => {
        this.handleBulkEntry();
    }

    componentDidUpdate(prevProps) {
        if (!this.state.isInitialized && Object.keys(this.props.data.item).length > 0 && this.refCheckBox.current) {
            this.setState({ isInitialized: true }, () => {
                this.initializeComponent();
            });
        }
        if (prevProps.data.item !== this.props.data.item) {
            this.refCheckBox.current.checked = this._CheckedState;
        }
        if (prevProps.enableToggle !== this.props.enableToggle) {
            if (!this.props.enableToggle) {
                this.setState({
                    CheckedState: false,
                    SwitchLabel: this._SwitchNoLabel
                });
                if (this.refCheckBox.current.checked)
                    this.projectInputMessage(this.props.data.item.ProjectAutoClearMessage);
                this.refCheckBox.current.checked = false;
                this.refCheckBox.current.disabled = true;
            }
            else {
                this.refCheckBox.current.disabled = false;
                this.projectInputMessage("");
            }
        }
    }

    initializeComponent = () => {
        this.refCheckBox.current.disabled = true;
        this.projectInputMessage(this.props.data.item.ProjectInitialMessage);
    }

    handleBulkEntry = () =>{
        let _entry = this.props.singleEntry;
        if(_entry && this.props.isBulk && _entry.IsProject){
            this.refCheckBox.current.checked = _entry.IsProject;
            this.handleChange(_entry.IsProject);
        }
    }

    handleChange = (event) => {
        this.setState({
            CheckedState: event,
            SwitchLabel: event ? this._SwitchYesLabel : this._SwitchNoLabel,
            projectInputMessage: ""
        });
        if (!event)
            this.props.setValidationState(true, "project");

        this.setFormValues(event);
        this.executeFunc(event);
    }

    executeFunc = (checked_state) => {
        var func = this.props.fnName;
        if (func) {
            if (typeof func === 'function') { //If is a function passed from Parent
                func(checked_state);
            }
            else
                this[func](checked_state); //Else call a function from within the component
        }
    }


    projectSelectorPartial = () => {
        let _return = null;
        let _installerProjects = [];
        let _validInstallerProjects = []
        if (this.props.params && Array.isArray(this.props.params)) {
            _installerProjects = this.props.params[0];
            _validInstallerProjects = this.props.params[1];
        }

        if (this.state.CheckedState) {
            return (
                <ProjectSelector data={this.props.data} 
                isBulk={this.props.isBulk} 
                singleEntry={this.props.singleEntry} 
                ProjectInputMessage={this.projectInputMessage} 
                setFormValues={this.props.setFormValues} 
                isSitecore={this.props.isSitecore} 
                setValidationState={this.props.setValidationState}
                isEditing={this.props.isEditing}
                Projects={_installerProjects}
                ValidProjects={_validInstallerProjects}
                ZipCode={this.props.params && Array.isArray(this.props.params) ? this.props.params[2] : undefined}
                />
                );
                
        }

        return _return;
    }

    projectInputMessage = (value, callback) => {
        this.setState({ projectInputMessage: value }, () => {
            if (callback)
                callback()
        });
    }

    renderInputMessage = () => {
        let _return = null;
        let _inputMessage = this.state.projectInputMessage;
        let _class = _inputMessage !== this.props.data.item.ProjectInitialMessage ? "has-error" : "has-success" ;
        if (_inputMessage != "") {
            _return =
                <div className="section-field">
                    <div className="columns medium-12">
                        <span className={"project input-validation " + _class} dangerouslySetInnerHTML={{ __html: this.state.projectInputMessage}}></span>
                    </div>
                </div>;
        }
        return _return;
    }


    setFormValues = (checked_state) => {
        //set object values to be merged in form field values
        var _obj = {
            IsProject: checked_state
        };
        if (this.props.setFormValues) {
            this.props.setFormValues(_obj);
        }
    }

    render() {
        return (
            <React.Fragment>
                <div className="form-group">
                    <div className="row section-field project-input">
                        <div className={this._toggleSwitchBtn ? "switch-wrapper w-btn" : "switch-wrapper"}>
                            <label dangerouslySetInnerHTML={{ __html: this.props.data.item.ProjectToggleTitle }}></label>
                            <div className="switch-wrapper">
                                <input
                                    ref={this.refCheckBox}
                                    className="switch"
                                    type="checkbox"
                                    id={this._SwitchId}
                                    onChange={event => this.handleChange(event.target.checked)}
                                />
                                <label className="project-label" htmlFor={this._SwitchId} name={this._SwitchId} dangerouslySetInnerHTML={{ __html: this.state.SwitchLabel }}></label>
                                <a href={this.props.data.item.ProjectToggleInfoUrl} dangerouslySetInnerHTML={{ __html: this.props.data.item.ProjectToggleInfo }} className="switch-link"></a>
                                {this.projectSelectorPartial()}
                            </div>
                            {this.renderInputMessage()}
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default ToggleSwitch;