import React, { Component } from "react";
import AddressHelper from "../../Helpers/AddressHelper";
import SitecoreHelper from "../../Helpers/SitecoreHelper";
import { stringify } from "querystring";

class RegistrationAddress extends Component {
    constructor(props) {
        super(props);

        this.refPostcode = React.createRef();
        this.refHouseNumber = React.createRef();

        
        this.state = {
            result: null,
            validationClass: "",
            className: "",
        };
    }

    componentDidMount = () => {
        this.handleBulkEntry();
    }

    handleBulkEntry = () =>{
        if(this.props.singleEntry && this.props.isBulk){
            this.handleAPITrigger(this.props.singleEntry.PostalCode, this.props.singleEntry.HouseNumber);
            this.refPostcode.current.value = this.props.singleEntry.PostalCode;
            this.refHouseNumber.current.value = this.props.singleEntry.HouseNumber;
        }
    }

    handleKeyPress = (post_code, house_number, event, reference) => {
        if (event.key === " ") {
            if (reference == this.refPostcode && post_code.split(" ").length > 1)
                event.preventDefault();
            else if (reference == this.refHouseNumber && house_number.split(" ").length > 0)
                event.preventDefault();
        }
    }


    handleAPITrigger = (post_code, house_number) => {
        this.setState({
            result: null,
            validationClass: "",
            className: ""
        });

        AddressHelper.getAddressInfo(post_code, house_number, data => {
            var _result = null;
            let _validationClass = " has-error";
            let _className = " error";
            this.props.setValidationState(false, "address");

            if(!data || !data.response || data.response.numFound === 0)
                _result = this.props.data.item.NotFoundValidationMessage;
            else if (data.response.numFound > 0) {
                _result = data.response.docs[0].weergavenaam;
                _validationClass = " has-success";
                _className = " success";
                this.props.setValidationState(true, "address");
            }
            else
                _result = this.props.data.item.NotFoundValidationMessage;

            this.setState({
                result: _result,
                validationClass: _validationClass,
                className: _className
            }, () => {
                this.setFormValues(post_code, house_number, data); 
            });
        });
    };



    setFormValues = (post_code, house_number, data) => {
        //set object values to be merged in form field values
        var _obj = {
            PostalCode: post_code,
            HouseNumber: house_number,
            AddressResponse : data,
            TotalAddressFound: data === null ? null : data.response.numFound
        };
        this.props.setFormValues(_obj);
    }

    renderAddressResult = () => {
        let _return = null;
        if (this.state.result) {
            _return = (
                <div className="row section-field">
                    <div className="columns medium-12">
                        <span className={"input-validation" + this.state.validationClass}>{this.state.result}</span>
                    </div>
                </div>
            );
        }
        return _return;
    }

    render() {
        return (
            <div className="form-group register-address">
                <div className="row section-title">
                    <div className="columns medium-12">
                        <label
                            dangerouslySetInnerHTML={{
                                __html: this.props.data.item.AddressTitle
                            }}
                        />
                    </div>
                </div>
                <div className="row section-field">
                    <div className="columns medium-8 small-11">
                        <label className={"input-wrapper first-label" + this.state.className}>
                            <input
                                onKeyPress={event => this.handleKeyPress(event.target.value, this.refHouseNumber.current.value, event, this.refPostcode)}
                                onChange={event => this.handleAPITrigger(event.target.value, this.refHouseNumber.current.value)}
                                className={"has-default" + this.state.className}
                                type="text"
                                id="post-code"
                                maxLength="7"
                                placeholder={SitecoreHelper.getPlaceholderText(
                                    this.props.isEditing,
                                    this.props.data.item.PostcodePlaceholder
                                )}
                                ref={this.refPostcode}
                            />
                        </label>
                        <label className={"input-wrapper second-label" + this.state.className}>
                            <input
                                onKeyPress={event => this.handleKeyPress(this.refPostcode.current.value, event.target.value, event, this.refHouseNumber)}
                                onChange={event => this.handleAPITrigger(this.refPostcode.current.value, event.target.value)}
                                className={"has-default" + this.state.className}
                                type="text"
                                id="house-number"
                                maxLength="10"
                                placeholder={SitecoreHelper.getPlaceholderText(
                                    this.props.isEditing,
                                    this.props.data.item.HousenumberPlaceholder
                                )}
                                ref={this.refHouseNumber}
                            />
                        </label>
                    </div>
                </div>
                {this.renderAddressResult()}
            </div>
        );
    }
}

export default RegistrationAddress;