import React, { Component } from "react";
import SitecoreHelper from "../../Helpers/SitecoreHelper";
import Data from "../../Data/Data";
import ProxyData from "../../Data/ProxyData";
import CustomDroplist from "../Generic/CustomDroplist";
import ProductCategoryHelper from "../../Helpers/ProductCategoryHelper";
import MaskedInput from 'react-text-mask';

 



class RegistrationProductSearch extends Component {
    constructor(props) {
        super(props);

        this.refProductSearchInput = React.createRef();
        this.refAddProductLink = React.createRef();
        this.refAddProductLink2 = React.createRef();
        this.refSerialReEntry = React.createRef();
        this.refProdRegMsg = React.createRef();

        //Masks the serial input as: 00 000 0000 0000
        this._mask = [/[0-9]/, /[0-9]/, ' ',
            /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, ' ',
            /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/];

        this.state = {
            //Array of object where we specify if Ids are Valid or not, to use in the creation of Span
            productsInputs: [],
            //Array of values to use in the Result container
            productList: [],
            //category list
            productCategories:[],
            validationMessage: "",
            modalClass: "modal",
            errModalClass: "",
            hasError: false,
            droplistSelected: null,
            isDbExist: false,
            animateWarningClass: "shake",
            hasChange: true,
            addBtnIsDisabled: false,
            isInitialized: false,
          
        };
    }

    //Get products from a source, mock or database
    componentDidMount() {
        if (!this.props.isEditing) {
            if (!this.props.isSitecore) {
                Data.getData("MockProductItems", data => {
                    this.setState({ productList: data.Products });
                    this.handleBulkEntry();
                });
                Data.getData("MockProductCategories", data => {
                    this.setState({ productCategories: data.Results });
                    this.handleBulkEntry();
                });
            } else {
                //call the actual Product database.
                ProxyData.getData('api/products/all', (response) => {
                    this.setState({ productList: response.Results });
                    this.handleBulkEntry();
                }, true);
                ProxyData.getData('api/productcategories', (response) => {
                    this.setState({ productCategories: response.Results });
                }, true);
            }
            
        }
    }

    componentDidUpdate(prevProps, prevState) {
        //init validation messages
        if (!this.props.isEditing) {
            if(this.props.isBulk && this.props.productsResult.length >0 && prevProps.productsResult[0] != this.props.productsResult[0]){
                this.props.AddProductToContainer(this.props.productsResult[0], this.refProductSearchInput);
            }
        }
        if (!this.state.isInitialized && this.refProductSearchInput.current) {
            this.setState({isInitialized: true}, () => {
                if (this.props.defaultInputValue)
                    this.refProductSearchInput.current.inputElement.value = this.props.defaultInputValue;
            });
        }
    }

    handleBulkEntry = () =>{
        let _entry = this.props.singleEntry;
        if(_entry && this.props.isBulk){
            this.renderSNEntries(_entry);
        }
    }

    renderSNEntries = (items) =>{
        if(items){
            items.SerialNumber.forEach((item, i) => {
                this.refProductSearchInput.current.value = item;
                this.refProductSearchInput.current.inputElement.value = item;
                this.handleProductInput(null, this.refProductSearchInput.current.value);
            });
        }
    }
   
    addProductOnEnter = (event) => {
        //Simulates click event on user enter
        if (event.key === 'Enter') {
            if (this.refAddProductLink.current) {
                this.refAddProductLink.current.click();
            }
            if (this.refAddProductLink2.current) {
                this.refAddProductLink2.current.click();
            }
        }
    }

    //Handle the all searched product items in the component
    handleProductInput = (e, tempE) => {
        var snLimit = parseInt(this.props.data.item.ProductSNLength);
        snLimit = isNaN(snLimit) ? 13 : snLimit;

        let _input=null;
        if(e)
            _input = e.target.value;
        else{
            _input = tempE;
        }
        //Clears the result if SN length has changed and if it contains a result already
        if (this.props.productsResult.length > 0) {
            this.props.ClearProductResults();
        }

        this.props.ClearWarnings();

        if (this.state.hasError) {
            this.setState({ hasError: false });
        }
       
        var snInputLength = _input.replace(/ /g, '').length;

        if (snInputLength >= snLimit) {
            //e.target.blur()
            this.setState({addBtnIsDisabled : true});
            this.createProductInputs(_input);
        }
    }

    //create the product input list
    createProductInputs = (event, callback) => {
        let _input = {};
        _input.ProductId = event.replace(/ /g, '');

        this.props.AddProduct(_input, this.state.productList.slice()).then((result) => {
            if (!result) {
                this.setState({
                    hasError: true
                });
            }
        });
    }
    

    handleProductChanged = (e, s, val) => {
        let selectedProduct = this.selectedProductValidator(val.Value);
        this.setState({
            droplistSelected: selectedProduct === undefined ? null : selectedProduct
        });
    }

    selectedProductValidator(id) {
        let product = this.state.productList.find(item => item.UniqueId === id);
        let _categoryExist = false;
        if (product) {
            this.state.productCategories.filter(key =>{
                if(key.Disabled === false && String(key.CategoryName).toLowerCase().replace(/\s/g, '') === String(product.Category).toLowerCase().replace(/\s/g, '')){
                    return _categoryExist = true;
                }
            });

            if (_categoryExist) {
                this.setState({
                    isDbExist: false
                });
                //Make a unique object to be pushed in the addedProducts array
                const returnedTarget = Object.assign({}, product);
                //Re-assign productid
                returnedTarget.ProductId = this.refProductSearchInput.current.inputElement.value.replace(/ /g, '');
                return returnedTarget;
            }
            else {
                //Ask to re-enter serial number
                this.setState({
                    isDbExist: true
                });

                return product;
            }
        }

        return null;

    }
     
    renderSerialReEntry = () => {
        let _return = null;
        if (this.state.isDbExist) {
            _return = (
                <div>
                    <div ref={this.refProdRegMsg} className={`product-reg-message-text ${this.state.animateWarningClass}`}>
                        <p>{this.props.data.item.ProductSerialNumberReEnterMessage} {ProductCategoryHelper.getDefinition(this.state.droplistSelected)}</p>
                    </div>
                    <div className="product-reg--detailes-retype-serial">
                        <label>
                            <p>{this.props.data.item.ProductSerialNumberReEnterTitle}</p>
                            <MaskedInput
                                autoFocus="true"
                                type="text"
                                placeholder={SitecoreHelper.getPlaceholderText(
                                    this.props.isPageEditing,
                                    this.props.data.item.ProductSearchPlaceholder
                                )}
                                mask={this._mask}
                                guide={false}
                                ref={this.refSerialReEntry}
                                onKeyPress={event => this.addProductOnEnter(event)}
                            />
                        </label>
                    </div>
                </div>);
        }

        return _return;
    }

    //set the validation message when the user adds up to 5 products
    setValidationMessage = () => {
        if (this.props.addedProducts.length >= (parseInt(this.props.data.item.ProductLimit) - this.props.productLimitCtr))
            return this.setValidationMessageHTML(this.props.data.item.ProductLimitMessage);
        else if (this.props.isProductLimitReached)
            return this.setValidationMessageHTML(this.props.data.item.ProductLimitMessage);
        else if (this.props.isDuplicate)
            return this.setValidationMessageHTML(this.props.data.item.ProductRegisteredValidationMessage);
        else if (this.props.isRegistered)
            return this.setValidationMessageHTML(this.props.data.item.ProductRegisteredValidationMessage);
        else if (!this.props.isSerialNumberActive)
            return this.setValidationMessageHTML(this.props.data.item.ProductInactiveSerialNumberValidationMessage);
    }

    setValidationMessageHTML = (value) => {
        let _html = "";

        if (value === this.props.data.item.ProductLimitMessage) {
            _html = (
                <div className="product-reg-message-text">
                    <p>{value}</p>
                </div>
            );
        }
        else {
            _html = (
                <div className="row section-block modal">
                    <div className="columns medium-12">
                        <div className="product-reg--message">
                            <i
                                className="close-button"
                                onClick={event => { this.props.ClearWarnings(); }}
                            />
                            <label htmlFor="" className="result-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.SearchResultTitle }}></label>
                            <div className="product-reg-message-text">
                                <p>{value}</p>
                            </div>
                            <a
                                className="text-link"
                                href="javascript:void(0)"
                                onClick={event => { this.props.ClearWarnings(); }}
                            >{this.props.data.item.ProductCloseText}</a>
                        </div>
                    </div>
                </div>
            );
        }

        return _html;
    }

    //Method for generating the Product Results in a container.
    createDivForProductResult = () => {
        let _return = [];

        this.props.productsResult.slice().forEach((item, i) => {
            _return.push(
                <div key={i} className="product-list--result">
                    <i
                        className="close-button"
                        onClick={event => { this.clearResults(); }}
                    />
                    <label htmlFor="" className="result-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.FoundProductTitle }}></label>
                    <div className="product-list--overview">
                        <div className="product-list--img">
                            <img src={item.ProductImage} alt={item.ProductName}/>
                        </div>
                        <div className="product-list--details">
                            <div className="product-list--desc">
                                <p className="product-list--title">{item.ProductName}</p>
                                <a
                                    className="product-list--add"
                                    ref={this.refAddProductLink}
                                    onClick={!this.state.addBtnIsDisabled ? event.preventDefault() : event => this.setState({addBtnIsDisabled : false}, () => {this.props.AddProductToContainer(item, this.refProductSearchInput);})}
                                >
                                    <span>{this.props.data.item.AddProductLabel}</span>
                                </a>
                            </div>
                            <div className="product-list--loyalty-points">
                            <p className="product-list--serial">{this.props.FormatProductId(item.ProductId)}</p>
                                {this.getPoints(item)}
                            </div>
                        </div>
                    </div>
                    {
                        (item.CombiProducts != null && item.CombiProducts.length >= 1) &&
                        this.props.GetCombiProducts(item.CombiProducts, "overview")
                    }
                </div>
            );
        });

        return _return;
    }

    clearResults = () => {
        this.props.ClearResult();
        this.refProductSearchInput.current.inputElement.value = "";
    }


    getPoints = (item) => {
        return (
            <p className={`product-list--points ${this.props.showPoints ? "" : "removed"}`}> +{item.ProductPoints}</p>
        );
    }

    //Filter Product list that are in product results
    filterProductList = (options) => {
        let filters = this.props.productsResult.slice();
        if (filters.length == 1) {
            if (filters[0].ProductId == null) return options;
        }

        for (var key in filters) {
            if (filters[key].ProductId.length > 0) {
                options = options.filter(function (item) {
                    return item.ProductId != filters[key].ProductId;
                });
            }
        }
        return options;
    }

    //create the selection option for dropdown list
    renderProductList = (options) => {
        let _productList = this.filterProductList(options);
        let _options = [];
        let _default = {
            Text: this.props.data.item.ProductListDefault,
            Value: ""
        };


        let _selectedProduct = this.state.droplistSelected === null ? _default : {
            Text: this.state.droplistSelected.ProductName,
            Value: this.state.droplistSelected.UniqueId
        };


        _options.push(_default);
        _productList.forEach((obj, i) => {
            let _obj = {};
            _obj.Text = obj.ProductName;
            _obj.Value = obj.UniqueId;
            _options.push(_obj);
        });
        return (
            <CustomDroplist containerClass="" list={_options} selected={_selectedProduct} action={this.handleProductChanged} identifier="_" />
        );

    }


    //Method for rendering invalid product
    createInvalidMessage = () => {
        return (
            <div className="product-reg--message">
                <i
                    className="close-button"
                    onClick={event => { this.removeModal(); }}
                />
                <label htmlFor="" className="result-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.SearchInProductsTitle }}></label>
                <div className="product-reg-message-text">
                    <p dangerouslySetInnerHTML={{ __html: this.props.data.item.ProductErrorMessage }}></p>
                </div>
                <div className="product-reg--validation">
                    <div className="product-reg--img">
                    <img src={SitecoreHelper.getImage(this.props.data.item.UnknownProductImage)}/>
                    </div>
                    <div className="product-reg--details-box">
                        <div className="product-reg--details-select-product">
                            <div className="product-reg--details">
                                {this.renderProductList(this.state.productList)}
                                <div className="product-reg--add">
                                    <a
                                        ref={this.refAddProductLink2}
                                        onClick={event => this.addSelectedProduct()}>
                                        {this.props.data.item.AddProductLabel}
                                    </a>
                                </div>
                                <p className="product-reg--serial">{this.refProductSearchInput.current.inputElement.value}</p>

                            </div>
                            {this.renderSerialReEntry()}

                        </div>
                    </div>
                </div>
            </div>
        );
    }

    animateWarning = () => {
        this.setState({
            animateWarningClass: ""
        });
        setTimeout(() => {
            this.setState({
                animateWarningClass: "shake"
            });
        }, 100);
    }

    addSelectedProduct = () => {
        if (this.state.droplistSelected === undefined) {
            return false;
        }
        if (this.state.isDbExist && this.state.droplistSelected.ProductId !== this.refSerialReEntry.current.inputElement.value.replace(/ /g, '')) {
            this.refSerialReEntry.current.inputElement.focus();
            this.animateWarning();
            return false;
        }

        this.props.AddProductToContainer(this.state.droplistSelected, this.refProductSearchInput, (result)=> {
            if(result)            
                this.removeModal();
        });
        

    }

    removeModal = () => {
        this.setState({ hasError: false, droplistSelected: null, isDbExist: false }, () => {
            if(this.refProductSearchInput.current)
                this.refProductSearchInput.current.inputElement.value = "";
        });
    }

    // Remove product in the selection (local state productsInputs) then removes it from parent productResults
    removeProduct = (value) => {
        this.setState({
            productsInputs: this.state.productsInputs.filter(key => {
                return key.ProductId !== value;
            })
        });

        this.props.RemoveProduct(value);
    }

    renderSearchResult = () => {
        let _return = null;

        if (this.props.productsResult.length > 0) {
            _return = (
                <div className="form-group products-list">
                    <div className={"row section-block " + this.state.modalClass}>
                        <div className="columns medium-12">
                            {this.createDivForProductResult()}
                        </div>
                    </div>
                </div>
            );
        }
        return _return;
    }

    renderAddedProducts = () => {
        let _return = null;
        if (this.props.addedProducts.length > 0) {
            _return = (
                <div className="form-group products-list">
                    <div className="row section-block">
                        <div className="columns medium-12">
                            <label htmlFor="" className="list-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.AddedProductTitle }}></label>
                            {this.createDivForAddedProducts()}
                        </div>
                    </div>
                </div>
            );
        }
        return _return;
    }

    //Method for generating the Product Results in a container.
    createDivForAddedProducts = () => {
        let _return = [];
        this.props.addedProducts.forEach((item, i) => {

            _return.push(
                <React.Fragment key={i}>
                    <div className="product-list--added">
                        <div className="product-list--img">
                            <img src={item.ProductImage} alt={item.ProductName} />
                        </div>
                        <div className="product-list--details">
                            <div className="product-list--desc">
                                <p className="product-list--title">{item.ProductName}</p>
                                <a className="product-list--remove" onClick={event => this.removeProduct(item.ProductId)}>
                                    <span>{this.props.data.item.RemoveProduct}</span>
                                </a>
                            </div>
                            <div className="product-list--loyalty-points">
                                <p className="product-list--serial">{this.props.FormatProductId(item.ProductId)}</p>
                                {this.getPoints(item)}
                            </div>
                        </div>
                    </div>
                    {
                        (item.CombiProducts != null && item.CombiProducts.length >= 1) &&
                        this.props.GetCombiProducts(item.CombiProducts, "added")
                    }
                </React.Fragment>
            );
        });

        return _return;
    }

    renderProductSelector = () => {
        let _return = null;

        if (this.state.hasError) {
            _return = (
                <div className={"row section-block " + this.state.modalClass}>
                    <div className="columns medium-12">
                        {this.createInvalidMessage()}
                    </div>
                </div>
            );
        }
        return _return;
    }

    renderProductSearchField = () => {
        let _return = "";

        if (this.props.addedProducts.length < (parseInt(this.props.data.item.ProductLimit) - this.props.productLimitCtr))
            _return = (
                <React.Fragment>
                    <div className="row section-title">
                        <div className="columns medium-12">
                            <label
                                className="serial-label"
                                dangerouslySetInnerHTML={{
                                    __html: this.props.productSearchTitle
                                }}
                            />
                        </div>
                    </div>
                   
                    <div className="row section-field">
                        <div className="columns medium-12">
                            <div className="serial-input">
                                <MaskedInput
                                    type="text"
                                    placeholder={SitecoreHelper.getPlaceholderText(
                                        this.props.isPageEditing,
                                        this.props.data.item.ProductSearchPlaceholder
                                    )}
                                    mask={this._mask}
                                    guide={false}
                                    ref={this.refProductSearchInput}
                                    onChange={event => this.handleProductInput(event)}
                                    onKeyPress={event => this.addProductOnEnter(event)}
                                />
                            </div>
                        </div>
                    </div>
                </React.Fragment>
            );

        return _return;
    }

    handleSerialReEntry = (event) => {
        var snInputLength = event.target.value.replace(/ /g, '').length;

        if (snInputLength === 13) {
            this.addSelectedProduct();
        }
    }
    
    render() {
        return (
            <div className="form-group">
                {this.renderAddedProducts()}
                {this.renderProductSearchField()}
                {this.renderSearchResult()}
                {this.setValidationMessage()}
                {this.renderProductSelector()}
            </div>
        );
    }
}

export default RegistrationProductSearch;
