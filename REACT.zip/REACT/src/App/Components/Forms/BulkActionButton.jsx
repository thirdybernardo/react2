import React, { Component } from 'react';

class BulkActionButton extends Component {
    constructor(props){
        super(props);
    }

    returnToBulkUpload = () => {
        if(this.props.returnToBulkUpload)
            this.props.returnToBulkUpload();
    }

    bulkSubmit = () => {
        if(this.props.bulkSubmit)
            this.props.bulkSubmit();
    }

    render() {
        return(
            <div className="bulk-overview--wrapper">
                <div className="bulk-overview--buttons">
                    <a className="button arrow-left" href="javascript:void(0)" onClick={event => this.returnToBulkUpload()}>
                        <span>{this.props.data.item.BackButton}</span>
                    </a>
                    <a className="button arrow-right green" id="project_register_afronden" href="javascript:void(0)" onClick={event => this.bulkSubmit()}>
                        <span>{this.props.data.item.SubmitButton}</span>
                    </a>
                </div>
            </div>
        );
    }
}

export default BulkActionButton;