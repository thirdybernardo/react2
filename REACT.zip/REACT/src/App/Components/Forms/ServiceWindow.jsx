import React, { Component } from 'react';
import Data from "../../Data/Data";
import CustomDroplist from "../Generic/CustomDroplist";
import ProductAPI from '../../API/ProductRegistration';
import Button from '../Generic/Button';

class ServiceWindow extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productsServices: []
        };
    }


    //Get product services from a source, mock or database
    componentDidMount() {
        if (!this.props.isEditing) {
            if (!this.props.isSitecore) {
                Data.getData("MockProductServices", data => {
                    this.setState({ productsServices: data.ProductServices });
                });
            } else {
                //call the actual Product Services database.
                ProductAPI.GetOGP((result) => {
                    this.setState({ productsServices: result.Results });
                });
            }
        }
    }

    triggerServiceWindow = () => {
        if(this.props.triggerServiceWindow)
            this.props.triggerServiceWindow(false);
    }

    renderProducts = (products) => {
        let _products = [];
        let _options = [];
        let _default = {
            Text: this.props.data.item.NoServiceTitle,
            Value: this.props.data.item.NoServiceTitle
        };
        _options.push(_default);
        this.state.productsServices.forEach((obj, i) => {
            let _obj = {};
            _obj.Text = obj.Title;
            _obj.Value = obj.ServiceId;
            _options.push(_obj);
        });
        products.forEach((obj, i) => {
            if (obj.WarrantyEnabled) {
                let _points = this.props.showPoints !== false ? (<p className="product-list--points">{obj.ProductPoints}</p>) : undefined;
                let _matchingService = this.props.productsServices.find((val, ind) => {
                    if(val.ProductId == obj.ProductId){
                        let _sObj =  {};
                        _sObj.Text = val.Value;
                        _sObj.Value = val.Value;
                        return _sObj;
                    }
                });
                let _selectedService = this.props.productsServices.length > 0
                    ? (!_matchingService ? _default : _matchingService)
                    : _default;
                _products.push(
                    <div className="row section-block" key={i}>
                        <div className="columns medium-12">
                            <div className="product-list--added">
                                <div className="product-list--img">
                                    <img src={obj.ProductImage} alt={obj.ProductName}/>   
                                </div>
                                <div className="product-list--details">
                                    <div className="product-list--desc">
                                        <p className="product-list--title">{obj.ProductName}</p>
                                    </div>
                                    <div className="product-list--loyalty-points">
                                        <p className="product-list--serial">{this.props.FormatProductId(obj.ProductId)}</p>
                                        {_points}
                                    </div>
                                </div>
                            </div>
                            {
                                (obj.CombiProducts != null && obj.CombiProducts.length >= 1) &&
                                this.props.GetCombiProducts(obj.CombiProducts, "added")
                            }
                            <div className="columns medium-12">
                                <div className="product-list--ogp">
                                    <label>
                                        <span dangerouslySetInnerHTML={{ __html: this.props.data.item.ServiceDroplist }} />
                                    </label>
                                    <CustomDroplist 
                                        containerClass="" 
                                        list={_options} 
                                        selected={_selectedService} 
                                        action={this.props.ManageProductService} 
                                        identifier={obj.ProductId}/>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            }
        });
        return _products;
    }

    renderContent = () => {
        let _return = null;
        if (this.props.showServiceWindow) {
            _return = (
                <div className={"form--single-upload " + (this.props.showServiceWindow === true ? "" : "hide")}>
                    <div className="form-group service">
                        <div className="row section-title">
                            <div className="columns medium-12">
                                <div className="contextual-title-bold"><span dangerouslySetInnerHTML={{ __html: this.props.data.item.ServiceWindowTitle }} /></div>
                            </div>
                        </div>
                        {this.renderProducts(this.props.productsResult)}
                    </div>
                    <div className="form-group services">
                        <div className="row section-title collapse">
                            <Button
                                className = "button back"
                                text={this.props.data.item.ServiceBackButton}
                                callback ={this.triggerServiceWindow}
                                wrapperClassName="columns small-6"
                            />
                            <Button
                                className = "button arrow-right green"
                                text={this.props.data.item.SubmitButton}
                                callback ={this.props.action}
                                wrapperClassName="columns small-6 hide-for-small text-right"
                            />
                            <Button
                                className = "button arrow-right"
                                text={this.props.data.item.SubmitButtonMobile}
                                callback ={this.props.action}
                                wrapperClassName="columns small-6 show-for-small-only"
                            />
                        </div>
                    </div>
                </div>
            );
        }
        return _return;
    }

    render() {
        return (
            <React.Fragment>
                {this.renderContent()}
            </React.Fragment>
        );
    }
}

export default ServiceWindow;