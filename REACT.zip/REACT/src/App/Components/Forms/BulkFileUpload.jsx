import React, { Component } from 'react';
import Mime from 'mime-types';
import DownloadButton from '../Generic/DownloadButton';
import FileUpload from '../Generic/FileUpload';
import File from '../../Helpers/FileHelper';
import Faker from '../../Helpers/Faker';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import ProductAPI from '../../API/ProductRegistration';
import BulkOverview from './BulkOverview';
import QueryString from "../../Data/QueryString";

class BulkFileUpload extends Component {
    constructor(props) {
        super(props);
        this.filepondRef = React.createRef();
        this.serverUrl = "/";
        this.redirectTimeout = 1000;

        this.state = {
            fileUploadStep: 0,
            allowUploadCallback: true,
            fileName: "",
            errorMessage: ""
        };
        this.enums = {
            fileError: {
                genericError: 0,
                hasDuplicateField: 1,
                hasMissingField: 2
            }
        };
    }

    getAllowedFileTypes = () => {
        let _mimeTypes = String(this.props.data.item.TemplateAcceptedMimeTypes).split("|");
        return _mimeTypes;
    }

    initialStep = () => {
        let _return = null;
        _return = (
            <React.Fragment>
                <div className="row section-upload">
                    <div className="columns medium-12 ul-wrapper">
                        <label dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadContainerText }} />
                        <label dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadOptionText }} />
                        <FileUpload
                            maxFiles={1}
                            filepondRef={this.filepondRef}
                            hidden={false}
                            server={this.serverUrl}
                            allowFileTypeValidation={true}
                            allowedFileTypes={this.getAllowedFileTypes()}
                            instantUploadEnabled={false}
                            handleInit={undefined}
                            updateCallback={this.uploadCallback}
                            labelLink={this.props.data.item.FileUploadButtonText}
                        />
                    </div>
                </div>
                <div className="row">
                    <div className="columns medium-5 dl-wrapper">
                        <label dangerouslySetInnerHTML={{ __html: this.props.data.item.ChoiceText }} />
                        <DownloadButton
                            className="button arrow-right"
                            text={this.props.data.item.DownloadTemplateText}
                            fileUrl={this.props.data.item.TemplateFileSource}
                            fileName={this.props.data.item.TemplateFileName}
                            isSitecore={this.props.isSitecore}
                            isEditing={this.props.isEditing} />
                    </div>
                </div>
            </React.Fragment>
        );
        return _return;
    }

    uploadStep = () => {
        let _return = null;
        _return = (
            <React.Fragment>
                <div className="row section-upload">
                    <div className="columns medium-12 ul-loading-wrapper">
                        <div className="image-container">
                            <img src={this.props.isSitecore ? SitecoreHelper.getImage(this.props.data.item.FileUploadingIcon) : this.props.data.item.FileUploadingIcon} alt="" />
                        </div>
                        <label>
                            <span dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadingText }} />
                            <span className="file-name">&nbsp;{this.state.fileName}</span>
                        </label>
                    </div>
                </div>
            </React.Fragment>
        );
        return _return;
    }

    successStep = () => {
        let _return = null;
        _return = (
            <React.Fragment>
                <div className="row section-upload">
                    <div className="columns medium-12 ul-successful-wrapper">
                        <img src={this.props.isSitecore ? SitecoreHelper.getImage(this.props.data.item.FileUploadSuccessIcon) : this.props.data.item.FileUploadSuccessIcon} alt="" />
                        <label className="success-wrapper">
                            {this.state.fileName}
                            &nbsp;
                                <span dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadSuccessText }} />
                        </label>
                        <label dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadSuccessSubText }} />
                    </div>
                </div>
            </React.Fragment>
        );
        return _return;
    }

    failStep = () => {
        let _return = null;
        let _errorMessage = this.state.errorMessage === "" ? this.props.data.item.FileUploadFailIncorrectFileText : this.state.errorMessage;
        _return = (
            <React.Fragment>
                <div className="row section-upload">
                    <div className="columns medium-12 ul-error-wrapper">
                        <img src={this.props.isSitecore ? SitecoreHelper.getImage(this.props.data.item.FileUploadFailIcon) : this.props.data.item.FileUploadFailIcon} alt="" />
                        <label className="error-wrapper" dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadFailText }} />
                        <label dangerouslySetInnerHTML={{ __html: _errorMessage }} />
                        <div htmlFor="bulk-upload-fail" className="bulk-input-wrapper">
                            <FileUpload
                                maxFiles={1}
                                filepondRef={this.filepondRef}
                                hidden={false}
                                server={this.serverUrl}
                                allowFileTypeValidation={true}
                                allowedFileTypes={this.getAllowedFileTypes()}
                                instantUploadEnabled={false}
                                handleInit={undefined}
                                updateCallback={this.uploadCallback}
                                labelLink={this.props.data.item.FileUploadFailTryAgainText} />
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="columns medium-5 dl-wrapper">
                        <label dangerouslySetInnerHTML={{ __html: this.props.data.item.TemplateConfirmationText }} />
                        <DownloadButton
                            className="button arrow-right"
                            text={this.props.data.item.DownloadTemplateText}
                            fileUrl={this.props.data.item.FileSource}
                            fileName={this.props.data.item.FileName} />
                    </div>
                </div>
            </React.Fragment>
        );
        return _return;
    }

    overviewStep = () => {
        return <BulkOverview />;
    }

    getRequiredFields = () => {
        let _return = [];
        if (this.props.data.item.TemplateRequiredFields) {
            this.props.data.item.TemplateRequiredFields.split("|").forEach((val) => {
                _return.push(String(val).replace(/\s/g, ''));
            });
        }
        return _return;
    }

    uploadCallback = () => {
        if(this.state.allowUploadCallback){
            this.setState({ allowUploadCallback: false}, () => {
                let _isValid = false;
                this.filepondRef.current.getFiles().forEach((file) => {
                    let _allowed = this.getAllowedFileTypes().find((val) => {
                        return String(val).toLowerCase() == String(Mime.lookup(file.file.name)).toLowerCase();
                    });
                    if (_allowed) {
                        _isValid = true;
                        let _ref = this.filepondRef.current;
                        File.readWorkbookOrCSV(file.file, this.getRequiredFields(), true, (result) => {
                            if (result.status) {
                                this.setState({
                                    fileUploadStep: 1,
                                    fileName: file.file.name,
                                    errorMessage: ""
                                }, () => {
                                    let _result = [...result.data];
                                    // Pass analyzed content to the next component here - Bulk Upload Overview  
                                    if (!this.props.isSitecore) {
                                        // Fake file upload on React
                                        Faker.fakePromise(3000, "Mock upload").then((result) => {
                                            console.log(result);
                                            this.setState({ fileUploadStep: 2 });
                                        });
                                    }
                                    else {
                                        // API call in Sitecore
                                        let snLimit = this.props.productSNMonthLimit;
                                        let _installerId = QueryString.getValue("installerid");
                                        let __result = [..._result].map((val) => {
                                            val["InstallerId"] = _installerId;
                                            return val;
                                        });
                                        ProductAPI.RefineBulkData(snLimit, __result, (response) => {
                                            if (response && response.status === 200) {
                                                this.setState({ fileUploadStep: 2 });
                                                setTimeout(() => {
                                                    //Redirect to bulk overview
                                                    this.props.renderBulkOverView(response.data.Results, response.data.UploadBasicInfo, this.state.fileName);
                                                }, this.redirectTimeout);
                                            }
                                            else{
                                                // When file is invalid on component validation level, ensure to reset the generic component's input file's filelist
                                                _ref.removeFiles();
                                                this.setState({ fileUploadStep: 3, allowUploadCallback: true});
                                            }
                                        });
                                    }
                                });
                            }
                            else {
                                let _errorMessage = "";
                                if (result.code === this.enums.fileError.genericError) {
                                    _errorMessage = this.props.data.item.FileUploadFailIncorrectFileText;
                                }
                                else if (result.code === this.enums.fileError.hasDuplicateField) {
                                    _errorMessage = this.props.data.item.FileUploadFailDuplicateFieldText;
                                }
                                else if (result.code === this.enums.fileError.hasMissingField) {
                                    _errorMessage = this.props.data.item.FileUploadFailMissingFieldText;
                                }
                                this.setState({
                                    fileUploadStep: 3,
                                    errorMessage: _errorMessage,
                                    allowUploadCallback: true
                                });
                                // When file is invalid on component validation level, ensure to reset the generic component's input file's filelist
                                _ref.removeFiles();
                            }
                        }, _ref);
                    }
                    else {
                        // When file is invalid on component validation level, ensure to reset the generic component's input file's filelist
                        this.filepondRef.current.removeFiles();
                    }
                });
                if (!_isValid) {         
                    // When file is invalid on component validation level, ensure to reset the generic component's input file's filelist
                    this.filepondRef.current.removeFiles();                       
                    this.setState({ fileUploadStep: 3, errorMessage: this.props.data.item.FileUploadFailIncorrectFileText, allowUploadCallback: true });
                }
            });
        }
        else
            this.filepondRef.current.removeFiles();
    }

    renderContents = () => {
        let _partial = null;
        let _return = null;
        switch (this.state.fileUploadStep) {
            case 0:
                _partial = this.initialStep();
                break;
            case 1:
                _partial = this.uploadStep();
                break;
            case 2:
                _partial = this.successStep();
                break;
            case 3:
                _partial = this.failStep();
                break;
        }
        _return = (
            <div className="form">
                <div className="form-group">
                    <div className="row section-title">
                        <div className="columns medium-12">
                            <label dangerouslySetInnerHTML={{ __html: this.props.data.item.FileUploadSubtitle }} />
                        </div>
                    </div>
                    {_partial}
                </div>
            </div>
        );
        return _return;
    }

    render() {
        return (
            <React.Fragment>
                {this.renderContents()}
            </React.Fragment>
        );
    }
}

export default BulkFileUpload;