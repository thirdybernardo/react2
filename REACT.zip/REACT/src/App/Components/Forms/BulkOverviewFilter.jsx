import React, { Component } from 'react';
import PaginationSlicer from "../Generic/PaginationSlicer";
import SH from "../../Helpers/SitecoreHelper";

class BulkOverviewFilter extends Component {
    constructor(props) {
        super(props);
        this.enums = {
            CallbackKeys: {
                paginationSlice: "paginationSlice"
            }
        };
        this.paginationSlicerRef = React.createRef();
    }

    getPaginationSlices = () => {
        let _return = [{}];
        let _slices = this.props.data.item.PaginationSlices;
        if (_slices) {
            _return = _slices.split("|").map((val) => {
                let _val = {};
                _val.Text = String(val);
                _val.Value = parseInt(val.replace(/[^\d.]/g, '' ));
                return _val;
            });
        }
        return _return;
    }

    handleStateChange = (val, ref, callbackKey) => {
        this.props.updatePaginationSlice(val);
    }

    getFileData = () => {
        let _dataFound = this.props.data.item.OverviewFileDataFound;
        if(!this.props.isEditing && _dataFound != undefined)
            return _dataFound.replace("$(address)", this.props.uploadBasicInfo.AddressesFound).replace("$(product)", this.props.uploadBasicInfo.ProductsFound);

        return _dataFound;
    }

    render() {
        return (
            <div className="product--result-search-filter">
                <div className="product--bulk-result">
                    <h2>{this.props.fileName}</h2>
                    <p>{this.getFileData()}</p>
                </div>
                <div className="product--bulk-search-filter">
                    <div className="product--bulk-search-filter-box product--bulk-search">
                        <div className="product-overview--search-wrapper">
                            <input type="text" 
                            placeholder={SH.getPlaceholderText(this.props.isEditing, this.props.data.item.OverviewSearchPlaceholder)} 
                            onChange={e => this.props.handleSearch(e)} />
                        </div>
                    </div>
                    <PaginationSlicer
                        title={this.props.data.item.PaginationTitle}
                        wrapperClass={this.props.data.item.WrapperClass}
                        slices={this.getPaginationSlices()}
                        dataRef={this.paginationSlicerRef}
                        callback={this.handleStateChange}
                        callbackKey={this.enums.CallbackKeys.paginationSlice}
                    />
                </div>
            </div>
        );
    }
}

export default BulkOverviewFilter;