import React, { Component } from 'react';

class Save extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    removeEntry = () => {
        if (this.props.removeEntry) {
            this.props.removeEntry();
        }
    }


    render() {
        return (
            <div className="form-group service-buttons">
                <div className="row section-title">
                    <a href="javascript:void(0)" className="button secondary hollow-red" onClick={event => this.removeEntry()}>
                        <span dangerouslySetInnerHTML={{ __html: this.props.data.item.RemoveButton }} />
                    </a>
                    <a href="javascript:void(0)" className={"button arrow-right green " + this.props.buttonClass} id="save_data" onClick={event => this.props.action(event)}>
                        <span dangerouslySetInnerHTML={{ __html: this.props.data.item.SaveButton }} />
                    </a>
                </div>
            </div>
        );
    }
}

export default Save;