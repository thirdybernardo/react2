import React, { Component } from 'react';

class ServiceButton extends Component {
    constructor(props) {
        super(props);
    }

    getClass = () => {
        let _return = "button secondary";
        if(!this.props.isVisible){
            _return += " hide";
        }
        return _return;
    }

    serviceButtonClick = (e) => {
        e.preventDefault();
        this.props.TriggerServiceWindow(true);
    }


    render() {
        return (   
            <a href="#" className={this.getClass()} id="project_select" onClick={event => this.serviceButtonClick(event)}>
                <span className="" dangerouslySetInnerHTML={{ __html: this.props.data.item.ServiceButton }} />
                <span className= "mobile" dangerouslySetInnerHTML={{ __html: this.props.data.item.ServiceButtonMobile }} />
            </a>
        );
    }
}

export default ServiceButton;