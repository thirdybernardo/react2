﻿import React, { Component } from 'react';
import Modal from '../Generic/Modal';
import SingleUpload from '../ProductRegistration/SingleUpload';
import Data from '../../Data/Data';
import moment from 'moment';
import ValidatorHelper from "../../Helpers/Validator";
import Pagination from '../Generic/Pagination';

class BulkOverviewTable extends Component {
    constructor(props) {
        super(props);

        this.state = {
            entries: null,
            modalOpened: false,
            dataEntries: null,
            isBulk: true,
            singleEntry: {},
            registeredProducts: [],
            paginationOptions: {
                currentPagination: 1,
                targetPagination: 1,
                totalPagination: 0,
                resultKeysCount: 0
            },
            paginationSlicesFallback: 1
        };

        this.enums = {
            Product: "product",
            Address: "address",
            Email: "email",
            Telephone: "telephone"
        };

        this.sections = {
            productSectionValid: true,
            addressSectionValid: true,
            telephoneSectionValid: true,
            emailSectionValid: true
        };
        this.errCtr = 0;
        this.validator = ValidatorHelper;
    }

    componentDidMount() {
        if (!this.props.isEditing) {
            if (!this.props.isSitecore) {
                Data.getData("MockRegisteredProducts", data => {
                    this.setState({ registeredProducts: data.Products });
                });
            }
        }
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props.selectedForDeletion.length === 0) {
            var checkboxes = document.getElementsByName("chkSelectAll");
            checkboxes[0].checked = false;
        }
        if (Object.values(this.props.data.item).length > 0 && this.props.uploaded && !this.props.initialize) {
            //this.renderTableEntries()
            //*start
            this.props.setEntryAnalysation(true, () => {
                let _entriesHasError = (this.errCtr > 0) ? true : false;
                this.props.setBulkErrorValidation(_entriesHasError, this.errCtr);
            });
            //*end
            this.props.setInitialize(true);
        }

        if (prevProps.uploaded.length != this.props.uploaded.length || prevProps.paginationSlice != this.props.paginationSlice) {
            let _data = [...this.props.uploaded];
            let _slice = this.props.paginationSlice <= 0 ? this.state.paginationSlicesFallback : this.props.paginationSlice;
            let _totalP = (_data.length / _slice);
            _totalP = (_totalP % 1).toFixed(1).substring(2) != 0 ? Math.floor(_totalP) + 1 : _totalP;
            this.updatePaginationOptions(["resultKeysCount:" + _data.length, "totalPagination:" + _totalP, "currentPagination:" + 1]);
        }

        /*Uncheck all checkboxes on page change*/
    
        if (prevState.paginationOptions.currentPagination != this.state.paginationOptions.currentPagination) {
            this.props.undoSelection();
        }
    }

    checkSetTelephoneIfValid = (value, sections) => {
        let _result = "";
        let _section = "telephone";
        if (value) {
            this.validator["telephone"].rules.forEach((rule) => {
                if (rule.validate instanceof RegExp) {
                    if (!rule.validate.test(value)) {
                        _result = "error";
                        this.setEntrySectionStatus(sections, _section, false);
                    }
                }
            });
        }
        return _result;
    }

    checkSetEmailAddressIfValid = (value, sections) => {
        let _result = "";
        let _section = "email";
        if (value) {
            this.validator["email"].rules.forEach((rule) => {
                if (rule.validate instanceof RegExp) {
                    if (!rule.validate.test(value)) {
                        _result = "error";
                        this.setEntrySectionStatus(sections, _section, false);
                    }
                }
            });
        }
        return _result;
    }

    setEntrySectionStatus = (sections, section, isValid) => {
        let _obj = Object.assign(sections);

        if (section === this.enums.Product)
            _obj.productSectionValid = isValid;
        else if (section === this.enums.Address)
            _obj.addressSectionValid = isValid;
        else if (section === this.enums.Email)
            _obj.emailSectionValid = isValid;
        else if (section === this.enums.Telephone)
            _obj.telephoneSectionValid = isValid;

        this.sections = _obj;
    }

    entryErrorCounter = (sections) => {
        let _ctr = this.errCtr;
        let _obj = sections;
        let _results = null;
        _results = Object.values(_obj);

        let _result = _results.filter(x => x === false);

        if (_result.length >= 1)
            _ctr++;

        _result.productSectionValid = true;
        _result.addressSectionValid = true;
        _result.emailSectionValid = true;
        _result.telephoneSectionValid = true;

        this.sections =

            this.errCtr = _ctr;
    }

    renderTableEntries = () => {
        let uploadedRegistrations = [];
        this.errCtr = 0;

        if (this.props.uploaded) {
            this.props.uploaded.map((val, i) => {
                if (i < (this.props.paginationSlice * this.state.paginationOptions.currentPagination) && i >= (this.props.paginationSlice * (this.state.paginationOptions.currentPagination - 1))) {
                    let errorTelephone = this.checkSetTelephoneIfValid(val.TelephoneNo, this.sections);
                    let errorEmail = this.checkSetEmailAddressIfValid(val.EmailAddress, this.sections);
                    let errorClass = (val.ErrorList || errorTelephone === "error" || errorEmail === "error") ? "error" : "";

                    uploadedRegistrations.push(<div key={val.Id} className="list-product-selection">
                        <label className="select-wrapper">
                            <input type="checkbox" id={val.Id} name="chkTable" onChange={e => this.props.checkboxSelect(e, val.Id)} />
                            <span />
                        </label>
                        <div className={`product-table--list-fields ${errorClass}`}>
                            <div className="list-entry-section">
                                <div className="list-entry list--date">

                                    <span>{moment(new Date(val.InstallationDate)).locale("nl").format('DD-MM-YYYY')}</span>
                                </div>
                                <div className="list-entry list--name">
                                    <span>{val.Firstname} {val.Lastname}</span>
                                </div>
                                {this.renderCompleteAddress(val.AddressResponse, this.sections)}
                                <div title={val.TelephoneNo} className={"list-entry list--telephone " + errorTelephone}>
                                    <span>{val.TelephoneNo}</span>
                                </div>
                                <div className={"list-entry list--email " + errorEmail}>
                                    <span>{val.EmailAddress}</span>
                                </div>
                                <div className="list-entry list--modify">
                                    <a href="javascript:void(0)" className="update-link" onClick={event => this.triggerEditEntry(event, val)}>{this.props.data.item.EditEntryButton}</a>
                                </div>
                            </div>
                            {this.renderProductsSection(val)}
                        </div>
                    </div>
                    );
                    this.entryErrorCounter(this.sections, this.errCtr);
                }
            });
        }
        return uploadedRegistrations;
        // this.props.setEntryAnalysation(true)
        // let _entriesHasError = (this.errCtr > 0) ? true : false
        // this.props.setBulkErrorValidation(_entriesHasError, this.errCtr)
        // this.setState({ entries: uploadedRegistrations })
    }


    renderProductsSection = (rowItem) => {

        let productsList = [];
        let productCtr = 1;

        rowItem.SerialNumber.map((val, i) => {
            let _product = rowItem.Products.find(item => item.ProductId === val);
            if (_product) {
                if (_product.CombiProducts.length >= 1)
                    productCtr++;

                if (productCtr > 5) {
                    productsList.push(<div key={i} className="list-products-section error">
                        <div className="product-description">{this.props.data.item.BulkGenericErrorMessage}</div>
                        <div className="product-serial">{val}</div>
                        <span>&nbsp;</span>
                    </div>);
                    this.setEntrySectionStatus(this.sections, "product", false);
                }else if(_product.isRegistered === 1 || _product.isSerialNumberActive === 0) {
                    productsList.push(<div key={i} className="list-products-section error">
                        <div className="product-description">{this.props.data.item.BulkGenericErrorMessage}</div>
                        <div className="product-serial">{val}</div>
                        <span>&nbsp;</span>
                    </div>);
                    this.setEntrySectionStatus(this.sections, "product", false);
                }else if (this.checkIfDuplicateProductEntry(_product.ProductId, rowItem.SerialNumber)) {
                    productsList.push(<div key={i} className="list-products-section error">
                        <div className="product-description">{this.props.data.item.BulkGenericErrorMessage}</div>
                        <div className="product-serial">{val}</div>
                        <span>&nbsp;</span>
                    </div>);
                    this.setEntrySectionStatus(this.sections, "product", false);
                }else {
                    productsList.push(< div key={i} className="list-products-section" >
                        <div className="product-description" title={_product.ProductName}>{_product.ProductName}</div>
                        <div className="product-serial">{_product.ProductId}</div>
                        <span>&nbsp;</span>
                    </div>);
                    productCtr++;
                }
            } else if (this.checkIfDuplicateProductEntry(_product, rowItem.SerialNumber)) {
                productsList.push(<div key={i} className="list-products-section error">
                    <div className="product-description">{this.props.data.item.BulkGenericErrorMessage}</div>
                    <div className="product-serial">{val}</div>
                    <span>&nbsp;</span>
                </div>);
                this.setEntrySectionStatus(this.sections, "product", false);
            }
            else {
                productsList.push(<div key={i} className="list-products-section error">
                    <div className="product-description">{this.props.data.item.BulkGenericErrorMessage}</div>
                    <div className="product-serial">{val}</div>
                    <span>&nbsp;</span>
                </div>);
                this.setEntrySectionStatus(this.sections, "product", false);
            }
        });

        return productsList;
    }

    triggerEditEntry = (e, val) => {
        this.manageEditEntry(val);
    }

    modalRenderer = () => {
        if (this.state.modalOpened) {
            return (<Modal data={this.props.data} closeEvent={this.closeEntry} modalContent={this.modalContent} closeId={"modalOpened"} />);
        }
    }

    manageEditEntry = (entry) => {
        if (this.state.singleEntry !== entry) {
            this.setState({
                singleEntry: entry,
                ID: entry.Id
            }, () => {
                this.setState({ modalOpened: true });
            });
        }
        else {
            this.setState({ modalOpened: true });
        }
    }

    closeEntry = (key) => {
        this.setState({
            [key]: false
        });
    }

    removeEntry = () => {
        let _id = this.state.singleEntry.Id;
        if (this.props.removeEntry) {
            this.props.removeEntry(_id, () => {
                //this.renderTableEntries()
               //*start
                this.props.setEntryAnalysation(true, () => {
                    let _entriesHasError = (this.errCtr > 0) ? true : false;
                    this.props.setBulkErrorValidation(_entriesHasError, this.errCtr);
                });
               //*end
                this.closeEntry("modalOpened");
            });
        }
    }

    saveAction = (obj) => {
        obj.Id = this.state.singleEntry.Id;
        obj.ErrorList = null;
        if (this.props.saveAction) {
            this.props.saveAction(obj, () => {
                //this.renderTableEntries()
                //*start
                this.props.setEntryAnalysation(true, () => {
                    let _entriesHasError = (this.errCtr > 0) ? true : false;
                    this.props.setBulkErrorValidation(_entriesHasError, this.errCtr);
                });
                //*end
                this.closeEntry("modalOpened");
                if(this.props.searchValue)
                    this.props.handleSearch(null, this.props.searchValue);
            });
        }

    }

    updatePaginationOptions = (newParams) => {
        let paginationOptionsCopy = Object.assign({}, this.state.paginationOptions);
        newParams.forEach((val, index) => {
            let thisVal = String(val).split(":");
            paginationOptionsCopy[thisVal[0]] = thisVal[1];
        });
        this.setState({ paginationOptions: paginationOptionsCopy },
            () => {
                //this.renderTableEntries()
                //*start
                this.props.setEntryAnalysation(true, () => {
                    let _entriesHasError = (this.errCtr > 0) ? true : false;
                    this.props.setBulkErrorValidation(_entriesHasError, this.errCtr);
                });
                //*end
                this.props.setInitialize(true);
            }
        );
    }

    modalContent = () => {
        let singleEntry = this.state.singleEntry;
        return (
            <React.Fragment>
                <div className="form--content">
                    {/* <!-- Added single upload- contents --> */}
                    <SingleUpload data={this.props.data}
                        registeredProducts={this.state.registeredProducts}
                        isBulk={this.state.isBulk}
                        singleEntry={this.state.singleEntry}
                        isSitecore={this.props.isSitecore}
                        removeEntry={this.removeEntry}
                        saveAction={this.saveAction}
                        index={this.state.index}
                        isEditing={this.state.isEditing} />

                </div>

            </React.Fragment>);
    }

    checkIfDuplicateProductEntry = (productId, arr) => {
        let _result = arr.filter(x => x === productId);

        if (_result.length >= 2)
            return true;

        return false;
    }

    renderCompleteAddress = (addressResponse, sections) => {
        let _address = "";
        let _section = "address";
        if (addressResponse) {
            _address = `${addressResponse.response.docs[0].straatnaam} 
                        ${addressResponse.response.docs[0].huis_nlt}, 
                        ${addressResponse.response.docs[0].postcode} 
                        ${addressResponse.response.docs[0].gemeentenaam}`;
        }

        if (_address == "")
            this.setEntrySectionStatus(sections, _section, false);

        return (
            <div title={_address} className="list-entry list--address">
                <span>{_address}</span>
            </div>
        );
    }

    selectAllCheckboxes = (e) => {
        var checkboxes = document.getElementsByName("chkTable");
        let ids = [];

        checkboxes.forEach((item, i) => {
            item.checked = e.target.checked;
            ids.push(item.id);
        });

        this.props.checkboxMultipleSelect(e, ids);
    }


    renderTable = () => {
     
        let _return = (
            <div className="product-table--list active">
                <div className="product-table--list-box">
                    <div className="list-header-selection">
                        <label className="select-wrapper">
                            <input type="checkbox" name="chkSelectAll" onChange={e => this.selectAllCheckboxes(e)} />
                            <span />
                        </label>
                        <div className="product-table--list-header">
                            <div className="list-entry list--date">
                                <span>{this.props.data.item.DateLabel}</span>
                            </div>
                            <div className="list-entry list--name">
                                <span>{this.props.data.item.NameLabel}</span>
                            </div>
                            <div className="list-entry list--address">
                                <span>{this.props.data.item.AddressLabel}</span>
                            </div>
                            <div className="list-entry list--telephone">
                                <span>{this.props.data.item.TelephoneLabel}</span>
                            </div>
                            <div className="list-entry list--email">
                                <span>{this.props.data.item.EmailLabel}</span>
                            </div>
                        </div>
                    </div>
                    {this.renderTableEntries()}
                </div>
            </div>
        );

        return _return;
    }

    renderDeleteButton = () => {
        let _return = "";

        if (this.props.selectedForDeletion.length > 0) {
            _return = (
                <div className="delete-button-wrapper">
                    <a href="javascript:void(0);" className="button red" onClick={e => this.props.deleteSelected()}>
                        <span>{this.props.data.item.DeleteLabel}</span>
                    </a>
                </div>
            );
        }
        return _return;
    }

    render() {
        return (
            <div className="bulk-overview--wrapper white-bg-full-width">
                <div className="table-container">
                    {this.renderDeleteButton()}
                    {this.renderTable()}
                    <Pagination
                        data={this.props.data}
                        paginationOptions={this.state.paginationOptions}
                        updatePaginationOptions={this.updatePaginationOptions}
                    />
                    {this.modalRenderer()}
                </div>
            </div>
        );
    }
}

export default BulkOverviewTable;