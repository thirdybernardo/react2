import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import ServiceButton from '../ServiceButton';
import serviceButtonContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';

const serviceButtonComponent = shallow(<ServiceButton data={serviceButtonContent} TriggerServiceWindow={jest.fn(()=> true)} />);

test("Check data used in component", () => {
    expect(serviceButtonComponent.instance().props.data.item.ServiceButton).toEqual("OGP regelen & afronden");
});

test("Anchor tag exists", () => {
    expect(serviceButtonComponent.find("a#project_ogp")).toEqual(expect.anything());
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(<ServiceButton data={serviceButtonContent} />);
    expect(tree).toMatchSnapshot();
});

test('ServiceButton simulate event with props', () => {
    const serviceButtonAnchor = serviceButtonComponent.find("a#project_select");

    // Simulate click of the input element and its value
    serviceButtonAnchor.simulate('click', {
        target: { value: "test value" },
        preventDefault: () => {
        }
    });

    // Check if mocked function received from parent was executed with click   
    expect(serviceButtonComponent.instance().props.TriggerServiceWindow).toBeCalled();
});
