import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import BulkOverviewFilter from '../BulkOverviewFilter';
import bulkOverviewFilter from '../../../../../build/Data/json/BulkRegistrationProductFields.json';
import renderer from 'react-test-renderer';

const fn = jest.fn();
const bulkOverviewFilterComponent = shallow(
    <BulkOverviewFilter 
        data={bulkOverviewFilter}
        handleSearch={fn}
        uploadBasicInfo={{}}
        fileName="Bulk Overview Test File"
        updatePaginationSlice={jest.fn(()=> 1)}
        isEditing={false}
    />);

test('BulkOverviewFilter matches snapshot', () => {
    const tree = renderer.create(
        <BulkOverviewFilter 
            data={bulkOverviewFilter}
            handleSearch={fn}
            uploadBasicInfo={{}}
            fileName="Bulk Overview Test File"
            updatePaginationSlice={jest.fn(()=> 1)}
            isEditing={false}
        />).toJSON();
    expect(tree).toMatchSnapshot();
});

