import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import DatePicker from '../DatePicker';
import DatePickerContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import renderer from 'react-test-renderer';

const fn = jest.fn();
const datePicker = shallow(
    <DatePicker
        data={DatePickerContent}
        setFormValues={fn}
    />);


test("Check data used in component", () => {
    expect(datePicker.instance().props.data.item.DatePickerMaxDays).toEqual("28");
    expect(datePicker.instance().props.data.item.DatePickerMinDays).toEqual("28");
    expect(datePicker.instance().props.data.item.DatePickerLocale).toEqual("nl");
    expect(datePicker.instance().props.data.item.DatePickerFormat).toEqual("dddd, DD MMMM");
    expect(datePicker.instance().props.data.item.DatePickerTodayLabel).toEqual("(Vandaag)");
    expect(datePicker.instance().props.data.item.DatePickerTitle).toEqual("Installatiedatum");
});

test("Toggle Date Picker", ()=>{
    const _wrapper = datePicker.find(".datepicker-wrapper");
    _wrapper.simulate("click", ()=>{
        {"test";}
    });

    datePicker.instance().setState({displayClassName: ""},()=>{
        expect(datePicker.state().displayClassName).toMatch("");
    });

    datePicker.instance().setState({isDateSelecting: false},()=>{
        expect(datePicker.state().isDateSelecting).toEqual(false);
    });

    datePicker.instance().setState({activeClassName: "active"},()=>{
        expect(datePicker.state().activeClassName).toMatch("active");
    });

});
