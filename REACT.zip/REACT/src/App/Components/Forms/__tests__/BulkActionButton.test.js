import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import BulkActionButton from '../BulkActionButton';
import bulkActionContent from '../../../../../build/Data/json/BulkRegistrationProductFields.json';

const fn = jest.fn();
const bulkActionComponent = shallow(
    <BulkActionButton data={bulkActionContent} 
        returnToBulkUpload={fn}
        bulkSubmit={fn}
    />);

const undefinedProps = shallow(
    <BulkActionButton data={bulkActionContent} 
        returnToBulkUpload={undefined}
        bulkSubmit={undefined}
    />);

test("Check data used in component", () => {
    expect(bulkActionComponent.instance().props.data.item.BackButton).toEqual("Start een nieuwe upload");
    expect(bulkActionComponent.instance().props.data.item.SubmitButton).toEqual("Verwerk alleen goede registraties");
});

test("Anchor tag exists", () => {
    expect(bulkActionComponent.find("a.button.green")).toEqual(expect.anything());
    expect(bulkActionComponent.find("a.button.arrow-left")).toEqual(expect.anything());
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(
        <BulkActionButton data={bulkActionContent} 
            returnToBulkUpload={fn}
            bulkSubmit={fn}
        />);
    expect(tree).toMatchSnapshot();
    
});

test("Check Back To Upload Entry component buttons", () =>{
    const backToUpload = bulkActionComponent.find("a.button.arrow-left");
    
    backToUpload.simulate('click', ()=>{
        {"test value";}
    });
    expect(bulkActionComponent.instance().props.returnToBulkUpload).toBeCalled();
});

test("Check Submit Entry component buttons", () =>{
    const submit = bulkActionComponent.find("a.button.green");
    submit.simulate('click', ()=>{
        {"test";}
    });
    expect(bulkActionComponent.instance().props.bulkSubmit).toBeCalled();
});

test("check if props if undefine", ()=>{undefined;
    const backToUpload = undefinedProps.find("a.button.arrow-left");
    const submit = undefinedProps.find("a.button.green");

    backToUpload.simulate('click', ()=>{
        {"test value";}
    });

    submit.simulate("click", ()=>{
        { "test";}
    });

    expect(undefinedProps.instance().props.returnToBulkUpload).toBeUndefined();
    expect (undefinedProps.instance().props.bulkSubmit).toBeUndefined();
});