import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import BulkAlert from '../BulkAlert';
import data from '../../../../../build/Data/json/BulkRegistrationProductFields.json';
import SitecoreHelper from '../../../Helpers/SitecoreHelper';

const fn = jest.fn();

test("Bulk Alert matches snap shot if with Alert", () => {
    const toolTipIcon = SitecoreHelper.getImage(data.ToolTipIcon);
    const bulkErrorValidation = {
        hasError: true,
        numberOfError: "1"
    };
    const tree = renderer.create(
        <BulkAlert
            data={data}
            tooltipIcon={toolTipIcon}
            bulkErrorValidation={bulkErrorValidation}
            entryAnalysationDone={true}
            setEntryAnalysation={true}
        />
    );

    expect(tree).toMatchSnapshot();
});

test("Bulk Alert matches snap shot if without Alert", () => {
    const toolTipIcon = SitecoreHelper.getImage(data.ToolTipIcon);
    const bulkErrorValidation = {
        hasError: false,
        numberOfError: "0"
    };
    const tree = renderer.create(
        <BulkAlert
            data={data}
            tooltipIcon={toolTipIcon}
            bulkErrorValidation={bulkErrorValidation}
            entryAnalysationDone={true}
            setEntryAnalysation={true}
        />
    );

    expect(tree).toMatchSnapshot();
});

test("Get number of errors no errors", () => {
    const toolTipIcon = SitecoreHelper.getImage(data.ToolTipIcon);
    const bulkErrorValidation = {
        hasError: false,
        numberOfError: "0"
    };

    const wrapper = shallow(<BulkAlert
            data={data}
            tooltipIcon={toolTipIcon}
            bulkErrorValidation={bulkErrorValidation}
            entryAnalysationDone={true}
            setEntryAnalysation={true}
            isEditing={false}
        />);

    expect(wrapper.instance().getNumberOfError()).toEqual("Uw bestand bevat 0 probleem, controleer uw data a.u.b.");
});

test("Get number of errors with errors", () => {
    const toolTipIcon = SitecoreHelper.getImage(data.ToolTipIcon);
    const bulkErrorValidation = {
        hasError: true,
        numberOfError: "1"
    };

    const wrapper = shallow(<BulkAlert
            data={data}
            tooltipIcon={toolTipIcon}
            bulkErrorValidation={bulkErrorValidation}
            entryAnalysationDone={true}
            setEntryAnalysation={true}
            isEditing={false}
        />);

    expect(wrapper.instance().getNumberOfError()).toEqual("Uw bestand bevat 1 probleem, controleer uw data a.u.b.");
});
