import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import Submit from '../Submit';
import submitContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import Button from '../../Generic/Button';

const fn = jest.fn();
const submitComponent = shallow(
    <Submit 
        data={submitContent} 
        action={fn} 
    />);

test("Check data used in component", () => {
    expect(submitComponent.instance().props.data.item.SubmitButton).toEqual("Registratie afronden");
});

test("Anchor tag exists", () => {
    expect(submitComponent.find("a.button.submit")).toEqual(expect.anything());
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(
    <Submit 
        data={submitContent} 
        action={fn} 
    />);
    expect(tree).toMatchSnapshot();
});

test("check submit event", ()=>{
    const _submit = submitComponent.find(".submit").shallow();
    _submit.simulate("click", ()=>{
        {"test";}
    });

    expect(submitComponent.instance().props.action).toBeDefined();
});