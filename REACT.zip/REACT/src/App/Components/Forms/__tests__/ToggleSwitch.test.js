import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import ToggleSwitch from '../ToggleSwitch';
import ToggleSwitchContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import renderer from 'react-test-renderer';
import UIDGenerator from "../../../Helpers/UIDGenerator";

const fn = jest.fn();
jest.mock('uuid/v1', () => jest.fn(()=> 1));
const toggleSwitch = shallow(
    <ToggleSwitch
        data={ToggleSwitchContent}
        fnName={fn}
        setFormValues={fn}
        isSitecore={true}
        setValidationState={fn}
        isEditing={true}
        _toggleSwitchBtn={true}
    />);


test("Check data used in component", () => {
    expect(toggleSwitch.instance().props.data.item.ProjectToggleTitle).toEqual("Onderdeel van een project?");
    expect(toggleSwitch.instance().props.data.item.ProjectToggleInfo).toEqual("Wat betekent dit?");
    expect(toggleSwitch.instance().props.data.item.SwitchYesLabel).toEqual("Ja");
    expect(toggleSwitch.instance().props.data.item.SwitchNoLabel).toEqual("Nee");
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(
    <ToggleSwitch 
        data={ToggleSwitchContent}
        fnName={fn}
        setFormValues={fn}
        isSitecore={true}
        setValidationState={fn}
        isEditing={true}
    />).toJSON();
    expect(tree).toMatchSnapshot();
});

test('ToggleSwitch renders required HTML elements', () => {
    // Check if certain elements exist using CSS selectors
    const checkboxControl = toggleSwitch.find("input.switch");
    expect(checkboxControl).toEqual(expect.anything());
});

test('ToggleSwitch changes its label when switched', () => {

    const toggleControl = toggleSwitch.find('input.switch');

    expect(toggleSwitch.find(".project-label").render().html()).toBe("Nee"); //Initial text should be "Nee" at index 24

    toggleControl.simulate('change', { target: { checked: true } }); //Simulate switching

    expect(toggleSwitch.find(".project-label").render().html()).toBe("Ja");//The text should now be "Ja" at index 24
    expect(toggleSwitch.instance().props.setFormValues).toBeCalled();

});

