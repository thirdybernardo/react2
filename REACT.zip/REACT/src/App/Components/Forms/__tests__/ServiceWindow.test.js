import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import ServiceWindow from '../ServiceWindow';
import serviceWindowContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';

const serviceWindowComponent = shallow(<ServiceWindow 
                                        data={serviceWindowContent}
                                        productsResult={[]} 
                                        productsServices={[]}
                                        showPoints={true} 
                                        showServiceWindow={false} 
                                        triggerServiceWindow={jest.fn().mockReturnValue(true)}
                                        ManageProductService={jest.fn()}
                                        />
                                    );

test("Check data used in component", () => {
    expect(serviceWindowComponent.instance().props.data.item.ServiceWindowTitle).toEqual("Direct uw Onderdelen Garantie Plan regelen");
    expect(serviceWindowComponent.instance().props.data.item.ServiceBackButton).toEqual("Terug");
});

test("Something is rendered initially", () => {
    expect(serviceWindowComponent.instance().props.showServiceWindow).toEqual(false);
    expect(serviceWindowComponent.find("div.form--single-upload")).toEqual(expect.anything());
});

test('Product Services state is an empty array', () => {
    expect(serviceWindowComponent.state().productsServices.length).toEqual(0);
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(<ServiceWindow 
                                    data={serviceWindowContent}
                                    productsResult={[]} 
                                    productsServices={[]}
                                    showPoints={true} 
                                    showServiceWindow={false} 
                                    triggerServiceWindow={jest.fn().mockReturnValue(true)}
                                    ManageProductService={jest.fn()}
                                    />
                                );
    expect(tree).toMatchSnapshot();
});