import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import RegistrationProductSearch from '../RegistrationProductSearch';
import productSearchContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import renderer from 'react-test-renderer';

const productsResult = [];
const addedProducts = [];
const productSearch = shallow(<RegistrationProductSearch data={productSearchContent} productsResult={productsResult} addedProducts={addedProducts} />);

test("Check if component matches the snapshot", () => {
    const tree = renderer.create(<RegistrationProductSearch data={productSearchContent} productsResult={productsResult} addedProducts={addedProducts} />);
    expect(tree).toMatchSnapshot();
});

test("Check data used in the compoenent", () => {
    expect(productSearch.instance().props.data.item.ProductSearchTitle).toEqual("Serienummer van het product");
    expect(productSearch.instance().props.data.item.ProductSearchPlaceholder).toEqual("00 0000 0000000");
    expect(productSearch.instance().props.data.item.RemoveProduct).toEqual("Verwijder");
    expect(productSearch.instance().props.data.item.ProductLimit).toEqual("5");
    expect(productSearch.instance().props.data.item.ProductErrorMessage).toEqual("Geen product gevonden bij dit serienummer, selecteer handmatig");
    expect(productSearch.instance().props.data.item.ProductListDefault).toEqual("Select the product");
}); 