import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import RegistrationCustomerData from '../RegistrationCustomerData';
import customerDataContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import renderer from 'react-test-renderer';
import { equal } from 'assert';
import v1 from "uuid/v1";

const customerData = shallow(<RegistrationCustomerData data={customerDataContent} />);

jest.mock('uuid/v1', () => jest.fn(()=> 1));

test("Check data used in the component", () => {
    expect(customerData.instance().props.data.item.CustomerDataTermsOfAgreementDescription).toEqual("Heeft u aanvullende informatie over uw klant?");
    expect(customerData.instance().props.data.item.CustomerDataFirstName).toEqual("Voornaam");
    expect(customerData.instance().props.data.item.CustomerDataFirstNamePlaceholder).toEqual("bv. Merel");
    expect(customerData.instance().props.data.item.CustomerDataLastName).toEqual("Achternaam");
    expect(customerData.instance().props.data.item.CustomerDataLastNamePlaceholder).toEqual("bv. de Vries");
    expect(customerData.instance().props.data.item.CustomerDataTelephone).toEqual("Telefoonnummer");
    expect(customerData.instance().props.data.item.CustomerDataTelephonePlaceholder).toEqual("+31 0 000 000");
    expect(customerData.instance().props.data.item.CustomerDataEmailAddress).toEqual("E-mail adres");
    expect(customerData.instance().props.data.item.CustomerDataEmailAddressPlaceholder).toEqual("john.doe@email.com");
});

test("Check if component matches with snapshot", () => {
    const tree = renderer.create(<RegistrationCustomerData data={customerDataContent} />).toJSON();
    expect(tree).toMatchSnapshot();
});


test('Customer Data renders required HTML elements', () => {
    // Check if certain elements exist using CSS selectors
    const checkboxControl = customerData.find("input.switch");
    expect(checkboxControl).toEqual(expect.anything());
});
