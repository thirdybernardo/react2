import React, { Component } from 'react';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';
import '../../setupTest';
import ProjectSelector from '../ProjectSelector';
import ProjectSelectorContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import renderer from 'react-test-renderer';
import axios from 'axios';

describe('ProjectSelector', ()=>{
    describe('when rendered', ()=>{
        it('should fetch data', ()=>{
            const getSpy = jest.spyOn(axios, 'get');
            const projectSelector = shallow(
                <ProjectSelector data={ProjectSelectorContent} 
                    setFormValues={jest.fn()} 
                    isSitecore={false} 
                    setValidationState={jest.fn()}
                    ProjectInputMessage ={jest.fn()}
            />);
            expect(getSpy).toBeCalled();
            getSpy.mockClear();
        });
    });
});

const projectSelector = shallow(
    <ProjectSelector data={ProjectSelectorContent} 
        setFormValues={jest.fn()} 
        isSitecore={false} 
        setValidationState={jest.fn()}
        ProjectInputMessage ={jest.fn()}
    />);


describe('ProjectSelector', ()=>{
    describe('when input is changed', ()=>{
        it('match product', async ()=>{
            const _inputVal = "0239";
            const _input = projectSelector.find('input#project-selector');
            _input.simulate('change', { target: { value: _inputVal }});

            expect(projectSelector.instance().props.isSitecore).toBe(false);
            await projectSelector.instance().searchProject(_inputVal).then(data=>{
                expect(data).toBeUndefined();
            });
        });
    });
});

describe('ProjectSelector', ()=>{
    describe('when input is null', ()=>{
        it('undefined product', ()=>{
            const _input = projectSelector.find('input#project-selector');
            _input.simulate('change', { target: { value: "" }});

            expect(projectSelector.instance().props.ProjectInputMessage).toBeCalled();
            expect(projectSelector.instance().props.setValidationState).toBeCalled();
            expect(projectSelector.state().validationClass).toEqual("");
            expect(projectSelector.instance().props.setFormValues).toBeCalled();
        });
    });
});
