import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import BulkFileUpload from '../BulkFileUpload';
import bulkFileUpload from '../../../../../build/Data/json/BulkRegistrationProductFields.json';
import renderer from 'react-test-renderer';

const bulkUpload = shallow(<BulkFileUpload data={bulkFileUpload} />);

test('BulkFileUpload matches snapshot', () => {
    const tree = renderer.create(
        <BulkFileUpload data={bulkFileUpload} />).toJSON();
    expect(tree).toMatchSnapshot();
});

test('Change upload steps', () => {
    expect(bulkUpload.state().fileUploadStep).toEqual(0);
    expect(bulkUpload.find('div.columns.ul-wrapper').length).toBe(1);

    bulkUpload.instance().setState({ fileUploadStep: 1 }, () => {
        expect(bulkUpload.state().fileUploadStep).toEqual(1);
        expect(bulkUpload.find('div.columns.ul-loading-wrapper').length).toBe(1);
    });

    bulkUpload.instance().setState({ fileUploadStep: 2 }, () => {
        expect(bulkUpload.state().fileUploadStep).toEqual(2);
        expect(bulkUpload.find('div.columns.ul-successful-wrapper').length).toBe(1);
    });

    bulkUpload.instance().setState({ fileUploadStep: 3 }, () => {
        expect(bulkUpload.state().fileUploadStep).toEqual(3);
        expect(bulkUpload.find('div.columns.ul-error-wrapper').length).toBe(1);
    });
});