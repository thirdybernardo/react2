import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import renderer from 'react-test-renderer';
import Save from '../Save';
import saveContent from '../../../../../build/Data/json/BulkRegistrationProductFields.json';

const fn = jest.fn();
const saveComponent = shallow(
    <Save data={saveContent} 
        removeEntry={fn} 
        action={fn} 
        buttonClass=""
    />);

const undefinedRemove = shallow(
    <Save data={saveContent} 
        removeEntry={undefined} 
        action={fn} 
        buttonClass=""
    />);

test("Check data used in component", () => {
    expect(saveComponent.instance().props.data.item.RemoveButton).toEqual("Registratie verwijderen");
    expect(saveComponent.instance().props.data.item.SaveButton).toEqual("Wijzigingen opslaan");
});

test("Anchor tag exists", () => {
    expect(saveComponent.find("a.button.green")).toEqual(expect.anything());
    expect(saveComponent.find("a.button.hollow-red")).toEqual(expect.anything());
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(
        <Save data={saveContent} 
            removeEntry={fn} 
            action={fn} 
            buttonClass=""
        />);
    expect(tree).toMatchSnapshot();
    
});

test("Check Remove Entry component buttons", () =>{
    const removeButton = saveComponent.find("a.button.hollow-red");
    
    removeButton.simulate('click', ()=>{
        {"test value";}
    });
    expect(saveComponent.instance().props.removeEntry).toBeCalled();
});

test("Check Save Entry component buttons", () =>{
    const saveButton = saveComponent.find("a.button.green");
    saveButton.simulate('click', ()=>{
        {"test";}
    });
    expect(saveComponent.instance().props.action).toBeCalled();
});

test("check if props if undefine", ()=>{
    const removeButton = undefinedRemove.find("a.button.hollow-red");
    
    removeButton.simulate('click', ()=>{
        {"test value";}
    });

    expect(undefinedRemove.instance().props.removeEntry).toBeUndefined();
});