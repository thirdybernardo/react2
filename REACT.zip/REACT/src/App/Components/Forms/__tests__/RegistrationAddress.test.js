import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import RegistrationAddress from '../RegistrationAddress';
import addressContent from '../../../../../build/Data/json/SingleRegistrationProductFields.json';
import renderer from 'react-test-renderer';
import { equal } from 'assert';

const fn = jest.fn();
const address = shallow(
    <RegistrationAddress data={addressContent}
        setFormValues={fn}
        isEditing={undefined}
        setValidationState={fn}
        isBulk={undefined} 
        singleEntry={[]}
    />);

test("Check data used in component", () => {
    expect(address.instance().props.data.item.Title).toEqual("Voor de registratie hebben we nodig:");
    expect(address.instance().props.data.item.AddressTitle).toEqual("Postcode & huisnummer + toev.");
    expect(address.instance().props.data.item.PostcodePlaceholder).toEqual("0000 AA");
    expect(address.instance().props.data.item.HousenumberPlaceholder).toEqual("000");
    expect(address.instance().props.data.item.SuffixPlaceholder).toEqual("XX");
    expect(address.instance().props.data.item.AddressOptionsButton).toEqual("Kiezen uit leads");
    expect(address.instance().props.data.item.NotFoundValidationMessage).toEqual("Adres is onbekend. Controleer alsjeblieft of het ingevoerde adres correct is");
    expect(address.instance().props.data.item.GenericErrorMessage).toEqual("Invalid input");
});

test("Check if component matches snapshot", () => {
    const tree = renderer.create(
    <RegistrationAddress data={addressContent}
        setFormValues={fn}
        isEditing={undefined}
        setValidationState={fn}
        isBulk={undefined} 
        singleEntry={[]}
    />);
    expect(tree).toMatchSnapshot();
});

test("Renders 2 input tag", () => {
    expect(address.find("input")).toHaveLength(2);
});

test("Renders 1 anchor tag", () => {
    expect(address.find("a")).toHaveLength((0));
});

