import React from 'react';
import moment from 'moment';
import Pagination from '../Generic/Pagination';
import Button from '../Generic/Button';

class TileListTable extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            paginationOptions: {
                currentPagination: 1,
                targetPagination: 1,
                totalPagination: 0,
                resultKeysCount: 0
            },
            paginationSlicesFallback: 1
        };
    }

    componentDidUpdate(prevProps) {
        if (prevProps.refinedMyProducts.length != this.props.refinedMyProducts.length || prevProps.paginationSlice != this.props.paginationSlice) {
            let _data = [...this.props.refinedMyProducts];
            let _slice = this.props.paginationSlice <= 0 ? this.state.paginationSlicesFallback : this.props.paginationSlice;
            let _totalP = (_data.length / _slice);
            _totalP = (_totalP % 1).toFixed(1).substring(2) != 0 ? Math.floor(_totalP) + 1 : _totalP;
            this.updatePaginationOptions(["resultKeysCount:" + _data.length, "totalPagination:" + _totalP, "currentPagination:" + 1]);
        }
    }

    getDateText = () => {
        let _return = "";
        if (this.props.data.item.DatePickerLocale) {
            let _locale = this.props.data.item.DatePickerLocale;
            let _dateRange = this.props.dateRange;
            let _startDate = moment(new Date(_dateRange.startDate)).locale(_locale);
            let _endDate = moment(new Date(_dateRange.endDate)).locale(_locale);
            _return = `${_startDate.format('D')} ${_startDate.format('MMMM')} - ${_endDate.format('D')} ${_endDate.format('MMMM')} ${_endDate.format('YYYY')}`;
        }
        return _return;
    }

    getDateWeekMonthNum = () => {
        let _return = "";
        if (this.props.data.item.DatePickerLocale) {
            let _locale = this.props.data.item.DatePickerLocale;
            let _dateRange = this.props.dateRange;
            let _startDate = moment(new Date(_dateRange.startDate)).locale(_locale);
            _return = this.props.isTileView ? `${this.props.data.item.TableWeekText} ${_startDate.format('W')} ` : `${this.props.data.item.TableMonthText} ${_startDate.format('M')} `;
        }
        return _return;
    }

    triggerSettleNowButton = (e, val) => {
        this.props.manageRegistration(val);
    }

    updatePaginationOptions = (newParams) => {        
        let paginationOptionsCopy = Object.assign({}, this.state.paginationOptions);
        newParams.forEach((val, index)=>{
            let thisVal = String(val).split(":");
            paginationOptionsCopy[thisVal[0]] = thisVal[1];
        });        
        this.setState({ paginationOptions: paginationOptionsCopy });
    }

    renderListView = () => {
        let _return = "";
        let _entries = [];
        if (Object.keys(this.props.data.item).length > 0) {
            this.props.refinedMyProducts.forEach((val, i) => {
                if (i < (this.props.paginationSlice * this.state.paginationOptions.currentPagination) && i >= (this.props.paginationSlice * (this.state.paginationOptions.currentPagination-1))){
                    let _pointsPrefix = parseInt(val.Points) == 0 ? (<i className="fa fa-warning"></i>) : "+";
                    let _ogpText = ""

                    if(val.Product.WarrantyEnabled === 1) {
                        if(!val.Product.ServiceName || (val.Product && val.Product.WarrantyStatus.toLowerCase() === "disapproved"))
                            _ogpText = this.props.data.item.NoOGPText
                        else
                            _ogpText = val.Product.ServiceName
                    }else
                        _ogpText = this.props.data.item.NotOGPEligibleText

                    _entries.push(
                        <div className={"product-table--list-fields " + (typeof _pointsPrefix == 'string' ? "" : "red-box")} key={i}>
                            <div className="list-entry list--date">
                                <p>{moment(new Date(val.InstallationDate)).locale(this.props.data.item.DatePickerLocale).format('DD-MM-YYYY')}</p>
                            </div>
                            <div className="list-entry list--location">
                                <div className="list--location-box">
                                    <h4 className="product-table--house-num">{val.City},&nbsp;{val.PostalCode}</h4>
                                </div>
                                <p className="product-table--address">
                                    <span>{val.StreetName} {val.HouseNumber}</span>
                                    <br />
                                    <span>{val.Firstname} {val.Lastname}</span>
                                </p>
                            </div>
                            <div className="list-entry list--product">
                                <div className="product-image">
                                    <img src={val.imageSource} />
                                    <span className="floating-points">
                                        {_pointsPrefix}{val.Points}
                                    </span>
                                </div>
                                <div className="product-details">
                                    <h3 className="product-table--product-title">{val.Product.Name}</h3>
                                    <p className="product-table--serial-number">{val.Product.ProductId}</p>
                                    <p className="product-table--house-num show-for-small-only">{val.City},&nbsp;{val.PostalCode}</p>
                                </div>
                            </div>
                            <div className="list-entry list--ogp">
                                <div className="list-OGP-box">
                                    <p className="product-table--ogp-enable">{_ogpText}</p>
                                    <a href="javascript:void(0)" className="button" onClick={event => this.triggerSettleNowButton(event, val)}><span>{this.props.data.item.SettleNowButtonText}</span></a>
                                </div>
                            </div>
                        </div>
                    );
                }
            });
        }
        _return = (
            <div className="product-table--list active">
                <div className="product-table--list-box">
                    <div className="product-table--list-header hide-for-small">
                        <div className="list-entry list--date">
                            <span dangerouslySetInnerHTML={{ __html: this.props.data.item.TableListViewDateHeader }} />
                        </div>
                        <div className="list-entry list--location">
                            <span dangerouslySetInnerHTML={{ __html: this.props.data.item.TableListViewAddressHeader }} />
                        </div>
                        <div className="list-entry list--product">
                            <span dangerouslySetInnerHTML={{ __html: this.props.data.item.TableListViewProductHeader }} />
                        </div>
                        <div className="list-entry list--ogp">
                            <span dangerouslySetInnerHTML={{ __html: this.props.data.item.TableListViewOGPHeader }} />
                        </div>
                    </div>
                    {_entries}                    
                </div>
            </div>
        );
        return _return;
    }

    renderTileView = () => {
        let _return = "";
        let _entries = [];
        if (Object.keys(this.props.data.item).length > 0) {
            this.props.refinedMyProducts.forEach((val, i) => {
                if (i < (this.props.paginationSlice * this.state.paginationOptions.currentPagination) && i >= (this.props.paginationSlice * (this.state.paginationOptions.currentPagination-1))) {
                    let _pointsPrefix = parseInt(val.Points) == 0 ? (<i className="fa fa-warning"></i>) : "+";
                    let _ogpText = val.Product.WarrantyEnabled === 1 ? (!val.Product.ServiceName ? this.props.data.item.NoOGPText : val.Product.ServiceName) : this.props.data.item.NotOGPEligibleText;
                    _entries.push(
                        <div className={"product-table--tile-box " + (typeof _pointsPrefix == 'string' ? "" : "red-box")} key={i}>
                            <div className="product-table--day">
                                <p>{moment(new Date(val.InstallationDate)).locale(this.props.data.item.DatePickerLocale).format('dddd DD MMMM YYYY')}</p>
                            </div>
                            <div className="product-table--content">
                                <div className="product-table--address-underline">
                                    <h4 className="product-table--house-num">{val.City},&nbsp;{val.PostalCode}</h4>
                                    <span className="floating-points">
                                        {_pointsPrefix}{val.Points}
                                    </span>
                                </div>
                                <p className="product-table--address addheight">
                                    <span>{val.StreetName} {val.HouseNumber}</span>
                                    <br />
                                    <span>{val.Firstname} {val.Lastname}</span>
                                </p>
                                <p className="product-image">
                                    <img src={val.imageSource} />
                                </p>
                                <h3 className="product-table--product-title">{val.Product.Name}</h3>
                                <p className="product-table--serial-number">{val.Product.ProductId}</p>
                                <p className="product-table--ogp-enable">{_ogpText}</p>
                                <a href="javascript:void(0)" className="button" onClick={event => this.triggerSettleNowButton(event, val)}><span>{this.props.data.item.SettleNowButtonText}</span></a>
                            </div>
                        </div>
                    );
                }
            });
        }
        _return = (
            <div className="product-table--tile active">
                {_entries}  
            </div>
        );
        return _return;
    }

    renderPagination = () => {
        let _return = "";
        if (this.props.isMobile) {
            if (this.props.refinedMyProducts.length > 3 && this.props.refinedMyProducts.length !== this.props.paginationSlice) {
                _return = <Button callback={this.props.displayAllProducts} className="button button-clear-bg" noWrapper={true} text={"Alle Tonnen (" + this.props.refinedMyProducts.length + ")"}/>;
            }
        }
        else {
            _return = <Pagination data={this.props.data} paginationOptions={this.state.paginationOptions} updatePaginationOptions={this.updatePaginationOptions}/>;
        }
        return _return;
    }

    render() {
        let _table = !this.props.isTileView ? this.renderListView() : this.renderTileView();
        return (
            <div className={this.props.wrapperClass}>
                <div className="product-table--title">
                    <h5 className="product-table--week-title">
                        <a href="javascript:void(0)" className="product-week-previous" onClick={(event) => this.props.getPrevWeek(event)}></a>
                        <span className="week--number">{this.getDateWeekMonthNum()}</span>
                        <span className="week--range">{this.getDateText()}</span>
                        <a href="javascript:void(0)" className="product-week-next" onClick={(event) => this.props.getNextWeek(event)}></a>
                    </h5>
                    <p className="product-table--week-subtitle">{`${this.props.refinedMyProducts.length} ${this.props.data.item.TableTotalText}`}</p>
                </div>
                <div className="table-container">
                    {_table}
                </div>
                {this.renderPagination()}
            </div>
        );
    }

}

module.exports = TileListTable;