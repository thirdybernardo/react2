import React from 'react';
import Modal from '../Generic/Modal';
import Button from '../Generic/Button';
import ErrorReportModalContent from './ErrorReportModalContent';

class ErrorReport extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            modalCloseId: null,
            modalType: null,
            closeEvent: null,
            isVisible: false
        },
            this.preModalType = "ErrorForm",
            this.knownProductModalType = "ErrorForm2";
            this.successType = "SuccessModal";
    }

    componentDidMount() {
        if (this.props.params) {
            this.setState({ isVisible: true });
            if (this.props.params.closeId)
                this.setState({ modalCloseId: this.props.params.closeId });
            if (this.props.params.closeEvent)
                this.setState({ closeEvent: this.props.params.closeEvent });
        }
        else if (this.props.data.item.IsStandaloneModal == 1){
            this.setState({
                closeEvent: (() => {
                    this.setState(function (prevState) {
                        return { isVisible: false };
                    });
                }),
                modalCloseId: this.successType
            });        
        }
        this.setState({ modalType: (this.props.data.item.PreModalEnabled ? this.preModalType : this.knownProductModalType) });
    }

    renderModalContent = (resetTopScroll) => {
        return (
            <ErrorReportModalContent
                data={this.props.data}
                isSitecore={this.props.isSitecore}
                isEditing={this.props.isEditing}
                preModal={this.props.preModal ? this.props.preModal : (this.props.data.item.PreModalEnabled == 1 ? true : false)}
                callback={this.changeModalType}
                closeEvent={this.state.closeEvent}
                closeId={this.state.modalCloseId}
                resetTopScroll={resetTopScroll}
                params={{
                    preModalType: this.preModalType,
                    knownProductModalType: this.knownProductModalType,
                    SuccessModalType: this.successType,
                    returnToProductInfo: this.props.params ? this.props.params.returnToProductInfo : () => {/*Empty FUnction*/ },
                    productContext: this.props.params ? this.props.params.productContext : undefined,
                }}
            />
        );
    }

    changeModalType = (val, callback) => {
        this.setState({ modalType: val }, () => {
            if (callback)
                callback();
        });
    }

    render() {
        let _button = this.props.data.item.IsStandaloneModal == 1
            ? <Button
                noWrapper={true}
                className={this.props.data.item.StandaloneModalButtonClass}
                text={this.props.data.item.StandaloneModalButtonTitle}
                callback={(event) => {
                    event.stopPropagation();
                    this.setState(function (prevState) {
                        return { isVisible: prevState.isVisible ? false : true };
                    });
                }}
            />
            : undefined;
        return (
            <React.Fragment>
                {_button}
                {this.state.isVisible ?
                    <Modal
                        data={this.props.data}
                        closeEvent={this.state.closeEvent}
                        closeId={this.state.modalCloseId}
                        type={this.state.modalType}
                        noModalContentClass={this.state.modalType == this.successType ? true : undefined}
                        wrapperClass={this.state.modalType == this.knownProductModalType ? "cold-flow-reporting" : undefined}
                        modalContent={this.renderModalContent} />
                    : undefined
                }
            </React.Fragment>
        );
    }
}

module.exports = ErrorReport;