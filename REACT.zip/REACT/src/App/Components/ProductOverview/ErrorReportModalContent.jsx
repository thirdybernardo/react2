import React from 'react';
import ErrorReports from '../../API/ErrorReports';
import Products from '../../API/Products';
import SearchHelper from '../../Helpers/SearchHelper';
import SitecoreHelper from '../../Helpers/SitecoreHelper';
import DisplayHelper from '../../Helpers/DisplayHelper';
import QueryString from '../../Data/QueryString';
import ProductRegistrationsList from '../Generic/Lists/ProductRegistrationsList';
import Button from '../Generic/Button';
import ToggleInput from '../Generic/ToggleInput';
import TextInput from '../Generic/TextInput';
import RadioInput from '../Generic/RadioInput';
import MaskedInput from 'react-text-mask';
import DatePicker from '../Generic/DatePicker';
import CustomDroplist from '../Generic/CustomDroplist';
import AddressInput from '../Generic/Forms/AddressInput';
import ProductCategoryHelper from "../../Helpers/ProductCategoryHelper";
import Data from '../../Data/Data';
import moment from 'moment';
import { isNullOrUndefined, isUndefined } from 'util';

class ErrorReportModalContent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isInitialized: false,
            modalStep: 0,
            hasResult: false,
            popManualSearch: false,
            myProducts: [],
            productList: [],
            manualSearch: {
                productResult: null,
                showNoResult: false,
                droplistSelected: null,
                invalidDroplistSelected: false,
                myRegisteredProduct: null
            },
            refinedMyProducts: [],
            productContext: null,
            faultIndications: [],
            faultSwitchOn: true,
            emailSwitchOn: true,
            locationVisitedSwitchOn: true,
            isFormValid: false,
            isUnknownSerial: false,
            formValues: {
                ProductId: null,
                ProductRegistration: null,
                Product: null,
                FaultIndication: [],
                DateVisited: new Date(),
                FailureDate: null,
                OrderNumber: null,
                FaultDescription: "",
                WorkDoneDescription: "",
                WarrantyAgreementAccepted: false,
                JoinRemehaServiceAccepted: false,
                AllowClientVisitNotificationAccepted: false,
                PostalCode: "",
                HouseNumber: "",
                StreetName: "",
                City: "",
                Salutation: "",
                Firstname: "",
                Lastname: "",
                TelephoneNo: "",
                EmailAddress: ""
            },
            browserWidth: 1920 // Temporary value for server processing, will be overridden when rendered on browser
        }
        this.YesLabel = "Ja";
        this.NoLabel = "Nee";
        this.maxListSize = 15;
        this.errorFormSearch = React.createRef();
        this.errorFormTerms = React.createRef();
        this.errorFormTerms2 = React.createRef();
        this.joinRemehaService = React.createRef();
        this.joinRemehaService2 = React.createRef();
        this.allowClientVisitNotification = React.createRef();
        this.allowClientVisitNotification2 = React.createRef();
        this.storingscodeInput = React.createRef();
        this.locatiegeweestInput = React.createRef();
        this.orderNumberInput = React.createRef();
        this.workDoneInput = React.createRef();
        this.postCodeInput = React.createRef();
        this.housenumberInput = React.createRef();
        this.serialNumberInput = React.createRef();
        this.salutationOption = React.createRef();
        this.firstnameInput = React.createRef();
        this.lastnameInput = React.createRef();
        this.telephoneInput = React.createRef();
        this.emailInput = React.createRef();
        this.serialReentryInput = React.createRef();
        this.emailSwitch = React.createRef();
        this.enums = {
            searchInput: "searchInput",
            storingscodeInput: "storingscodeInput",
            locatiegeweest: "locatiegeweest",
            orderNumberInput: "orderNumberInput",
            workDoneInput: "workDoneInput",
            errorFormTerms: "errorFormTerms",
            postCodeInput: "PostalCode",
            housenumberInput: "HouseNumber",
            serialNumberInput: "serial-number-input",
            salutationOption: "salution-option",
            firstnameInput: "customer-first-name",
            lastnameInput: "customer-last-name",
            telephoneInput: "customer-telefon",
            emailInput: "customer-email",
            emailSwitch: "email-switch",
            invalidInput: "<<invalid-input>>",
            mobileWidth: 639
        }
        this._mask = [/[0-9]/, /[0-9]/, ' ',
            /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, ' ',
            /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/];
    }

    componentDidMount() {     
        this.setState({ browserWidth: window.outerWidth})
        if (!this.props.preModal)
            this.setState({ modalStep: 1 });
        if (!this.props.isSitecore) {
            if (this.props.preModal) {
                this.initializeReactStandaloneProducts();
            }
            Data.getData("MockFaultIndications", (data) => {
                this.setState({ faultIndications: data.Results });
            });
            Data.getData("MockProductItems", data => {
                let _activeProductsOnly = data.Products.filter((v) => { return !v.Disabled; });
                this.setState({ productList: _activeProductsOnly });
            });
        }
        else {
            let _data = { installerId: QueryString.getValue("installerid") };
            ErrorReports.GetFaultDescriptions(_data, (data) => {
                if (data.Results)
                    this.setState({ faultIndications: data.Results }, () => {
                        this.setState({ isInitialized: true });
                    });
                else
                    this.setState({ isInitialized: true });
            });
            Products.GetProducts(_data, (_result) => {
                if (_result) {
                    let _activeProductsOnly = _result.filter((v) => { return !v.Disabled; });
                    this.setState({ productList: _activeProductsOnly });
                }
            });
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (!this.state.isInitialized && this.state.modalStep != prevState.modalStep) {
            // Set ProductRegistration for Product Flow
            if (this.state.modalStep == 1) {
                this.setFormValues("ProductRegistration", this.props.params.productContext.Product.ProductId);
            }
            //Set ProductId for Manual Product Flow
            else {
                if (prevState.modalStep == 1) {
                    this.initializeReactStandaloneProducts();
                }
                this.setFormValues("ProductId", this.props.params.productContext ? this.props.params.productContext.Product.ProductId : null);
            }
        }
        if (prevState.modalStep == 0 && this.state.modalStep == 2) {
            // Unknown product manual flow
            this.setFormValues("FailureDate", new Date()); // FailureDate field doesn't exist on product known flow and is null at start, set it on unknown product flow
        }
        if (prevState.modalStep != this.state.modalStep) {
            this.props.resetTopScroll();
        }
    }

    initializeReactStandaloneProducts = () => {
        if (!this.props.isSitecore) {
            Data.getData("MockInstallerRegisteredProducts", (data) => {
                this.setState({
                    myProducts: data.Registered,
                    refinedMyProducts: data.Registered
                }, () => {
                    this.handleSearch(this.state.searchKeyword, () => {
                        this.setState({ isInitialized: true });
                    });
                });
            });
        }
    }

    setFormValues = (key, val, callback) => {
        this.setState(function (prevState) {
            if (!isUndefined(prevState.formValues[key]))
                prevState.formValues[key] = val;
            return { formValues: prevState.formValues };
        }, () => {
                if (val && String(val).toLowerCase() == this.enums.invalidInput.toLowerCase())
                    this.setState({ isFormValid: false });
                else
                    this.validateForm(callback);
        });
    }

    validateForm = (callback) => {
        //Validation of formValues
        let _isValid = false;
        let _state = {...this.state.formValues};
        let _validFaultDescription = false;
        let _validReference = false;
        if (this.state.faultSwitchOn && _state.FaultDescription != "")
            _validFaultDescription = true;
        else if (!this.state.faultSwitchOn)
            _validFaultDescription = true;
        if (_state.ProductId != null || _state.ProductRegistration != null)
            _validReference = true;
        if (_state.FaultIndication.length > 0 && _validReference != "" && _state.WorkDoneDescription != ""
            && _state.WarrantyAgreementAccepted
            && _validFaultDescription) {
            _isValid = true;
        }
        if (_state.WorkDoneDescription.length < 10 || (this.state.faultSwitchOn && _state.FaultDescription < 2))
            _isValid = false;
        if (this.props.data.item.IsStandaloneModal && this.state.modalStep != 1) {
            if (this.state.isUnknownSerial && !_state.Product) {
                _isValid = false;
            }
            if (!_state.PostalCode || !_state.HouseNumber) {
                _isValid = false;
            }
            if (this.state.manualSearch.myRegisteredProduct && !_state.ProductRegistration)
                _isValid = false;
            else if (!this.state.manualSearch.myRegisteredProduct && (!_state.Salutation || !_state.TelephoneNo))  {
                _isValid = false;
            }
        }
        this.setState({ isFormValid: _isValid }, () => {
            if (callback)
                callback();
        });
    }

    handleSearch = (val, callback) => {
        let _return = [...this.state.myProducts];
        let _query = "";
        let _minChar = parseInt(this.props.data.item.ReportSearchMinCharacters) ? this.props.data.item.ReportSearchMinCharacters : 3;
        if (val === null || val === undefined)
            _query = this.errorFormSearch.current.value;
        else if (val.target)
            _query = val.target.value;
        else
            _query = val;
        let _minCharReaced = _query.length >= _minChar;
        if (_minCharReaced) {
            if (!this.props.isSitecore) {
                _return = [...this.state.myProducts].filter((val) => {
                    return ((String(val.Product.ProductId).toLowerCase().includes(String(_query).toLowerCase())
                        || String(val.Product.Name).toLowerCase().includes(String(_query).toLowerCase())) && !val.IsDisabled)
                })
                this.setState({ refinedMyProducts: _return }, () => {
                    if (this.state.isInitialized)
                        this.setState({ hasResult: (_query != "" && _minCharReaced && _return.length > 0) ? true : false });
                    if (callback)
                        callback();
                });
            }
            else {
                //Sitecore - call api for search
                let _installerId = QueryString.getValue('installerid');
                let _startD = undefined;
                let _endD = undefined;
                SearchHelper.getRegistrations(_installerId, _query, _startD, _endD, (data) => {
                    _return = (data.Results.length > 0) ? data.Results.filter(x=>x.IsDisabled == false) : data.Results;
                    if (_return) {
                        this.setState({
                            myProducts: _return,
                            refinedMyProducts: _return
                        });
                    }
                    if (this.state.isInitialized)
                        this.setState({ hasResult: (_query != "" && _minCharReaced && _return.length > 0) ? true : false });
                    if (callback)
                        callback();
                });
            }
        }
        else {
            if (this.props.isSitecore) {
                // Reset the array fields when in Sitecore to display empty results while a search is in progress
                this.setState({
                    myProducts: [],
                    refinedMyProducts: []
                });
            }
            this.setState({ hasResult: false }, () => {
                if (callback)
                    callback();
            });
        }
    }

    resetPreModalStates = () => {
        let _products = [];
        if (!this.isSitecore)
            _products = [...this.state.myProducts];
        //else
        //Apply here reseting products list in respect to API
        this.setState({
            refinedMyProducts: _products,
            hasResult: false,
            productContext: null
        });
    }

    resetFormValues = () => {
        this.setState({
            formValues: {
                ProductId: "",
                ProductRegistration: null,
                Product: null,
                FaultIndication: [],
                DateVisited: new Date(),
                FailureDate: null,
                OrderNumber: null,
                FaultDescription: "",
                WorkDoneDescription: "",
                WarrantyAgreementAccepted: false,
                JoinRemehaServiceAccepted: false,
                AllowClientVisitNotificationAccepted: false,
                PostalCode: "",
                HouseNumber: "",
                StreetName: "",
                City: "",
                Salutation: "",
                Firstname: "",
                Lastname: "",
                TelephoneNo: "",
                EmailAddress: ""
            },
            isUnknownSerial: false
        });
    }

    resetManualSearch = (e, resetStateOnly) => {
        if (!resetStateOnly) {
            this.serialNumberInput.current.inputElement.value = "";
        }
        if (this.state.manualSearch.myRegisteredProduct) {
            DisplayHelper.ChangeInputElemValueProgramatically(this.postCodeInput, "");
            DisplayHelper.ChangeInputElemValueProgramatically(this.housenumberInput, "");
            this.setFormValues("Salutation", "");
            DisplayHelper.ChangeInputElemValueProgramatically(this.firstnameInput, "");
            DisplayHelper.ChangeInputElemValueProgramatically(this.lastnameInput, "");
            DisplayHelper.ChangeInputElemValueProgramatically(this.telephoneInput, "");
            DisplayHelper.ChangeInputElemValueProgramatically(this.emailInput, "");
            this.setFormValues("PostalCode", "");
            this.setFormValues("HouseNumber", "");
            this.setFormValues("StreetName", "");
            this.setFormValues("City", "");
        }
        this.setFormValues("ProductRegistration", null);
        this.setFormValues("ProductId", null);
        this.setFormValues("Product", null);
        this.setState(function (prevState) {
            prevState.manualSearch.productResult = null;
            prevState.manualSearch.showNoResult = false;
            prevState.manualSearch.droplistSelected = null;
            prevState.manualSearch.invalidDroplistSelected = false;
            prevState.manualSearch.myRegisteredProduct = null;
            return { manualSearch: prevState.manualSearch, isUnknownSerial: false };
        });
    }

    selectProductRegistration = (event, data) => {
        this.setState({ productContext: data }, () => {
            this.setFormValues("ProductId", data.Product.ProductId);
            if (this.props.callback && this.props.params.knownProductModalType)
                this.props.callback(this.props.params.knownProductModalType);
            this.setState(function (prevState) {
                return { modalStep: prevState.modalStep + 1 };
            });
        });
    }

    selectReportManually = (event) => {
        event.preventDefault();
        this.setState(function (prevState) {
            return { modalStep: prevState.modalStep + 2 };
        });
    }

    returnToPreModal = () => {
        if (this.props.callback && this.props.params.preModalType) {
            this.setState(function (prevState) {
                return { modalStep: 0 };
            }, () => {
                this.resetPreModalStates();
                this.props.callback(this.props.params.preModalType);
            });
        }
    }

    selectFault = (e, fault, ref) => {
        if (fault) {
            this.setState(function (prevState) {
                if (ref.current.checked) {
                    let _faultIndications = {};
                    _faultIndications = prevState.formValues.FaultIndication.filter((val) => {
                        return val != fault.FaultId;
                    });
                    ref.current.checked = false;
                    prevState.formValues.FaultIndication = _faultIndications;
                }
                else {
                    prevState.formValues.FaultIndication.push(fault.FaultId);
                    ref.current.checked = true;
                }
                return { formValues: prevState.formValues };
            }, () => {
                this.validateForm();
            });
        }
    }

    submitErrorReport = () => {
        let _data = {
            "InstallerId": QueryString.getValue("installerid"),
            "Product": this.state.formValues.Product,
            "ProductId": this.state.formValues.ProductId,
            "ProductRegistration": this.state.formValues.ProductRegistration,
            "FaultIndication": this.state.formValues.FaultIndication,
            "FaultDescription": this.state.formValues.FaultDescription,
            "WorkDoneDescription": this.state.formValues.WorkDoneDescription,
            "DateVisited": this.state.formValues.DateVisited,
            "FailureDate": this.state.formValues.FailureDate,
            "OrderNumber": this.state.formValues.OrderNumber,
            "JoinRemehaService": this.state.formValues.JoinRemehaServiceAccepted,
            "AllowClientVisitNotification": this.state.formValues.AllowClientVisitNotificationAccepted,
            "AgreeToWarrantyTerms": this.state.formValues.WarrantyAgreementAccepted,
            "CustomerInfo": {
                "PostalCode": this.state.formValues.PostalCode,
                "HouseNumber": this.state.formValues.HouseNumber,
                "StreetName": this.state.formValues.StreetName,
                "City": this.state.formValues.City,
                "Salutation": this.state.formValues.Salutation,
                "Firstname": this.state.formValues.Firstname,
                "Lastname": this.state.formValues.Lastname,
                "TelephoneNo": this.state.formValues.TelephoneNo,
                "EmailAddress": this.state.formValues.EmailAddress
            }
        };
        ErrorReports.CreateProductErrorReport(_data, (response) => {
            if (response == 200) {
                this.props.callback(this.props.params.SuccessModalType, () => {
                    this.setState({ modalStep: 3 });    
                });            
            }
            else
                alert("Something went wrong on our end. Please try again later!");
        });
    }

    getFaultIndications = () => {
        return this.state.faultIndications.map((val, i) => {
            let _faultRef = `faultIndicator${i}`;
            if (this[_faultRef])
                this[_faultRef] = undefined;
            this[_faultRef] = React.createRef();
            return (
                <div key={i}>
                    <label className="checkbox-wrapper" htmlFor="geen-cv" onClick={event => this.selectFault(event, val, this[_faultRef])}>
                        <input type="checkbox" name="storing" id={`geen-cv${i}`} value="geenCV" ref={this[_faultRef]} />
                        <span>{val.Title}</span>
                    </label>
                </div>
            );
        });
    }

    renderPreModal = () => {
        let _minChar = parseInt(this.props.data.item.ReportSearchMinCharacters) ? this.props.data.item.ReportSearchMinCharacters : 3;
        return (
            <React.Fragment>
                <div className="container error-title">
                    <h4 className="malfunction" dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportErrorTitle }} />
                </div>
                <div className="container light-blue-bg">
                    <h4 className="arrowright" dangerouslySetInnerHTML={{ __html: this.props.data.item.CallUsTitle }} />
                    <p dangerouslySetInnerHTML={{ __html: this.props.data.item.CallUsContent }} />
                    <div className="button-wrapper">
                        <a href={!this.props.data.item.CallUsButtonLabel /*|| this.state.browserWidth > this.enums.mobileWidth*/ ? "" : `tel:+${this.props.data.item.CallUsButtonLabel.match(/\d+/g).map(Number)[0]}`} className="button call" dangerouslySetInnerHTML={{ __html: this.props.data.item.CallUsButtonLabel }} />
                    </div>
                </div>
                <div className="container">
                    <h4 className="arrowright" dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportTitle }} />
                    <p dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportContent }} />
                    <div className={"search-modal " + (this.errorFormSearch.current ? (this.errorFormSearch.current.value.length >= _minChar ? "popsearch" : "") : "")}>
                        <div className="overlay"></div>
                        <div className="empty-box"></div>
                        <div className="search-group">
                            {
                                this.state.modalStep != 3 ?
                                    <div className="close mobile" onClick={event => {
                                        this.setState({ hasResult: false });
                                        this.errorFormSearch.current.value = "";
                                        if (this.props.closeEvent)
                                            this.props.closeEvent(); // No close id needed on manual flow
                                    }}>
                                    </div>
                                    : undefined
                            }
                            <div className="error--search">
                                <label>
                                    <span dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportSearchTitle }} />
                                </label>
                                <div className="search-wrapper">
                                    <TextInput
                                        id={this.enums.searchInput}
                                        placeholder={SitecoreHelper.getPlaceholderText(this.props.isEditing, this.props.data.item.ReportSearchPlaceholder)}
                                        refData={this.errorFormSearch}
                                        callback={(_id, _val) => { this.handleSearch(_val); }}
                                        keyUp={(event) => { event.keyCode == 13 ? (this.handleSearch(event)) : undefined; }}
                                    />
                                </div>
                            </div>
                            <div className="search-result">
                                <div className={"no-result " + (this.state.hasResult ? "hide" : "")}>
                                    <div className="search-not-found">
                                        <p><span dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportSearchNoResultLabel }} />&nbsp;<span className="search-string">{`“${this.errorFormSearch.current ? this.errorFormSearch.current.value : ""}”`}</span></p>
                                    </div>
                                    <p dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportManuallyContent }} />
                                    <div className="button-wrapper">
                                        <a href=""
                                            className="button arrow-right"
                                            dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportManuallyButtonLabel }}
                                            onClick={event => this.selectReportManually(event)}
                                        />
                                    </div>
                                </div>
                                <div className={"result-found " + (this.state.hasResult ? "" : "hide")}>
                                    <ProductRegistrationsList
                                        isInitialized={this.state.isInitialized}
                                        isSitecore={this.props.isSitecore}
                                        list={this.state.refinedMyProducts}
                                        listSize={this.maxListSize}
                                        type={2}
                                        callback={this.selectProductRegistration}
                                    >
                                        <Button
                                            text={this.props.data.item.SelectButtonLabel}
                                            wrapperClassName="button-wrapper"
                                            className="button select"
                                        />
                                    </ProductRegistrationsList>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }

    replaceTokens = (field, token, tokenValue) => {
        if(!this.props.isEditing && field != undefined)
            return field.replace(token, tokenValue);

        return field;
    }

    renderKnownProduct = () => {
        let _title = "", _img = null, _return = null, _context = null;
        if (this.props.preModal) {
            _title = this.props.data.item.ProductFoundTitle;
            _return = this.returnToPreModal;
            _context = this.state.productContext;
        }
        else {
            _title = this.props.data.item.ReportAFault;
            _return = this.props.params.returnToProductInfo;
            _context = this.props.params.productContext;
        }
        let _faultIndications = this.getFaultIndications();
        return (
            <React.Fragment>
                <div className="cold-flow-reporting">
                    <div className="modal--content-back">
                        <a
                            href="javascript:void(0)"
                            dangerouslySetInnerHTML={{ __html: _title }}
                            onClick={event => {
                                this.setFormValues("ProductId", "");
                                this.resetFormValues();
                                _return();
                            }}
                        />
                    </div>
                    {
                        // Render this modal header on 'Manual Flow - Known Product' when the isPremodalEnabled is checked
                        this.props.data.item.PreModalEnabled == 1 ?
                            <div className="modal--content-header">
                                <span dangerouslySetInnerHTML={{ __html: this.props.data.item.SelectDifferentProductTitle }} />
                            </div>
                            : undefined
                    }
                    <div className="row border-bottom">
                        <div className="modal--content-image">
                            <img src={_context.imageSource} alt="productimage" />
                        </div>
                        <div className="modal--content-main">
                            <div className="modal--content-main-section padding-top-40 padding-bottom">
                                <div className="contextual-title-bold main-title">{_context.Product.Name}</div>
                                <div className="padding-bottom border-bottom">
                                    <p><b dangerouslySetInnerHTML={{ __html: `${this.props.data.item.SerialNumber}:` }} /> {_context.Product.ProductId}</p>
                                    <p><b dangerouslySetInnerHTML={{ __html: `${this.props.data.item.InstalledOn}:` }} /> {moment(_context.InstallationDate).locale(this.props.data.item.locale ? this.props.data.item.locale : "nl").format("dddd DD MMMM YYYY")}</p>
                                </div>
                                <div className="modal--content-section">
                                    <h4 dangerouslySetInnerHTML={{ __html: this.props.data.item.PostedAtLabel }} />
                                    <div className="margin-bottom">
                                        <p><b>{`${_context.Firstname} ${_context.Lastname}`}</b></p>
                                        <p>{`${_context.StreetName} ${_context.HouseNumber}, ${_context.PostalCode.toUpperCase()} ${_context.City}`}</p>
                                    </div>
                                    <div className="margin-bottom-20">
                                        <h4 dangerouslySetInnerHTML={{ __html: this.props.data.item.Guarantee }} />
                                        <div>
                                            <p>{(moment(_context.Product.WarrantyEndDate).locale(this.props.data.item.locale ? this.props.data.item.locale : "nl").format("D MMMM YYYY")) + (`, ${this.props.data.item.FactoryWarranty}: ${this.replaceTokens(this.props.data.item.GuaranteePlan, "$(guaranteeplan)", String(_context.Product.WarrantyPeriod))}`)}
                                            </p>
                                        </div>
                                    </div>
                                    <div className={"warranty-message error " + ((_context.Product.ServiceId && _context.Product.WarrantyStatus.toLowerCase() != "disapproved") ? "hide" : "")}>
                                        <p dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportSearchNoOGPMessage }} />
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div className="modal--content-main-section padding-top-30 ">
                                <h2 dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportAFault }} />
                                <div className="form-group">
                                    <p dangerouslySetInnerHTML={{ __html: this.props.data.item.FaultIndicationTitle }} />
                                    <div className="checkbox-selection">
                                        {_faultIndications}
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="switch-selection-horizontal">
                                        <label className="text-label" htmlFor="locatiegeweest" dangerouslySetInnerHTML={{ __html: this.props.data.item.LocationVisitedTitle }} />
                                        <ToggleInput
                                            id="locatiegeweest"
                                            wrapperClassName="switch-wrapper"
                                            switchYesLabel={this.props.data.item.SwitchYesLabel}
                                            switchNoLabel={this.props.data.item.SwitchNoLabel}
                                            callback={(_id, _val) => {
                                                this.setState({ locationVisitedSwitchOn: _val }, () => {
                                                    if (!_val) {
                                                        this.setFormValues("DateVisited", null);
                                                    }
                                                    else {
                                                        this.setFormValues("DateVisited", new Date());
                                                    }
                                                });
                                            }}
                                            defaultChecked={this.state.locationVisitedSwitchOn ? true : false}
                                        />
                                    </div>
                                    <div>
                                        <div>
                                            {this.state.locationVisitedSwitchOn ?
                                                <div className="cold-flow-date">
                                                    <DatePicker
                                                        isEditing={this.props.isEditing}
                                                        locale={this.props.data.item.DatePickerLocale}
                                                        defaultSelectedDate={new Date()}
                                                        dateFormat={this.props.data.item.DatePickerFormat}
                                                        todayLabel={this.props.data.item.DatePickerTodayLabel}
                                                        containerClass="row"
                                                        callback={this.setFormValues}
                                                        callbackKey="DateVisited"
                                                    />
                                                </div>
                                                : undefined}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="switch-selection-horizontal">
                                        <label className="text-label" htmlFor="storingscode" dangerouslySetInnerHTML={{ __html: this.props.data.item.FaultDescription }} />
                                        <ToggleInput
                                            id="storingscode"
                                            wrapperClassName="switch-wrapper"
                                            switchYesLabel={this.props.data.item.SwitchYesLabel}
                                            switchNoLabel={this.props.data.item.SwitchNoLabel}
                                            callback={(_id, _val) => {
                                                this.setState({ faultSwitchOn: _val }, () => {
                                                    if (!_val) {
                                                        this.storingscodeInput.current.value = "";
                                                        this.setFormValues("FaultDescription", "");
                                                    }
                                                    else {
                                                        this.validateForm();
                                                    }
                                                });
                                            }}
                                            defaultChecked={this.state.faultSwitchOn ? true : false}
                                        />
                                    </div>
                                    <div className="row">
                                        <div className="columns medium-12">
                                            <label htmlFor="" className="input-wrapper">
                                                <TextInput
                                                    isTextArea={true}
                                                    id={this.enums.storingscodeInput}
                                                    placeholder=""
                                                    classValidation={this.state.faultSwitchOn ? "" : "hide"}
                                                    refData={this.storingscodeInput}
                                                    callback={(_id, _val) => { this.setFormValues("FaultDescription", _val); }}
                                                />
                                            </label>
                                            <div
                                                className={"disabled-input-message sub-p " + (this.state.faultSwitchOn ? "hide" : "")}
                                                dangerouslySetInnerHTML={{ __html: this.props.data.item.WarrantyAgreementContext }}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="section-title">
                                        <label dangerouslySetInnerHTML={{ __html: this.props.data.item.OrderNumberTitle }} />
                                    </div>
                                    <div className="section-field">
                                        <TextInput
                                            id={this.enums.orderNumberInput}
                                            numbersOnly={true}
                                            placeholder=""
                                            refData={this.orderNumberInput}
                                            callback={(_id, _val) => { this.setFormValues("OrderNumber", _val); }}
                                        />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="row section-title">
                                        <div className="columns medium-12">
                                            <label className="" dangerouslySetInnerHTML={{ __html: this.props.data.item.WorkDoneDescription }} />
                                        </div>
                                    </div>
                                    <div className="row section-field">
                                        <div className="columns medium-12 small-11">
                                            <div className="">
                                                <TextInput
                                                    isTextArea={true}
                                                    id={this.enums.workDoneInput}
                                                    placeholder=""
                                                    refData={this.workDoneInput}
                                                    callback={(_id, _val) => { this.setFormValues("WorkDoneDescription", _val); }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="modal--content-checkbox-section">
                        <div className="checkbox-selection">
                            <div className="">
                                <label className="checkbox-wrapper" htmlFor="agree1" onClick={event => { this.setFormValues("JoinRemehaServiceAccepted", !this.joinRemehaService.current.checked); }}>
                                    <input
                                        type="checkbox"
                                        name="agreebox"
                                        id="agree1"
                                        ref={this.joinRemehaService}
                                        checked={this.state.formValues.JoinRemehaServiceAccepted}
                                    />
                                    <span dangerouslySetInnerHTML={{ __html: this.props.data.item.JoinRemehaServiceTitle }} />
                                </label>
                            </div>
                            <div>
                                <label className="checkbox-wrapper" htmlFor="agree2" onClick={event => { this.setFormValues("AllowClientVisitNotificationAccepted", !this.allowClientVisitNotification.current.checked); }}>
                                    <input
                                        type="checkbox"
                                        name="agreebox"
                                        id="agree2"
                                        ref={this.allowClientVisitNotification}
                                        checked={this.state.formValues.AllowClientVisitNotificationAccepted}
                                    />
                                    <span dangerouslySetInnerHTML={{ __html: this.props.data.item.AllowClientVisitNotificationTitle }} />
                                </label>
                            </div>
                        </div>
                    </div>
                    <hr className="grid-row"></hr>
                    <div className="modal--content-footer">
                        <label className="checkbox-wrapper" htmlFor="agree" onClick={event => { this.setFormValues("WarrantyAgreementAccepted", !this.errorFormTerms.current.checked); }}>
                            <input
                                type="checkbox"
                                name="agreen"
                                id="agree"
                                ref={this.errorFormTerms}
                                checked={this.state.formValues.WarrantyAgreementAccepted}
                            />
                            <span>
                                <p className="font-weight-500" dangerouslySetInnerHTML={{ __html: this.props.data.item.WarrantyAgreementTitle }} />
                                <p className="sub-p" dangerouslySetInnerHTML={{ __html: this.props.data.item.WarrantyAgreementContext }} />
                            </span>
                        </label>
                        <Button
                            text={this.props.data.item.SendReportButtonLabel}
                            wrapperClassName="confirm-btn"
                            className={`${(this.state.isFormValid ? "" : "grey disabled")} button arrow-right float-right`}
                            callback={this.state.isFormValid ? (event => this.submitErrorReport(event)) : undefined}
                        />
                    </div>
                </div>
            </React.Fragment>
        );
    }

    renderUnknownProduct = () => {
        return (
            <React.Fragment>
                <div className="cold-flow-reporting">
                    <div className="modal--content-back">
                        <a
                            href="javascript:void(0)"
                            dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportManuallyTitle }}
                            onClick={event => {
                                this.resetManualSearch();
                                this.resetFormValues();
                                this.returnToPreModal();
                            }}
                        />
                        <div className="close mobile" onClick={() => { }}></div>
                    </div>
                    <div className="modal--content-main">
                        <div className=""> {/* 'form' class removed to prevent datevisited incorrect display style */}
                            <div className="modal--content-main-section padding-top-40">
                                <div className="contextual-title-bold main-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.AddressSectionTitle }} />
                                <AddressInput
                                    apiCallback={(message, city, streetName) => {
                                        this.setFormValues("City", city);
                                        this.setFormValues("StreetName", streetName);
                                    }}
                                    callback={(field, val) => { this.setFormValues(field, val); }}
                                    label={this.props.data.item.AddressTitle}
                                    postCodeId={this.enums.postCodeInput}
                                    postcodePlaceholder={this.props.data.item.PostcodePlaceholder}
                                    refPostCode={this.postCodeInput}
                                    houseNumberId={this.enums.housenumberInput}
                                    houseNumberPlaceholder={this.props.data.item.HousenumberPlaceholder}
                                    refHouseNumber={this.housenumberInput}
                                    message={this.props.data.item.NotFoundValidationMessage}
                                    required="text-required"
                                    readOnly={this.state.manualSearch.myRegisteredProduct ? true : false}
                                />
                                <div className="form-group">
                                    <div className="row section-field">
                                        <div className="columns medium-12">
                                            <div className={"search-modal " + (this.state.popManualSearch ? "popsearch" : "")}>
                                                <div className="overlay"></div>
                                                <div className="empty-box"></div>
                                                <div className="search-group">
                                                    <div className="error--search">
                                                        <label className="serial-label" dangerouslySetInnerHTML={{ __html: this.props.data.item.SerialNumberTitle }} />
                                                        <div className="serial-input">
                                                            <MaskedInput
                                                                id={this.enums.serialNumberInput}
                                                                placeholder={SitecoreHelper.getPlaceholderText(
                                                                    this.props.isPageEditing,
                                                                    this.props.data.item.SerialNumberPlaceholder
                                                                )}
                                                                type="text"
                                                                mask={this._mask}
                                                                guide={false}
                                                                ref={this.serialNumberInput}
                                                                onChange={event => this.handleSerialInput(event)}
                                                                onKeyUp={event => {
                                                                    if (event.key === 'Enter' && event.target.value.replace(/ /g, '').length == this.props.data.item.SerialNumberLength) {
                                                                        this.handleSerialInput(event);
                                                                    }
                                                                    else if (event.key === 'Backspace' || event.key === 'Delete') {
                                                                        this.resetManualSearch(event, true);
                                                                    }
                                                                }}
                                                            />
                                                        </div>
                                                    </div>
                                                    <div className="search-result">
                                                        <div className={"no-result " + (this.state.manualSearch.showNoResult ? "" : "hide")}>
                                                            <div className="product-reg--message">
                                                                <i className="close-button" onClick={event => this.resetManualSearch(event)}></i>
                                                                <label htmlFor="" className="result-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.SearchInProductsTitle }} />
                                                                <div className="product-reg-message-text">
                                                                    <p dangerouslySetInnerHTML={{ __html: this.props.data.item.ProductErrorMessage }} />
                                                                </div>
                                                                <div className="product-reg--validation">
                                                                    <div className="product-reg--img">
                                                                        <img src={SitecoreHelper.getImage(this.props.data.item.UnknownProductImage)} />
                                                                    </div>
                                                                    <div className="product-reg--details-box">
                                                                        <div className="product-reg--details-select-product">
                                                                            <div className="product-reg--details">
                                                                                {this.renderProductsList()}
                                                                                <div className="product-reg--add">
                                                                                    <a
                                                                                        href="javascript:void(0)"
                                                                                        dangerouslySetInnerHTML={{ __html: this.props.data.item.SelectProductLabel }}
                                                                                        onClick={event => {
                                                                                            if ((this.state.manualSearch.productResult != null && !this.state.manualSearch.showNoResult)
                                                                                                || (this.state.manualSearch.droplistSelected != null && !this.state.manualSearch.invalidDroplistSelected)) {
                                                                                                this.setFormValues("ProductId", this.serialNumberInput.current.inputElement.value.replace(/ /g, ''));
                                                                                                this.setFormValues("Product", this.state.manualSearch.droplistSelected.UniqueId);
                                                                                                this.setState(function (prevState) {
                                                                                                    prevState.manualSearch.showNoResult = false;
                                                                                                    return { manualSearch: prevState.manualSearch, isUnknownSerial: true };
                                                                                                });
                                                                                            }
                                                                                            else if (this.serialReentryInput.current && this.serialReentryInput.current.inputElement.value.replace(/ /g, '').length == this.props.data.item.SerialNumberLength) {
                                                                                                /* 
                                                                                                    Commented out - Disabled Products will not be shown on CustomDroplist. Reentry for proper
                                                                                                    serial number is not not applicable when Serial Numbers have their own table
                                                                                                */
                                                                                                // this.serialNumberInput.current.inputElement.value = this.serialReentryInput.current.inputElement.value
                                                                                                // this.setFormValues("ProductId", this.serialReentryInput.current.inputElement.value.replace(/ /g, ''))
                                                                                                // this.setFormValues("Product", this.state.manualSearch.droplistSelected.UniqueId)
                                                                                                // this.setState(function (prevState) {
                                                                                                //     prevState.manualSearch.showNoResult = false
                                                                                                //     return { manualSearch: prevState.manualSearch, isUnknownSerial: true }
                                                                                                // })
                                                                                            }
                                                                                        }}
                                                                                    >
                                                                                    </a>
                                                                                </div>
                                                                                <p className="product-reg--serial">{this.state.manualSearch.showNoResult ? this.serialNumberInput.current.inputElement.value : ""}</p>
                                                                            </div>
                                                                            {/* 
                                                                                Commented out - Disabled Products will not be shown on CustomDroplist. Reentry for proper
                                                                                serial number is not not applicable when Serial Numbers have their own table
                                                                            */}
                                                                            {/* this.renderSerialReentry() */}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className={"result-found " + (this.state.manualSearch.showNoResult ? "hide" : "")}>
                                                            <div className="result-item">
                                                                <div className="product--img">
                                                                    <img src={this.state.manualSearch.productResult ? this.state.manualSearch.productResult.ProductImage : undefined} />
                                                                </div>
                                                                <div className="product--info">
                                                                    <p className="product--title">{this.state.manualSearch.productResult ? this.state.manualSearch.productResult.ProductName : undefined}</p>
                                                                    <p className="product--serial">{this.state.manualSearch.productResult ? this.state.manualSearch.productResult.Category : undefined}</p>
                                                                </div>
                                                                <div className="button-wrapper">
                                                                    <a href="javascript:void(0)"
                                                                        className="button select"
                                                                        onClick={event => {
                                                                            this.setFormValues("ProductId", this.state.manualSearch.productResult.ProductId);
                                                                            this.setState({ popManualSearch: false }, () => {
                                                                                // Check if product is registered by current installer and auto populate customer data fields if so
                                                                                if (this.props.isSitecore) {
                                                                                    let _installerId = QueryString.getValue('installerid');
                                                                                    let _startD = undefined;
                                                                                    let _endD = undefined;
                                                                                    let _query = this.serialNumberInput.current.inputElement.value.replace(/ /g, '');
                                                                                    SearchHelper.getRegistrations(_installerId, _query, _startD, _endD, (data) => {
                                                                                        let _myRegisteredProduct = data.Results;
                                                                                        if (_myRegisteredProduct && _myRegisteredProduct.length == 1) {
                                                                                            // Similiar to Product Flow - when products is registered by installer place the serial number on ProductRegistration and have a null ProductId for the API
                                                                                            this.setFormValues("ProductId", null);
                                                                                            this.setFormValues("ProductRegistration", _myRegisteredProduct[0].Product.ProductId);
                                                                                            this.setFormValues("Salutation", _myRegisteredProduct[0].Salutation || " ");
                                                                                            DisplayHelper.ChangeInputElemValueProgramatically(this.postCodeInput, _myRegisteredProduct[0].PostalCode);
                                                                                            DisplayHelper.ChangeInputElemValueProgramatically(this.housenumberInput, _myRegisteredProduct[0].HouseNumber);
                                                                                            this.setFormValues("PostalCode", _myRegisteredProduct[0].PostalCode, () => {                                                                                                
                                                                                                this.setFormValues("HouseNumber", _myRegisteredProduct[0].HouseNumber, () => {
                                                                                                    this.setState(function (prevState) {
                                                                                                        prevState.manualSearch.myRegisteredProduct = {..._myRegisteredProduct[0]};
                                                                                                        if (_myRegisteredProduct[0].EmailAddress)
                                                                                                            prevState.emailSwitchOn = true;
                                                                                                        return { manualSearch: prevState.manualSearch, emailSwitchOn: prevState.emailSwitchOn };
                                                                                                    }, () => {
                                                                                                        DisplayHelper.ChangeInputElemValueProgramatically(this.firstnameInput, this.state.manualSearch.myRegisteredProduct.Firstname);
                                                                                                        DisplayHelper.ChangeInputElemValueProgramatically(this.lastnameInput, this.state.manualSearch.myRegisteredProduct.Lastname);
                                                                                                        DisplayHelper.ChangeInputElemValueProgramatically(this.telephoneInput, this.state.manualSearch.myRegisteredProduct.TelephoneNo);
                                                                                                        DisplayHelper.ChangeInputElemValueProgramatically(this.emailSwitch, this.state.manualSearch.myRegisteredProduct && this.state.manualSearch.myRegisteredProduct.EmailAddress ? true : false, 'checked');
                                                                                                        DisplayHelper.ChangeInputElemValueProgramatically(this.emailInput, this.state.manualSearch.myRegisteredProduct.EmailAddress);
                                                                                                    });
                                                                                                });
                                                                                            });                                                                                            
                                                                                        }
                                                                                        else {
                                                                                            this.setFormValues("Product", this.state.manualSearch.productResult.UniqueId);
                                                                                        }
                                                                                    });
                                                                                }
                                                                                else {
                                                                                    let _myRegisteredProduct = [...this.state.myProducts].filter((val) => {
                                                                                        return String(val.Product.ProductId).toLowerCase().includes(String(this.serialNumberInput.current.inputElement.value.replace(/ /g, '')).toLowerCase());
                                                                                    });
                                                                                    if (_myRegisteredProduct.length == 1) {
                                                                                        this.setState(function (prevState) {
                                                                                            prevState.manualSearch.myRegisteredProduct = _myRegisteredProduct[0];
                                                                                            return { manualSearch: prevState.manualSearch };
                                                                                        });
                                                                                    }
                                                                                }
                                                                            });
                                                                        }}
                                                                    >
                                                                        <span dangerouslySetInnerHTML={{ __html: this.props.data.item.SelectButtonLabel }} />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="modal--content-main-section gray-bg">
                                <div className="contextual-title-bold main-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.CustomerDetailsSectionTitle }} />
                                <div className="form-group customer-data">
                                    <div className="row section-field customer-input">
                                        <div className="columns small-12 input-row--salutation">
                                            <RadioInput
                                                id={this.enums.salutationOption}
                                                label={this.props.data.item.CustomerDataSalutation}
                                                options={this.props.data.item.Salutation}
                                                isEditing={this.props.isEditing}
                                                required="text-required"
                                                callback={(_id, _val) => { this.setFormValues("Salutation", _val); }}
                                                checkedItem={this.state.manualSearch.myRegisteredProduct && this.state.manualSearch.myRegisteredProduct.Salutation ? this.state.manualSearch.myRegisteredProduct.Salutation : (this.state.formValues.Salutation || " ")}
                                                readOnly={this.state.manualSearch.myRegisteredProduct ? true : false}
                                            />
                                        </div>
                                        <div className="columns small-12 input-row--name">
                                            <div className="input-row--first-name">
                                                <TextInput
                                                    id={this.enums.firstnameInput}
                                                    label={this.props.data.item.CustomerDataFirstName}
                                                    placeholder={this.props.data.item.CustomerDataFirstNamePlaceholder}
                                                    refData={this.firstnameInput}
                                                    callback={(_id, _val) => { this.setFormValues("Firstname", _val); }}
                                                    readOnly={this.state.manualSearch.myRegisteredProduct ? true : false}
                                                />
                                            </div>
                                            <div className="input-row--last-name">
                                                <TextInput
                                                    id={this.enums.lastnameInput}
                                                    label={this.props.data.item.CustomerDataLastName}
                                                    placeholder={this.props.data.item.CustomerDataLastNamePlaceholder}
                                                    refData={this.lastnameInput}
                                                    callback={(_id, _val) => { this.setFormValues("Lastname", _val); }}
                                                    readOnly={this.state.manualSearch.myRegisteredProduct ? true : false}
                                                />
                                            </div>
                                        </div>
                                        <div className="columns small-12">
                                            <TextInput
                                                id={this.enums.telephoneInput}
                                                type="telephone"
                                                validate={true}
                                                required={this.state.manualSearch.myRegisteredProduct ? undefined : "text-required"}
                                                errorMessage={this.props.data.item.TelephoneInvalidMessage}
                                                label={this.props.data.item.CustomerDataTelephone}
                                                placeholder={this.props.data.item.CustomerDataTelephonePlaceholder}
                                                refData={this.telephoneInput}
                                                callback={(_id, _val) => { this.setFormValues("TelephoneNo", _val); }}
                                                readOnly={this.state.manualSearch.myRegisteredProduct ? true : false}
                                            />
                                        </div>
                                        <div className="columns small-12">
                                            <label className="" dangerouslySetInnerHTML={{ __html: this.props.data.item.CustomerDataEmailAddress }} />
                                            <div className="switch-wrapper">
                                                <ToggleInput
                                                    id={this.enums.emailSwitch}
                                                    refData={this.emailSwitch}
                                                    switchYesLabel={this.props.data.item.SwitchYesLabel}
                                                    switchNoLabel={this.props.data.item.SwitchNoLabel}
                                                    callback={(_id, _val) => {
                                                        this.setState({ emailSwitchOn: _val });
                                                    }}
                                                    defaultChecked={this.state.emailSwitchOn ? true : false}
                                                    readOnly={this.state.manualSearch.myRegisteredProduct ? true : false}
                                                />
                                                <div className={"validation-wrapper " + (this.state.emailSwitchOn ? "" : "hide")}>
                                                    <TextInput
                                                        id={this.enums.emailInput}
                                                        type="email"
                                                        validate={true}
                                                        errorMessage={this.props.data.item.EmailInvalidMessage}
                                                        placeholder={this.props.data.item.CustomerDataEmailAddressPlaceholder}
                                                        refData={this.emailInput}
                                                        callback={(_id, _val) => { this.setFormValues("EmailAddress", _val); }}
                                                        readOnly={this.state.manualSearch.myRegisteredProduct ? true : false}
                                                    />
                                                    <p className="sub-note" dangerouslySetInnerHTML={{ __html: this.props.data.item.CustomerDataEmailAddressDisclaimerText }} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="modal--content-main-section border-bottom">
                                <div className="contextual-title-bold main-title" dangerouslySetInnerHTML={{ __html: this.props.data.item.ErrorDetailsSectionTitle }} />
                                <DatePicker
                                    title={this.props.data.item.FailureDateTitle}
                                    isEditing={this.props.isEditing}
                                    locale={this.props.data.item.DatePickerLocale}
                                    defaultSelectedDate={new Date()}
                                    dateFormat={this.props.data.item.DatePickerFormat}
                                    todayLabel={this.props.data.item.DatePickerTodayLabel}
                                    wrapperClass="form-datepicker"
                                    columnCLass="columns medium-8"
                                    callback={this.setFormValues}
                                    callbackKey="FailureDate"
                                />
                                <div className="form-group">
                                    <div className="row section-title">
                                        <div className="switch-selection-horizontal columns medium-8">
                                            <label className="text-label" htmlFor="locatiegeweest" dangerouslySetInnerHTML={{ __html: this.props.data.item.LocationVisitedTitle }} />
                                            <ToggleInput
                                                id="locatiegeweest"
                                                wrapperClassName="switch-wrapper"
                                                switchYesLabel={this.props.data.item.SwitchYesLabel}
                                                switchNoLabel={this.props.data.item.SwitchNoLabel}
                                                callback={(_id, _val) => {
                                                    this.setState({ locationVisitedSwitchOn: _val }, () => {
                                                        if (!_val) {
                                                            this.setFormValues("DateVisited", null);
                                                        }
                                                        else {
                                                            this.setFormValues("DateVisited", new Date());
                                                        }
                                                    });
                                                }}
                                                defaultChecked={this.state.locationVisitedSwitchOn ? true : false}
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            {this.state.locationVisitedSwitchOn ?
                                                <div className="cold-flow-date">
                                                    <DatePicker
                                                        title={this.props.data.item.LocationVisitedTitle2}
                                                        isEditing={this.props.isEditing}
                                                        locale={this.props.data.item.DatePickerLocale}
                                                        defaultSelectedDate={new Date()}
                                                        dateFormat={this.props.data.item.DatePickerFormat}
                                                        todayLabel={this.props.data.item.DatePickerTodayLabel}
                                                        containerClass="row"
                                                        columnCLass="columns medium-8"
                                                        callback={this.setFormValues}
                                                        callbackKey="DateVisited"
                                                    />
                                                </div>
                                                : undefined}
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <h2 dangerouslySetInnerHTML={{ __html: this.props.data.item.ReportAFault }} />
                                    <div className="form-group">
                                        <p dangerouslySetInnerHTML={{ __html: this.props.data.item.FaultIndicationTitle }} />
                                        <div className="checkbox-selection">
                                            {this.getFaultIndications()}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="switch-selection-horizontal">
                                        <label className="text-label" htmlFor="storingscode" dangerouslySetInnerHTML={{ __html: this.props.data.item.FaultDescription }} />
                                        <ToggleInput
                                            id="storingscode"
                                            wrapperClassName="switch-wrapper"
                                            switchYesLabel={this.props.data.item.SwitchYesLabel}
                                            switchNoLabel={this.props.data.item.SwitchNoLabel}
                                            callback={(_id, _val) => {
                                                this.setState({ faultSwitchOn: _val }, () => {
                                                    if (!_val) {
                                                        this.storingscodeInput.current.value = "";
                                                        this.setFormValues("FaultDescription", "");
                                                    }
                                                    else {
                                                        this.validateForm();
                                                    }
                                                });
                                            }}
                                            defaultChecked={this.state.faultSwitchOn ? true : false}
                                        />
                                    </div>
                                    <div className="row">
                                        <div className="columns medium-12">
                                            <label htmlFor="" className="input-wrapper">
                                                <TextInput
                                                    isTextArea={true}
                                                    id={this.enums.storingscodeInput}
                                                    placeholder=""
                                                    classValidation={this.state.faultSwitchOn ? "" : "hide"}
                                                    refData={this.storingscodeInput}
                                                    callback={(_id, _val) => { this.setFormValues("FaultDescription", _val); }}
                                                />
                                            </label>
                                            <div
                                                className={"disabled-input-message sub-p " + (this.state.faultSwitchOn ? "hide" : "")}
                                                dangerouslySetInnerHTML={{ __html: this.props.data.item.WarrantyAgreementContext }}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="section-title">
                                        <label dangerouslySetInnerHTML={{ __html: this.props.data.item.OrderNumberTitle }} />
                                    </div>
                                    <div className="section-field">
                                        <TextInput
                                            id={this.enums.orderNumberInput}
                                            numbersOnly={true}
                                            placeholder=""
                                            refData={this.orderNumberInput}
                                            callback={(_id, _val) => { this.setFormValues("OrderNumber", _val); }}
                                        />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="row section-title">
                                        <div className="columns medium-12">
                                            <label className="" dangerouslySetInnerHTML={{ __html: this.props.data.item.WorkDoneDescription }} />
                                        </div>
                                    </div>
                                    <div className="row section-field">
                                        <div className="columns medium-12 small-11">
                                            <div className="">
                                                <TextInput
                                                    isTextArea={true}
                                                    id={this.enums.workDoneInput}
                                                    placeholder=""
                                                    refData={this.workDoneInput}
                                                    callback={(_id, _val) => { this.setFormValues("WorkDoneDescription", _val); }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="modal--content-checkbox-section">
                        <div className="checkbox-selection">
                            <div className="">
                                <label className="checkbox-wrapper" htmlFor="agreebox1u" onClick={event => { this.setFormValues("JoinRemehaServiceAccepted", !this.joinRemehaService2.current.checked); }}>
                                    <input
                                        type="checkbox"
                                        name="agreebox1u"
                                        id="agreebox1u"
                                        ref={this.joinRemehaService2}
                                        checked={this.state.formValues.JoinRemehaServiceAccepted}
                                    />
                                    <span dangerouslySetInnerHTML={{ __html: this.props.data.item.JoinRemehaServiceTitle }} />
                                </label>
                            </div>
                            <div>
                                <label className="checkbox-wrapper" htmlFor="agreebox2u" onClick={event => { this.setFormValues("AllowClientVisitNotificationAccepted", !this.allowClientVisitNotification2.current.checked); }}>
                                    <input
                                        type="checkbox"
                                        name="agreebox2u"
                                        id="agreebox2u"
                                        ref={this.allowClientVisitNotification2}
                                        checked={this.state.formValues.AllowClientVisitNotificationAccepted}
                                    />
                                    <span dangerouslySetInnerHTML={{ __html: this.props.data.item.AllowClientVisitNotificationTitle }} />
                                </label>
                            </div>
                        </div>
                    </div>
                    <hr className="grid-row"></hr>
                    <div className="modal--content-footer">
                        <label className="checkbox-wrapper" htmlFor="agreeu" onClick={event => { this.setFormValues("WarrantyAgreementAccepted", !this.errorFormTerms2.current.checked); }}>
                            <input
                                type="checkbox"
                                name="agreeu"
                                id="agreeu"
                                ref={this.errorFormTerms2}
                                checked={this.state.formValues.WarrantyAgreementAccepted}
                            />
                            <span>
                                <p className="font-weight-500" dangerouslySetInnerHTML={{ __html: this.props.data.item.WarrantyAgreementTitle }} />
                                <p className="sub-p" dangerouslySetInnerHTML={{ __html: this.props.data.item.WarrantyAgreementContext }} />
                            </span>
                        </label>
                        <Button
                            text={this.props.data.item.SendReportButtonLabel2}
                            wrapperClassName="confirm-btn"
                            className={`${(this.state.isFormValid ? "" : "grey disabled")} button arrow-right float-right`}
                            callback={this.state.isFormValid ? (event => this.submitErrorReport(event)) : undefined}
                        />
                    </div>
                </div>
            </React.Fragment >
        );
    }

    renderProductsList = () => {
        let _productList = this.state.productList;
        let _options = [];
        let _default = {
            Text: this.props.data.item.ProductListDefault,
            Value: ""
        };
        let _selectedProduct = _default;
        if (!isNullOrUndefined(this.state.manualSearch.droplistSelected) && Object.entries(this.state.manualSearch.droplistSelected).toString() !== Object.entries(_default).toString())
            _selectedProduct = {
                Text: this.state.manualSearch.droplistSelected.ProductName,
                Value: this.state.manualSearch.droplistSelected.UniqueId
            };
        _options.push(_default);
        _productList.forEach((obj, i) => {
            let _obj = {};
            _obj.Text = obj.ProductName;
            _obj.Value = obj.UniqueId;
            _options.push(_obj);
        });
        return (
            <CustomDroplist
                containerClass=""
                list={_options}
                selected={_selectedProduct}
                action={this.customDroplistProductSelected}
                identifier="_"
            />
        );
    }

    handleSerialInput = (e) => {
        let _id = this.enums.serialNumberInput;
        let _val = e.target.value.replace(/ /g, '');
        if (_val.length == this.props.data.item.SerialNumberLength) {
            if (!this.props.isSitecore) {
                //react-only search manual flow
                let _result = this.state.productList.find((v) => {
                    return v.ProductId == _val;
                });
                if (_result) {
                    this.setState(function (prevState) {
                        prevState.manualSearch.productResult = _result;
                        prevState.manualSearch.showNoResult = false;
                        return { manualSearch: prevState.manualSearch, popManualSearch: true };
                    });
                }
                else
                    this.setState(function (prevState) {
                        prevState.manualSearch.productResult = null;
                        prevState.manualSearch.showNoResult = true;
                        return { manualSearch: prevState.manualSearch, popManualSearch: false };
                    });
            }
            else {
                //sitecore searching of product
                let _data = {};
                _data.ProductId = _val;
                Products.GetProduct(_data, (_result) => {
                    if (_result)
                        this.setState(function (prevState) {
                            prevState.manualSearch.productResult = _result;
                            prevState.manualSearch.showNoResult = false;
                            return { manualSearch: prevState.manualSearch, popManualSearch: true };
                        });
                    else
                        this.setState(function (prevState) {
                            prevState.manualSearch.productResult = null;
                            prevState.manualSearch.showNoResult = true;
                            return { manualSearch: prevState.manualSearch, popManualSearch: false };
                        });
                });
            }
        }
        else if (this.state.popManualSearch)
            this.setState(function (prevState) {
                prevState.manualSearch.productResult = null;
                prevState.manualSearch.showNoResult = false;
                return { manualSearch: prevState.manualSearch, popManualSearch: false };
            });
    }

    renderSerialReentry = () => {
        let _return = null;
        if (this.state.manualSearch.invalidDroplistSelected) {
            _return = (
                <div>
                    <div ref={this.refProdRegMsg} className={"product-reg-message-text shake"}>
                        <p>{this.props.data.item.ReenterSerialNumberMessage} {ProductCategoryHelper.getDefinition(this.state.manualSearch.droplistSelected)}</p>
                    </div>
                    <div className="product-reg--detailes-retype-serial">
                        <label>
                            <p>{this.props.data.item.ReenterSerialNumberTitle}</p>
                            <MaskedInput
                                autoFocus="true"
                                type="text"
                                placeholder={SitecoreHelper.getPlaceholderText(
                                    this.props.isPageEditing,
                                    this.props.data.item.SerialNumberPlaceholder
                                )}
                                mask={this._mask}
                                guide={false}
                                ref={this.serialReentryInput}
                                onKeyPress={event => {
                                    if (event.key === 'Enter' && event.target.value.replace(/ /g, '').length == this.props.data.item.SerialNumberLength) {
                                        this.setFormValues("ProductId", this.serialReentryInput.current.inputElement.value.replace(/ /g, ''));
                                        this.setFormValues("Product", this.state.manualSearch.droplistSelected.UniqueId);
                                        this.setState(function (prevState) {
                                            prevState.manualSearch.showNoResult = false;
                                            return { manualSearch: prevState.manualSearch, isUnknownSerial: true };
                                        });
                                    }
                                }}
                            />
                        </label>
                    </div>
                </div>);
        }
        return _return;
    }

    customDroplistProductSelected = (e, s, val) => {
        let selectedProduct = { ...(this.state.productList.find((v) => { return v.UniqueId == val.Value; })) };
        if (Object.keys(selectedProduct).length > 0) {
            this.setState(function (prevState) {
                /*
                    Commented out - Disabled Products will not be shown on CustomDroplist. Reentry for proper
                    serial number is not not applicable when Serial Numbers have their own table
                */
                // if (selectedProduct && selectedProduct.Disabled) {
                //     selectedProduct.ProductId = this.serialNumberInput.current.inputElement.value.replace(/ /g, '')
                //     prevState.manualSearch.invalidDroplistSelected = false
                // }
                // else {
                //     prevState.manualSearch.invalidDroplistSelected = true
                // }
                selectedProduct.ProductId = this.serialNumberInput.current.inputElement.value.replace(/ /g, '');
                prevState.manualSearch.invalidDroplistSelected = false;
                prevState.manualSearch.droplistSelected = selectedProduct;
                return { manualSearch: prevState.manualSearch };
            });
        }
    }

    renderSuccessContent = () => {
        return (
            <React.Fragment>
                <div className="thank-you--img">
                    <img alt="" src={this.props.isSitecore ? SitecoreHelper.getImage(this.props.data.item.SuccessModalIcon) : this.props.data.item.SuccessModalIcon} />
                </div>
                <div className="thank-you--content">
                    <h2 dangerouslySetInnerHTML={{ __html: this.props.data.item.SuccessModalTitle }} />
                </div>
                <div className="thank-you--content">
                    <p dangerouslySetInnerHTML={{ __html: this.props.data.item.SuccessModalContent }} />
                </div>
                <a href="javascript:void(0)"
                    className="link"
                    dangerouslySetInnerHTML={{ __html: this.props.data.item.DownloadButtonText }}
                />
                <div className="button-wrapper">
                    <a href="javascript:void(0)"
                        className="button green"
                        dangerouslySetInnerHTML={{ __html: this.props.data.item.SuccessModalButtonText }}
                        onClick={() => {
                            if (this.props.closeEvent && this.props.closeId)
                                this.props.closeEvent(this.props.closeId);
                        }}
                    />
                </div>
            </React.Fragment>
        );
    }
        
    render() {
        let _content = undefined;
        if (this.state.modalStep == 0)
            _content = this.renderPreModal();
        else if (this.state.modalStep == 1)
            _content = this.renderKnownProduct();
        else if (this.state.modalStep == 2)
            _content = this.renderUnknownProduct();
        else if (this.state.modalStep == 3)
            _content = this.renderSuccessContent();
        return (
            <React.Fragment ref={this.focusTop}>
                {_content}
            </React.Fragment>
        );
    }
}

module.exports = ErrorReportModalContent;