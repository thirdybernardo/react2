import React from 'react';
import Data from '../../Data/Data';
import InstallerHelper from '../../Helpers/InstallerHelper';
import ExportButton from '../Generic/ExportButton';
import FileHelper from '../../Helpers/FileHelper';
import SearchHelper from '../../Helpers/SearchHelper';
import QueryString from '../../Data/QueryString';
import ProductAPI from '../../API/ProductRegistration';

class InstalledProductsOverview extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            installedProductsCount: null,
            installerId: null
        };
    }

    componentDidMount() {
        InstallerHelper.GetInstallerId(this.props.isSitecore, (_installerId) => {
            this.setState({ installerId: _installerId }, () => {
                this.renderInstalledProductsCount()
                    .then((data) => {
                        let _return = null;
                        let _count = "";
                        if (!this.props.isSitecore) {
                            _count = data;
                        }
                        else {
                            if (!isNaN(data.Count)) {
                                _count = String(data.Count);
                            }
                        }
                        _return = (
                            <h3 className="product-overview--notif-title">
                                {_count}
                                &nbsp;
                                <span dangerouslySetInnerHTML={{ __html: this.props.data.item.Title }} />
                            </h3>
                        );
                        this.setState({ installedProductsCount: _return });
                    })
                    .catch((error) => {
                        console.log(error);
                    });
            });
        });
    }

    exportRegistrationHistory = (installerID) => {
        if (!this.props.isSitecore) {
            Data.getData("MockInstallerRegisteredProducts", (data) => {
                /** Some pre-formatting for demo purposes only **/
                let registrations = [];
                registrations.push(data);
                let _registrations = registrations.find(item => item.Installer.ID === installerID);
                if (_registrations) {
                    let _objArr = [];
                    _registrations.Registered.forEach((val) => {
                        const registered = Object.assign({}, val);
                        //Just show the Serial No for the column name : "Product"
                        registered.Product = val.Product.ProductId + "\t"; //Added so it's not interpreted as numbers
                        registered.OGP = val.Product.ServiceId;
                        _objArr.push(registered);
                    })
                /**Assume that _objArr has correct informations when passed to the exporter**/
                /**fourth param is for format type (xlsx|csv). Default is xlsx */ /
                        FileHelper.exportJsonToWorkbook("Registrations", "Registration History", _objArr);
                }
            });
        }
        else {
            let _installerId = QueryString.getValue("installerid");

            SearchHelper.getRegistrations(_installerId, "", null, null, data => {
                if (data.Results) {
                    let _table = {
                        FirstName: "",
                        LastName: "",
                        CustomerId: "",
                        Emailaddress: "",
                        PostalCode: "",
                        HouseNumber: "",
                        City: "",
                        StreetName : "",
                        ProductName: "",
                        InstallationDate : "",
                        Points: "",
                        ProductId: "",
                        IsForProject: false,
                        ProjectName: "",
                        ProjectEndDate: ""
                    };
                    let _records = [];
                    data.Results.forEach((val, i) => {
                        _table = {
                            FirstName: val.Firstname,
                            LastName: val.Lastname,
                            CustomerId: val.Id,
                            Emailaddress: val.Emailaddress,
                            PostalCode: val.PostalCode,
                            HouseNumber: val.HouseNumber,
                            City: val.City,
                            StreetName: val.StreetName,
                            ProductName: val.Product.Name,
                            InstallationDate: val.InstallationDate,
                            ProductId : val.Product.ProductId,
                            Points: val.Points,
                            IsForProject: val.Project ? true : false,
                            ProjectName: val.Project ? val.Project.ProjectName : "",
                            ProjectEndDate: val.Project ? val.Project.ProjectEndDate : ""
                        };
                        _records.push(_table);
                    });

                    if (_records.length > 0) {
                        FileHelper.exportJsonToWorkbook("Registrations", "Registration History", _records);
                    }

                }
            });
        }
    }

    renderInstalledProductsCount = () => {
        return new Promise((resolve, reject) => {
            let _count = null;
            if (!this.props.isSitecore) {
                Data.getData("MockInstallerRegisteredProducts", data => {
                    _count = 0;
                    data.Registered.forEach((val) => {
                        if (val.isCompleted && !val.IsDisabled)
                            _count++
                    })
                    resolve(_count)
                });
            }
            else {
                ProductAPI.GetInstallerRegisteredProductsCount(this.state.installerId, (result) => {
                    resolve(result);
                });
            }
        });
    }

    render() {
        return (
            <div>
                <div className="product-overview product-overview--full-width">
                    <div className="row product-overview--export-section">
                        <div className="large-6 medium-6 small-12">
                            {this.state.installedProductsCount}
                        </div>
                        <ExportButton
                            wrapperClassName="large-6 medium-6 small-12"
                            className="button"
                            callback={e => this.exportRegistrationHistory(100) /*Queryable installer id. Must be dynamic*/}
                            text={this.props.data.item.ExportButtonText}
                        />
                    </div>
                </div>
            </div>
        );
    }

}

module.exports = InstalledProductsOverview;