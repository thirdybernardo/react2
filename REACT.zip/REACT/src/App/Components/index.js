﻿/**
 *  Copyright (c) 2015, Facebook, Inc.
 *  All rights reserved.
 *
 *  This source code is licensed under the BSD-style license found in the
 *  LICENSE file in the root directory of this source tree. An additional grant 
 *  of patent rights can be found in the PATENTS file in the same directory.
 */

module.exports = {
  HelloWorld: require('./Demo/HelloWorld'),
  SingleUpload: require('./ProductRegistration/SingleUpload'),
  ThankYou: require('./ThankYou/ThankYou'),
  InstalledProductsOverview: require('./ProductOverview/InstalledProductsOverview'),
  TableSearch: require('./Generic/TableSearch'),
  BulkRegistration: require('./ProductRegistration/BulkUpload'),
  RegistrationOptions: require('./ProductRegistration/RegistrationOptions'),
  Greeting: require('./Generic/Greeting'),
  StickyNavigation: require('./Generic/StickyNavigation'),
  ProfileForm: require('./Profile/ProfileForm'),
  UserInformation: require('./Profile/UserInformation'),
  QuickProductRegistrationTile: require('./Dashboard/QuickProductRegistrationTile'),
  RecentRegistrationsTile: require('./Dashboard/RecentRegistrationsTile'),
  RecentPointsEarnedTile: require('./Dashboard/RecentPointsEarnedTile'),
  DashboardSearch: require('./Dashboard/DashboardSearch'),
  EmailCampaignBanner: require ('./Dashboard/EmailCampaignBanner'),
  WishlistTile: require('./Dashboard/WishlistTile'),
  ProductErrorReport: require('./ProductOverview/ErrorReport')
};
  