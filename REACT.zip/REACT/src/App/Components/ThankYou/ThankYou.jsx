import React from "react";
import Data from "../../Data/Data";
import Card from "../Generic/Card";
import QueryString from "../../Data/QueryString";

class ThankYou extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            thankYouImg: null,
            pointsEarned: 0
        };
    }

    componentDidMount() {
        this.setState({pointsEarned: QueryString.getValue('pointsEarned')});
    }

    renderThankYouImage = () => {
        let _return = null;
        if (!this.props.isSitecore) {
            _return = (
                <img alt="" src="../images/icons/icons-success.svg" />
            );
        }
        else{
            //Get image here from Sitecore using SitecoreData class
        }
        return _return;
    }

    getPointsEarned = () => {
        let _return = null;
        let _points = this.state.pointsEarned;
        _return = !_points ? undefined : "+" + _points;
        return _return;
    }

    renderCards = () => {
        let _return = [];
        let _key = 1;
    
        _return.push(
            <div className="columns small-12 border-top"></div>
        );

        if (this.props.data.item.WarrantyVisible == true || this.props.isEditing === true)
            _return.push(
                <Card
                    key={_key++}
                    columnSize={this.props.data.item.WarrantyCardSize}
                    containerClass={"reg-box ogp-geen"}
                    title={this.props.data.item.WarrantyTitle}
                    content={this.props.data.item.WarrantyContent}
                    linkVisible={this.props.data.item.WarrantyButtonVisible}
                    linkClass={"button"}
                    linkEvent={this.props.data.links.WarrantyLink}
                    linkText={this.props.data.item.WarrantyLinkText} />
            );
        if (this.props.data.item.PointsGainedVisible == true || this.props.isEditing === true)
            _return.push(
                <Card
                    key={_key++}
                    columnSize={this.props.data.item.PointsGainedCardSize}
                    containerClass={"reg-box punten"}
                    title={this.props.data.item.PointsGainedTitle}
                    content={this.props.data.item.PointsGainedContent}
                    linkVisible={this.props.data.item.PointsGainedButtonVisible}
                    linkClass={"thank-you--credits"}
                    linkEvent={undefined}
                    linkText={this.getPointsEarned()} />
            );
        if (this.props.data.item.SummaryVisible == true || this.props.isEditing === true)
            _return.push(
                <Card
                    key={_key++}
                    columnSize={this.props.data.item.SummaryCardSize}
                    containerClass={"reg-box blue-box dl-pdf"}
                    title={this.props.data.item.SummaryTitle}
                    content={this.props.data.item.SummaryContent}
                    linkVisible={this.props.data.item.SummaryButtonVisible}
                    linkClass={"button arrow-down"}
                    linkEvent={this.props.data.links.SummaryLink}
                    linkText={this.props.data.item.SummaryLinkText} />
            );
        if (this.props.data.item.NewRegistrationVisible == true || this.props.isEditing === true)
            _return.push(
                <Card
                    key={_key++}
                    columnSize={this.props.data.item.NewRegistrationCardSize}
                    containerClass={"reg-box blue-box niuewe"}
                    title={this.props.data.item.NewRegistrationTitle}
                    content={this.props.data.item.NewRegistrationContent}
                    linkVisible={this.props.data.item.NewRegistrationButtonVisible}
                    linkClass={"button arrow-right"}
                    linkEvent={this.props.data.links.NewRegistrationLink}
                    linkText={this.props.data.item.NewRegistrationLinkText} />
            );
        return _return;
    }

    render() {
        return (
            <div className="thank-you--registration">
                <div className="thank-you--section">
                    <div className="thank-you--img">
                        {this.renderThankYouImage()}
                    </div>
                    <div className="thank-you--content">
                        <h2><span dangerouslySetInnerHTML={{ __html: this.props.data.item.Title }} /></h2>
                        <p><span dangerouslySetInnerHTML={{ __html: this.props.data.item.Subtitle }} /></p>
                    </div>
                </div>
                <div className="row thank-you--boxes">
                    {this.renderCards()}
                </div>
            </div>
        );
    }

}

module.exports = ThankYou;