import React, { Component } from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import ThankYou from '../ThankYou';
import thankYouData from '../../../../../build/Data/json/ThankYouFields.json';
import renderer from 'react-test-renderer';
import Cards from '../../Generic/Card';

const thankYou = shallow(<ThankYou data={thankYouData}/>);

test('ThankYou matches snapshot', () => {    
    const tree = renderer.create(<ThankYou data={thankYouData} />).toJSON();
    expect(tree).toMatchSnapshot();
});

test('Renders four cards', () => {
    const cards = thankYou.find(Cards);
    expect(cards.length).toEqual(4);
});

test('Renders main Thank You image', () => {
    const img = thankYou.find("div.thank-you--img img");

    expect.assertions(3);
    expect(img).toEqual(expect.anything());
    expect(img).toHaveLength(1);
    
    thankYou.setProps({ isSitecore: true});
    expect(img.prop('src')).toEqual("../images/icons/icons-success.svg");
    thankYou.setProps({ isSitecore: undefined});
});

test('Gets Title and Subtitle props', () => {  
    expect(thankYou.instance().props.data.item.Title).toEqual(expect.anything(String));
    expect(thankYou.instance().props.data.item.Subtitle).toEqual(expect.anything(String));
    expect(thankYou.find('.thank-you--content h2 span').html()).toEqual(expect.stringContaining(thankYouData.item.Title));
    expect(thankYou.find(".thank-you--content p span").html()).toEqual(expect.stringContaining(thankYouData.item.Subtitle)); 
});

test('Cards are rendered only based on true-valued props', () => {
    const updatedProps = Object.assign(thankYouData);
    expect(thankYou.find(Cards).length).toEqual(4);

    updatedProps.item.WarrantyVisible = false;
    thankYou.setProps({ data: updatedProps});
    expect(thankYou.find(Cards).length).toEqual(3);

    updatedProps.item.PointsGainedVisible = false;
    thankYou.setProps({ data: updatedProps});
    expect(thankYou.find(Cards).length).toEqual(2);

    updatedProps.item.SummaryVisible = false;
    thankYou.setProps({ data: updatedProps});
    expect(thankYou.find(Cards).length).toEqual(1);

    updatedProps.item.NewRegistrationVisible = false;
    thankYou.setProps({ data: updatedProps});
    expect(thankYou.find(Cards).length).toEqual(0);
});