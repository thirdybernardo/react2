import React, {Component} from "react";

export default class SubWorld extends Component{  
    constructor(props) {
        super(props);
        this.state = {
            showLink: false
        };
    }

    showHideLink = () => {
        let _temp = true;
        if(this.state.showLink){
            _temp = false;
        }        
        this.setState({
            showLink: _temp
        });
    }

    renderContent = (allowRender) => {
        let _return = null;
        if(allowRender){
            _return =                 
                <React.Fragment>
                    <button className="button" onClick={event => this.showHideLink()}>Show/Hide subcomponent's Link</button>
                    <a href="#" style={{display: this.state.showLink ? "block":"none"}}>I am a link being shown/hide on a button click</a>   
                    <p className="subworld-text">This is a paragraph on a subcomponent</p>  
                </React.Fragment>;
        }
        return(
            _return
        );
    }

    render(){
        return(
            <React.Fragment>
                {this.renderContent(true)}
            </React.Fragment>
        );
    }
}
