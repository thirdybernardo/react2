import React, {Component} from "react";
import SubWorld from "./SubWorld";

class HelloWorld extends Component{  
    constructor(props) {
        super(props);
        this.state = {
            sampleState: "Welcome to the demo page!",
            sampleState2: 1,
            renderSubcomponent: false
        };
    }

    changeTitle = () => {
        this.setState({ 
            sampleState: "The title has been changed." ,
            sampleState2: 100
        });
    }

    changeStateWithProp = (newProp) => {
        this.setState({ 
            sampleState2: newProp
        });
    }

    hideShowSubcomponent = () => {
        let _temp = false;
        let _subComponent = null;
        if(!this.state.renderSubcomponent){
            _temp = true;
            _subComponent = <SubWorld/>;
        }        
        this.setState({
            renderSubcomponent: _temp
        });
        return _subComponent;
    }

    renderSubcomponent = () => {
        let _return = null;
        if(this.state.renderSubcomponent){
            _return = <SubWorld/>;
        }     
        return _return; 
    }

    render(){
        return(
            <div>
                <h1 className="title">{this.state.sampleState}</h1>   
                <button className="button" onClick={event => {this.changeTitle();}}>Click me to change title</button><br/>
                <input id="clickWithProps" className="input-group-field" style={{border: "1px solid #c7c7c7"}} onChange={event => {this.changeStateWithProp(event.currentTarget.value);}}/><br/>
                <span dangerouslySetInnerHTML={{__html: this.props.data.item.PromoText}} className="promotext"></span>            
                <br/>
                <button className="button" onClick={event => {this.hideShowSubcomponent();}}>Click me to render the subcomponent</button><br/>
                {this.renderSubcomponent()}
            </div>
        );
    }
}

module.exports = HelloWorld;
