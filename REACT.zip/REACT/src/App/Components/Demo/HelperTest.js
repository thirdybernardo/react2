

export default class HelperTest{
    static CreateStringList(str1, str2){
        let _arr = [];
        str1.forEach((element, i) => {   
            if(element !== ""){
                let var2 = str2[i] !== undefined ? str2[i] : "";
                _arr.push(element + ":" + var2);
            }
        });
        return _arr;
    }
}