import React from 'react';
import '../../setupTest';
import HelperTest from '../HelperTest';

test('Sample mocking helper', () => {
    const mockCallback = ["string1"];
    const mockCallback2 = ["val1"];

    // Mock our helpers by passing them in "jes.fn()"
    const whattest = jest.fn(() => HelperTest.CreateStringList(mockCallback, mockCallback2));

    // Execute a mock once
    whattest(["string134534"], mockCallback2);

    // Check our mock called by X times
    expect(whattest.mock.calls.length).toBe(1);

    // Check our mock's return value - version 1
    expect(whattest.mock.results[0].value).toEqual(["string1:val1"]);
    
    //Check our mock's parameters received
    expect(whattest.mock.calls[0][0]).toEqual(["string134534"]);
    expect(whattest.mock.calls[0][1]).toEqual(["val1"]);

    // Execute another mock
    whattest(mockCallback, mockCallback2);

    // Check our mock's return value - version 2 (last mock ran)
    expect(whattest).toHaveLastReturnedWith(["string1:val1"]);

    // We already called 2 mocks so we are expecting calls.length to be 2
    expect(whattest.mock.calls.length).toBe(2);
});