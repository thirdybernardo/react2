import React from 'react';
import { shallow } from 'enzyme';
import '../../setupTest';
import HelloWorld from '../HelloWorld';
import pageContent from '../../../../../build/Data/json/DemoPage.json';
import renderer from 'react-test-renderer';


// Render HellowWorld using shallow rendering
const helloWorld = shallow(<HelloWorld data={pageContent} />);

test('HelloWorld matches snapshot', () => {
    // Check snapshot if markup did not change while using static data 
    const tree = renderer.create(<HelloWorld data={pageContent} />).toJSON();
    expect(tree).toMatchSnapshot();

    /* We can also initialize our data statically */
    // const pageContent = {
    //     "item":{
    //         "Title": "This is a demo of data retrieved from a mockup data file",
    //         "PromoText": "I'm supposed to be a <i>promo component</i>, do you recognize me?"
    //     }
    // }
});

test('HelloWorld renders required HTML elements', () => {
    // Check if certain elements exist using CSS selectors
    const title = helloWorld.find("div.title");
    const promoText = helloWorld.find("span.promotext");

    expect(title).toEqual(expect.anything());
    expect(promoText).toEqual(expect.anything());
});

test('HelloWorld gets all props', () => {  
    // Check if number of assertions is correct, specifically useful to ensure that assertions on an async function are executed
    expect.assertions(4);

    // Check if component received all props    
    expect(helloWorld.instance().props.data.item.Title).toEqual(expect.anything(String));
    expect(helloWorld.instance().props.data.item.PromoText).toEqual(expect.anything(String));

    // Check component renders the props it received
    expect(helloWorld.find(".title").text()).toEqual(pageContent.item.Title);
    expect(helloWorld.find("span.promotext").html()).toEqual(expect.stringContaining(pageContent.item.PromoText));  
});

test('HelloWorld has a required string state', () => {
    // Check if a specific state with string value exists
    expect(helloWorld.state().sampleState).toEqual(expect.anything(String));
});

test('HelloWorld has not yet rendered the subcomponent', () => {
    // Dynamically import the subcomponent just for the constructor and check if it does not exist yet
    const SubWorld = require ('../SubWorld').default;
    expect(helloWorld.find(SubWorld).length).toBe(0);
});

test('HelloWorld renders subcomponent when button is clicked', () => {
    const SubWorld = require ('../SubWorld').default;

    // Subcomponent should not render until button is clicked
    expect(helloWorld.find(SubWorld).length).toBe(0);

    const reqButton = helloWorld.find({children: "Click me to render the subcomponent"});
    expect(reqButton.text()).toBe("Click me to render the subcomponent");

    // Simulate click of button
    reqButton.simulate('click');

    expect(helloWorld.find(SubWorld).length).toBe(1);
});

test('HelloWorld simulate event with props', () => {
    const reqButton = helloWorld.find('input#clickWithProps');
    expect(helloWorld.state().sampleState2).toEqual(1);

    // Simulate onChange of the input element and its value
    reqButton.simulate('change', {
        currentTarget: { value: "test passed" }
    });
    expect(helloWorld.state().sampleState2).toEqual("test passed");
});