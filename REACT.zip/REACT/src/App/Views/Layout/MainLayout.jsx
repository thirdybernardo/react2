import React from "react";
import ReactDOM from "react-dom";

export default class MainLayout extends React.Component{
    render()
    {
        return(
            <div role="main">          
                {this.props.children}      
            </div>
        );
    }
}