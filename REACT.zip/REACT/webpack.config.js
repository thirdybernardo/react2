﻿var path = require('path');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

module.exports = {
  context: path.join(__dirname, 'src/App'),
  entry: {
    fed: './fed.js',
    server: './server',
    client: ['axios', './client']
  },

  output: {
    path: path.join(__dirname, 'build'),
    filename: '[name].bundle.js'
  },
  module: {
    noParse: [/jszip.js$/],
    loaders: [
      // Transform JavaScript files via Babel
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        loaders: ['babel-loader', "eslint-loader"],
        options: {
          presets: [
            '@babel/preset-env',
            {
              plugins: [
                '@babel/plugin-proposal-class-properties'
              ]
            }
          ]
        }
      },
      {
        test: /\.(scss|css)$/,
        exclude: /node_modules/,
        loader: ExtractTextPlugin.extract(['css-loader', 'sass-loader'])
      },
      {
        test: /\.json$/,
        loader: 'json-loader'
      }
      // Uncomment this if you want to use your own version of React instead of the version 
      // bundled with ReactJS.NET.
      //{ test: require.resolve('react'), loader: 'expose?React' }
    ]
  },
  plugins: [
    new ExtractTextPlugin("styles.css")
  ],
  resolve: {
    // Allow require('./blah') to require blah.jsx
    extensions: ['', '.js', '.jsx', '.json']
  },
  externals: {
    // Use external version of React (from CDN for client-side, or bundled with ReactJS.NET for server-side)
    // Comment this out if you want to load your own version of React
    react: 'React'
  },
  devServer: {
    historyApiFallback: true
  },
  devtool: 'source-map'
};